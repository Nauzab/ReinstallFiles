/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;


import java.util.ArrayList;
import model.Grade;
import model.Professor;
/**
 *
 * @author s6_zablov_n
 */
public class main {
    public static void main(String[] args){
        
        //Create subjects
        Subject sub1 = new Subject("JAVA" , 4); //check subject contstructor for input
        Subject sub2 = new Subject("Math", 8);
        Subject sub3 = new Subject("Datastr", 2);
        
        
        //Create grades for student 1 - Janis
        Grade g1_1  = new Grade(sub1,10); //Check grades constructor for inputs
        Grade g1_2 = new Grade (sub2, 5);
        
        Grade[] StudentGrades ={g1_1, g1_2};
        System.out.println(g1_1);
         
        
        Student s1 = new Student("Janis", "Berzins" , StudentGrades);
        
       System.out.println(s1);
       
       ArrayList<Subject> subForLiga = new ArrayList<Subject>();
       subForLiga.add(sub1);
       subForLiga.add(sub2);
      
       //System.out.println(p1);
        
        
    }

   
}