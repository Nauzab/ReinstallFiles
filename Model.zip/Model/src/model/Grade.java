/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author s6_zablov_n
 */
public class Grade {
    private Subject sub;
    private int gradeValue;

    public Grade(Subject sub, int gradeValue) {
        setSub(sub);
        setGradeValue(gradeValue);
    }

    public Subject getSub() {
        return sub;
    }

    public void setSub(Subject sub) {
        this.sub = sub;
    }

    public int getGradeValue() {
        return gradeValue;
    }

    public void setGradeValue(int gradeValue) {
        this.gradeValue = (gradeValue >= 0 && gradeValue <= 10)? gradeValue:0;
    }

    @Override
    public String toString() {
        return "Grage{" + "sub=" + sub + ", gradeValue=" + gradeValue + '}';
    }
     
    
    
    
}
