/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package md1;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author nz
 */
public class Appointment {
    private int appID;
    private int appCounter;
    private Date date;
    private String description;
    ArrayList<Doctor> Doctor = new ArrayList<>();
    private Patient patient;

    public Appointment(Date date, String description, Patient patient, ArrayList<Doctor> Doctor) {
        
        setDoctor(Doctor);
        setDate(date);
        this.description = description;
        this.patient = patient;
        
        
    }

    public int getAppID() {
        return appID;
    }

    public void setAppID(int appID) {
        this.appID = appID;
    }

    public int getAppCounter() {
        return appCounter;
    }

    public void setAppCounter(int appCounter) {
        this.appCounter = appCounter;
    }


    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        //checks if date is between 1 and 31 AND checks if month is between 1 and 12  //getMonth starts with 0 
        if(date.getDate() >= 1 || date.getDate() <= 31 || date.getMonth() +1 >= 1 || date.getMonth() +1 <= 12){
            this.date = date;
        }
        else {
        this.date = null;
        }
        
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        if(description != null)
        this.description = description;
        else{
            this.description = "Unset";
        }
    }

    public ArrayList<Doctor> getDoctor() {
       
        return Doctor;
    }

    public void setDoctor(ArrayList<Doctor> Doctor) {
        
        this.Doctor = Doctor;
        
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    
    public void printInvolvedDoctors(){
        for( Doctor i : Doctor  ){
            System.out.println(i);
        }
    }
    
    public boolean addNewDoctorToAppointmet(Doctor doctor){
        //Add doctor to a arraylist
        Doctor.add(doctor);
        return true;
    }
    
   public boolean removeExistingDoctorFromAppointment(Doctor Doctor, ArrayList<Doctor> doc){
      boolean a = false;
      //Goes through arraylist 
       for(int i = 0 ; i < doc.size(); i++){
           //If there is object equal to Doctor
          if( Doctor == doc.get(i)){
              //Delete object
              doc.remove(Doctor);
              a = true;
          }
      } return a;  
    }
   


    @Override
    public String toString() {
        return "Appointment{" + "appID=" + appID + ", appCounter=" + appCounter + ", date=" + date + ", description=" + description + ", Doctor=" + Doctor + ", patient=" + patient + '}';
    }
    
    
}