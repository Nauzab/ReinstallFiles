
package DatuSreSem1;

import java.util.Arrays;

/**
 *
 * @author nz
 */
public class Student {
    private int id = 1;
    private String name;
    private String surname;
    private char gander;
    private int[] grade = new int[3];

    public Student() {
        
    }
    
    public Student(String name, String surname, int[] grade){
        setName(name);
        setSurname(surname);
        setGrade(grade);
        setGender(name);
        setiD(id);
    }
    
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getName() {
        return name;
    }

    
    public void setSurname(String surname) {
        this.surname = surname;
    }
    
    public String getSurname() {
        return surname;
    }
    
    public void setGrade(int[] grade){
        for(int i = 0 ; i < grade.length ; i++){
            //check if grade is in range between 0 and 10;
            if(grade[i] <= 10 && grade[i] >=0 ){
                this.grade[i] = grade[i];
            }
        }
    }
   
    public int[] getGrade(){
        return grade;
    }
    
    public void setGender(String name){
        //checks if last character is 's' for men reprasented as 'V'
        if(name.charAt(name.length()-1) == 's'){
            this.gander = 'V';
        }
        //checks if last character is 'a' or 'e' for women reprasented as 'S'
        else if (name.charAt(name.length() -1) == 'a' || name.charAt(name.length() -1) == 'e'){
            this.gander = 'S';   
        }
        //Else set gander as unset reprasented as 'U'
        else{
            this.gander = 'U';
        }
    }
    public char getGender(){
        return gander;
    }
    
    public void setiD(int id){
        this.id++;
    }
    public int getId(){
        return id;
    }
    
    //Retunrs average grade for student
    public double getAverageGrade(int[] grade){
        double average = 0 ;
        int total = 0 ;
        
        for(int i = 0; i <  grade.length;i++){
            total += grade[i];
        }
        
        return average = total / grade.length;
        
    }
    
    public void Print(){
        System.out.println(name +" "+ surname + " id: " + id + " Gander: " + gander + " Grades: " + Arrays.toString(grade) + " Average grade: " + getAverageGrade(grade) );
    }
    
}
