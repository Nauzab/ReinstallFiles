package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.controllers.User;
import com.example.demo.controllers.bingoController;
import com.example.demo.model.Student;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		
		bingoController.allUsers.add(new User("Nauris" , "12345")); //create user 
		bingoController.allUsers.add(new User("Janis" , "12345"));
		
		SpringApplication.run(DemoApplication.class, args);
	}

}
