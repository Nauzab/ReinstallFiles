
package DatuSreSem1;

import DatuSreSem1.Saraksts;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author nz
 */
public class MyInteger {
    private Integer value = 0 ;

    public MyInteger( Integer value) {
        setInteger(value);
    }
     
    public void setInteger(Integer value ){
        this.value = value;
    }
    
    public Integer getInteger(){
        return value;
    }
    
    public boolean SearchForIntElement(int element ,List<Saraksts> saraksts ){
        boolean a = false;
        int found = 0 ;
        
           //Searche for element in list
            for(int i = 0 ; i < saraksts.size(); i++){
                //If find return true
            if(saraksts.get(i) == element){
              a =  true;
              found = i ;
            }else{
                a= false;
        }
        }
        System.out.println("Element found at index " + found );
    return a;
}
     
    public void print(){
        System.out.print(value);
    }
}
