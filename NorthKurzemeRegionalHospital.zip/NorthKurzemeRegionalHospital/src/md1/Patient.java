/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package md1;

/**
 *
 * @author nz
 */
public class Patient extends Person{
        private int patientId;
        private int patientCounter;
        private boolean isHospitalised;

    public Patient(boolean isHospitalised, String name, String surname, int[] identicator, Gender gender, Nationality nationality) {
        super(name, surname, identicator, gender, nationality);
        this.isHospitalised = isHospitalised;
    }

        
    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public int getPatientCounter() {
        return patientCounter;
    }

    public void setPatientCounter(int patientCounter) {
        this.patientCounter = patientCounter;
    }

    public boolean isIsHospitalised() {
        return isHospitalised;
    }

    public void setIsHospitalised(boolean isHospitalised) {
        this.isHospitalised = isHospitalised;
    }

    @Override
    public String toString() {
        return super.toString() + "Patient{" + "patientId=" + patientId + ", patientCounter=" + patientCounter + ", isHospitalised=" + isHospitalised + '}';
    }
        
        
    
}
