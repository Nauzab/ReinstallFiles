package com.example.demo.model;

public class Player {
    private int id = 0;
    private String name;
   
    
    public Player(String name) {
        setName(name);
        int idCounter = id;
        idCounter++;
        setId(idCounter);
        
    }
    public Player() {
    }
        
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
}
