
package eksamanes;

import java.util.Scanner;


public class Eksamanes {

    public static void main(String[] args) {
        
       
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Ar cik kompleksajiem skaitliem velesieties darboties? -> ");
        int input = sc.nextInt();
        if(input < 0 ){
            input = 0;
        }
        
        Stack realSt = new Stack(3);
        Stack result = new Stack(input);
        Complex cmp = new Complex();
        
        double real;
        double imaginary;
      
        Complex temp = new Complex();
        String darbiba;
        
        for(int i = 1; i< input + 1 ; i++){
        System.out.println("Ludzu ievadien skaitala Nr."+ i+". realo dalu -> ");
        if(sc.hasNextInt()){
            real = sc.nextInt();
        }else{
            real = 0;
        }

        System.out.println("Ludzu ievadien skaitala Nr."+ i +". imaginaro dalu -> ");
        if(sc.hasNextInt()){
            imaginary= sc.nextInt();
        }else{
            imaginary = 0;
        }
        
        
        
        
        cmp = new Complex((double)real, (double)imaginary);
        
        if(realSt.isEmpty()){
             realSt.push(cmp); 
             
        }else{
            
           temp = (Complex) realSt.top();
            realSt.push(real);
            realSt.push(temp);
        }
       
        System.out.println(cmp.toString());
        }
        
        System.out.println("Ludzu ievadiet darbibas (secigi pec kartas) ->");
        darbiba = sc.next();
        double sum; 
        Complex calCmp = new Complex();
        for(int i = 0 ; i < darbiba.length(); i++){
            if(darbiba.charAt(i) == '*'){
                calCmp = (Complex)realSt.top();
                sum= calCmp.getRe() * calCmp.getRe() + calCmp.getIm() * calCmp.getIm();
                result.push(sum);
                
            }else if (darbiba.charAt(i) == '/'){
              
                
            }
        }
        
        System.out.println(result.top());
        
            
    }
    
}
