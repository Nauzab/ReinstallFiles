
package mylinkedqueue;

/**
 *
 * @author nz
 */
public class Student {
    private float grade;
    private String name;
   


    public Student(){}
    public Student(float grade,String name){
        setName(name);
        this.grade = grade;
    }
    
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getName() {
        return name;
    }
    
   public void print(){
       System.out.println(grade +" "+ name);
   }
}

   
