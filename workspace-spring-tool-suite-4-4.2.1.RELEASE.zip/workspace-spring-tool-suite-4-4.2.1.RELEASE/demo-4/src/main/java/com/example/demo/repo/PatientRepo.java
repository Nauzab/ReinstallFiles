package com.example.demo.repo;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Patient;


public interface PatientRepo extends CrudRepository<Patient, Integer> {
		Patient findById(int id);
}
