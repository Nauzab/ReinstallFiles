package com.example.demo.repo;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Student;

public interface StudentRepo extends CrudRepository<Student, Integer>{

	
	//JPA repor or Crud rep
}
