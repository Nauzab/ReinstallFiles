/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;



import java.util.ArrayList;

/**
 *
 * @author s6_zablov_n
 */
public class Professor extends Person {
    
    private Degree degree;
    ArrayList<Subject> allProfSubjects = new ArrayList<>();

    public Professor(String name, String surname , Degree degree, ArrayList<Subject> subjects) {
        super(name, surname);
        setAllProfSubjects(allProfSubjects);
        setDegree(degree);
        
    }

    public Degree getDegree() {
        return degree;
    }

    public void setDegree(Degree degree) {
        this.degree = degree;
    }

    public ArrayList<Subject> getAllProfSubjects() {
        return allProfSubjects;
    }

    public void setAllProfSubjects(ArrayList<Subject> allProfSubjects) {
        this.allProfSubjects = allProfSubjects;
    }

    @Override
    public String toString() {
        return super.toString() + "Professor{" + "degree=" + degree + ", allProfSubjects=" + allProfSubjects + '}';
    }
    
    
    
}
