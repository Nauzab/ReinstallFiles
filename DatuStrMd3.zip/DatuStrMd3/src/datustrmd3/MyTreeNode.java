/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datustrmd3;



public class MyTreeNode <T> {
    private T data;
    private MyTreeNode<T> leftC;
    private MyTreeNode<T> rightC;

    public MyTreeNode(){
        data = null;
        leftC = null;
        rightC = null;
    }
    public MyTreeNode(T data, MyTreeNode<T> leftC, MyTreeNode<T> rightC) {
        this.data = data;
        this.leftC = leftC;
        this.rightC = rightC;
    }

    public MyTreeNode(T data) {
        this.data = data;
        this.leftC = null;
        this.rightC = null;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public MyTreeNode<T> getLeftC() {
        return leftC;
    }

    public void setLeftC(MyTreeNode<T> leftC) {
        this.leftC = leftC;
    }

    public MyTreeNode<T> getRightC() {
        return rightC;
    }

    public void setRightC(MyTreeNode<T> rightC) {
        this.rightC = rightC;
    }
}