
package sakums;

public class Sakums {


    public static void main(String[] args) {
        System.out.println("Hello Java");
        
        int i = 10000;
         short s = (short) i;
        
        System.out.println(s);
    }
    
    
}
