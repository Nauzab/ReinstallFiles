<?php 
# Veidojam savienojumu ar savu serveri un datu bāzi
$d = mysqli_connect('localhost','worldread','worldreadPaSS','world') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");
?>

<html>
<head>
<link rel="stylesheet" href="pasakums.css" type="text/css">
</head>
<body>
<?php

function tabula($sql_res) {
$first = true;
echo "<center><table class=\"schedule\">";
while ($row = mysqli_fetch_assoc($sql_res)) {
    if ($first) {
        echo "<tr>";
        foreach ($row as $k=>$v) {
            echo "<th>$k</th>";
        }
        echo "</tr>".PHP_EOL;
        $first = false;
    }
    echo "<tr>";
        foreach ($row as $v) {
            echo "<td>$v</td>";
        }
        echo "</tr>".PHP_EOL;
}
echo "</table></center>";

$row_cnt = mysqli_num_rows($sql_res);
printf("<br><left>Result set has <b>%d</b> rows. </left>\n", $row_cnt);
/* close result set */
mysqli_free_result($sql_res);
}

?>