package com.example.demo.repo;

import java.util.ArrayList;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Course;

public interface CourseRepo extends CrudRepository<Course, Integer> {
		
	Course findByTitle(String title); //return title name of course |STATEMENT|  Need to be FINDBY in functions name !!
	ArrayList<Course> findByCp(int cp); //return all courses credit points
	Course findByTitleAndCp(String title, int cp);
}
