package com.example.demo.VotingController;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.Candidate;
import com.example.demo.model.Party;
import com.example.demo.model.User;
import com.example.demo.repo.CandidateRepo;
import com.example.demo.repo.PartyRepo;
import com.example.demo.repo.UserRepo;

@Controller
public class VotingController {
	
	@Autowired
	UserRepo userRepo;
	
	@Autowired
	PartyRepo partyRepo;
	
	@Autowired
	CandidateRepo candidateRepo;
	
		
	@GetMapping(value="/testing")
	public String testing()
	{
		User u1 = new User("Janis", "1111");
		User u2 = new User("Andris", "0000");
		User u3 = new User("Emins", "2222");
		userRepo.save(u1);
		userRepo.save(u2);
		userRepo.save(u3);
		
		Party p1 = new Party("Latvijai");
		Party p2 = new Party("Eiropai");
		partyRepo.save(p1);
		partyRepo.save(p2);
		
		Candidate c1 = new Candidate("Janis" , "Berzins", 0 , p1);
		Candidate c2 = new Candidate("Baiba" , "Jauka", 0 , p1);
		Candidate c3 = new Candidate("Liga" , "Forsa", 0 , p2);
		Candidate c4 = new Candidate("Peteris" , "Kalnins", 0 , p2);
		candidateRepo.save(c1);
		candidateRepo.save(c2);
		candidateRepo.save(c3);
		candidateRepo.save(c4);
		
		
		
		
		
		return "auth.html";
	}

	@GetMapping(value="/authorise")
	public String authoriseGet(User user)
	{
		
		return "auth.html";
	}
	
		
	@PostMapping(value="/authorise")
	public String authorisePost(User user)
	{
		User u = userRepo.findByUsernameAndPassword(user.getUsername(), user.getPassword());
		if(u!=null) {}
			
			
		return " " ;
	}
	
	
	@GetMapping(value="/admin/insertnewparty")
	public String insertPartyGet(Party party)
	{
		
		return "insertparty";
	}
	
	@PostMapping(value="/admin/insertnewparty")
	public String insertPartyPost(Party party)
	{
		return "";
	}
	
	
	@GetMapping(value="/admin/insertnewcandidate")
	public String insertCandidateGet()
	{
		return "";
	}
	
	@PostMapping(value="/admin/insertnewcandidate")
	public String insertCandidatePost()
	{
		return "";
	}
	
	@GetMapping(value="/admin/showallparties")
	public String showAllPartiesGet(Model model)
	{
		ArrayList<Party> p = (ArrayList<Party>) partyRepo.findAll();
		
		model.addAttribute("veriable", p);
		
		
		
		return "party";
	}
	
	@GetMapping(value="/admin/showallcandidates")
	public String showAllcandidatesGet(Model model)
	{
		ArrayList<Candidate> c = (ArrayList<Candidate>) candidateRepo.findAll();;
		model.addAttribute("candidates", c);
		return "candidates";
	}
	
	
	@GetMapping(value="/admin/showallcandidates/{id}")
	public String showAllcandidatesGetByParty(Model model,@PathVariable (name="id")int id)
	{
		Party party = partyRepo.findById(id).get();
		//partyRepo.save(party);
		ArrayList<Candidate> c = candidateRepo.findByParty(party);
		
		
		model.addAttribute("candidate", c);
		
		
		return "candidates";
	}
	
	@GetMapping(value="/admin/showallusers")
	public String showAllUsersGet(Model model)
	{
		ArrayList<User> u = (ArrayList<User>) userRepo.findAll();
		model.addAttribute("user", u);
		return "user";
	}
	
	@GetMapping(value="/user/vote/{id}")
	public String voteGet()
	{
		return "";
	}
	
	@PostMapping(value="/user/vote/{id}")
	public String votePost()
	{
		return "";
	}
	
	@GetMapping(value="/voted")
	public String votedGet()
	{
		return "";
	}
}