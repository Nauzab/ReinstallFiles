package com.example.demo.repo;

import java.util.ArrayList;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Candidate;
import com.example.demo.model.Party;

public interface CandidateRepo extends CrudRepository<Candidate, Integer> {
	
	 	ArrayList<Candidate> findByParty(Party party);
}
