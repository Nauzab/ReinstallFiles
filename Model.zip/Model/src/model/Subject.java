/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author s6_zablov_n
 */
public class Subject {
    private String title;
    private int creditPoints;
    
    
    public Subject(String title, int creditPoints) {
        setTitle(title);
        setCreditPoints(creditPoints);
    }
    
    public void setTitle(String title) {
        this.title = title;
    }

    public void setCreditPoints(int creditPoints) {
        
        this.creditPoints = (creditPoints > 0 && creditPoints < 20)? creditPoints:4;//Check if creditpoints bigger then 0 and smaller the 20
    }

    @Override
    public String toString() {
        return "Subject{" + "title=" + title + ", creditPoints=" + creditPoints + '}';
    }

    
    
    
}
