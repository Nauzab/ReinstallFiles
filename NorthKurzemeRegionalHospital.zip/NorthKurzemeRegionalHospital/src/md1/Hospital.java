/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package md1;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;




/**
 *
 * @author nz
 */
public class Hospital {

    private String Hospital;
    static ArrayList<Doctor> Doctor = new ArrayList<Doctor>();
    static ArrayList<Appointment> Appointment = new ArrayList<Appointment>();
    static ArrayList<Patient> Patient = new ArrayList<Patient>();
    static ArrayList<Doctor> involvedDoctors = new ArrayList<Doctor>();
    static  int doctorIdCounter = 1; //Doctor id counter 
    static int doctorCounter = 1; // Doctor counter
    static int patientIdCounter = 1; // Patient id counter
    static  int patientCounter = 1; //Patient counter
    static int identicatorCounter = 0;
    static int appIdCounter = 1; //appointment id counter
    static  int appCounter = 1; //appointment counter
 
    public static void main(String[] args) throws ParseException {
        
        
        Hospital hosp = new Hospital();
        hosp.setHospitalName("NorthKurzemesRegionalHospital");
        
        short offic = 1;
        
        
       //Adding two doctors and patients
       System.out.println("1.Adding two new Doctors and Patiens to hospital.... \n");
       
        Doctor d1 = hosp.GenerateDoctor(offic, Speciality.Heart, "Janis", "Auzins",hosp.setIdenticator(), Gender.Male, Nationality.Latvian);
        Doctor d2 = hosp.GenerateDoctor(offic, Speciality.Heart, "Maris", "Liepa", hosp.setIdenticator(), Gender.Male, Nationality.Latvian);

        Patient p1 = hosp.GeneratePatient(false, "Julija", "Meiere", hosp.setIdenticator(), Gender.Famele, Nationality.Latvian );
        Patient p2 = hosp.GeneratePatient(false, "Lauris", "Krupis", hosp.setIdenticator(), Gender.Male, Nationality.Latvian);
        
        System.out.println("Added two Doctors.. \n" + Doctor + "\n \nAdded two Patients.. \n" + Patient );
        
        //2.Delete doctor and patient by id  
      hosp.deleteExistingDoctorInHospitalById(1);
      hosp.deleteExistingPatientInHospitalById(1);
      System.out.println("\n2.Deleting Doctor and Patient by ID (in this case id = 1) \n Deleting Doctor...."+Doctor+" \n Deleting Patient..." + Patient + "\n");
       
      //3.Delete doctor and patient by object
      hosp.deleteExistingDoctorInHospitalByObject(d2);
      hosp.deleteExistingPatientInHospitalByObject(p2);
      System.out.println("\n3.Deleting Doctor and Patient by object (in this case d2 and p2) \n Deleting Doctor...."+Doctor+" \n Deleting Patient..." + Patient + "\n");
      
      
      
      //4.Create new appointment //Appointment will only be added when doctor is added to involvedDoctor, because appointment can't happen without doctor.
      
      involvedDoctors.add(d1); //Set involved doctor
      Appointment a1 = hosp.makeNewAppointmentInHospital(p1, setDate("2019-03-08 12:20"), "Flue", involvedDoctors);
       System.out.println("\n4.Making new appointment...\n" + Appointment);
       
       
         //5.Delete specific appointment
      hosp.deleteExistingAppointment(p1, setDate("2019-03-08 12:20"));
      System.out.println("\n5.Deleting appointment...\n" + Appointment);
      
      
      //6.Pre-define list of Doctors Patients Appoitnemnts
      Doctor d3 = hosp.GenerateDoctor(offic, Speciality.Heart, "Matiss", "Lapins",hosp.setIdenticator(), Gender.Male, Nationality.Latvian);
      Doctor d4 = hosp.GenerateDoctor(offic, Speciality.kid, "Janis", "Kruks",hosp.setIdenticator(), Gender.Male, Nationality.Latvian);
      Doctor d5 = hosp.GenerateDoctor(offic, Speciality.kid, "Marta", "Briede",hosp.setIdenticator(), Gender.Famele, Nationality.Latvian);
      
      Patient p3 = hosp.GeneratePatient(false, "Artis", "Bisofs", hosp.setIdenticator(), Gender.Male, Nationality.Latvian );
      Patient p4 = hosp.GeneratePatient(false, "Anita", "Mieze", hosp.setIdenticator(), Gender.Famele, Nationality.Latvian );
      Patient p5 = hosp.GeneratePatient(false, "Ojars", "Burts", hosp.setIdenticator(), Gender.Male, Nationality.Latvian );
      
      involvedDoctors.add(d3);
      Appointment a2 = hosp.makeNewAppointmentInHospital(p3, setDate("2019-03-08 12:20"), "Flue", involvedDoctors);
      
     involvedDoctors.add(d4);
      Appointment a3 = hosp.makeNewAppointmentInHospital(p5, setDate("2019-03-08 15:30"), "Flue", involvedDoctors );
      
      involvedDoctors.add(d5);
      involvedDoctors.add(d4);
      Appointment a4 = hosp.makeNewAppointmentInHospital(p3, setDate("2019-03-09 15:30"), "Flue", involvedDoctors );
      
      //This wont add to Hospital appointment because of the same date and time for one doctor ..
      involvedDoctors.add(d3);
       Appointment a5 = hosp.makeNewAppointmentInHospital(p4, setDate("2019-03-08 12:20"), "Flue", involvedDoctors);
       
        involvedDoctors.add(d4);
      Appointment a6 = hosp.makeNewAppointmentInHospital(p5, setDate("2019-03-08 11:30"), "Flue", involvedDoctors );
      
          
      //7.Print all print functions;
      System.out.println("\nPrinting all Doctors in Hospital...");
      hosp.printAllDoctorstInHostpital();
      
      System.out.println("\nPrinting all Patient in Hospital...");
      hosp.printAllPatientsInHostpital();
      
      System.out.println("\nPrinting all Appointment in Hospital...");
      hosp.printAllAppointmentsInHostpital(); 
      
      System.out.println("\nPrinting all Appointment for Patient...");
      hosp.printAllAppointmentsForPatient(p3);
      
      System.out.println("\nPrinting all Patien for Date...");
      hosp.printAllPatientForDate(setDate("2019-03-08 00:00"));
 
      
      
      //8.*Generate the day plan of the specific doctor
       System.out.println("\nGenerating day plan for Doctor...");
       Date date = setDate("2019-03-08 00:00");
        hosp.generateAndPrintDayPlanForDoctor(d4, date);
        
        
        //9.*Generate doctor in hospital
        
        System.out.println("\nGenerating Doctor....");
        hosp.genereateDoctorInHospital();
     
     
     
     
        
      
   
    }
     enum Gender{
        Male,
        Famele,
        Unset
    }
    enum Nationality{
        Latvian,
        Estonian,
        Unset
    }
    enum Speciality{
        Heart,
        kid
    }

    public Hospital() {
        
    }

    
    
    public String getHospitalName() {
        return Hospital;
    }

    public void setHospitalName(String Hospital) {
        this.Hospital = Hospital;
    }

    public ArrayList<Doctor> getDoctorInHospital() {
        return Doctor;
    }

    public void setDoctorInHostpital(ArrayList<Doctor> Doctor) {
        this.Doctor = Doctor;
    }

    public ArrayList<Appointment> getAppointmentInHospital() {
        return Appointment;
    }

    public void setAppointmentInHospital(ArrayList<Appointment> Appointment) {
        this.Appointment = Appointment;
    }

    public ArrayList<Patient> getPatientInHospital() {
        return Patient;
    }

    public void setPatientInHospital(ArrayList<Patient> Patient) {
        this.Patient = Patient;
    }
    
    public boolean addNewPatientInHospital(Patient patient){
        
        Patient.add(patient);
        return true;
    }
    
    public boolean deleteExistingPatientInHospitalById(int id){
        
        //Goes trough Patient ArrayList
        for(int i = 0 ; i < Patient.size(); i++){
            
           //If finds same Patient ID , remove object from Patient ArrayList
           if( Patient.get(i).getPatientId() == id){
               Patient.remove(i);
           }
       }
        return true;
    }
    
    
    public boolean deleteExistingPatientInHospitalByObject(Patient patient){
        
        //Goes trough Patient ArrayList
        for(int i = 0 ; i < Patient.size(); i++){
            
           //If finds same Patient ,remove object from Patient ArrayList
           if( Patient.get(i) == patient){
               Patient.remove(i);
           }
       }
        return true;
    }
    
    public boolean addNewDoctorInHospital(Doctor doctor){
        
        Doctor.add(doctor);
        return true;
    }
    
    public boolean deleteExistingDoctorInHospitalById(int id){
        
        //Goes trough Doctor ArrayList
        for(int i = 0 ; i < Doctor.size(); i++){
            
           //If finds same Doctor ID , remove object from Patient ArrayList
           if( Doctor.get(i).getDoctorID() == id){
               Doctor.remove(i);
           }
       }
        return true;
    }
    
    
    public boolean deleteExistingDoctorInHospitalByObject(Doctor doctor){
        
        //Goes trough Doctor ArrayList
        for(int i = 0 ; i < Doctor.size(); i++){
            
           //If finds same Patient ,remove object from Patient ArrayList
           if( Doctor.get(i) == doctor){
               Doctor.remove(i);
           }
       }
        return true;
    }
    
    public void genereateDoctorInHospital(){
          
        short office = 1; //ofice
        String[] names ={"Janis" , "Marta" , "Emils" , "Jana"};//name
        String[] surnames = {"Kalnins" , "Kalnina", "Berzins" , "Takera"};//username
        Random r = new Random();
         int name = r.nextInt(names.length ) ; //get random index of names array
         int surname = r.nextInt(surnames.length  ) ; //get random index if surnames array
       
         Nationality nat = Nationality.Latvian; //Nationality
         Gender gen = Gender.Male; //Gender
         
         //while last char of string dont match
         while(names[name].charAt(names[name].length() -1 ) != surnames[surname].charAt(surnames[surname].length() -1) ){ 
             
            //if last char is s set male
            switch (names[name].charAt(names[name].length() -1)) {
                case 's':
                    
                    gen = Gender.Male;
                    break;
                case 'a':
                    
                    gen =  Gender.Famele;
                    break;
                
            }
           surname = r.nextInt(surnames.length); 
         }
         
         //Genereate speciality / from whom set description
         int indexForSpec = r.nextInt(Speciality.values().length); //Speciality
        
         
         Doctor di = GenerateDoctor(office,Speciality.values()[indexForSpec], names[name], surnames[surname], setIdenticator(), gen, nat);
        System.out.println(di);
        
             
        
    }
    
    public Appointment makeNewAppointmentInHospital(Patient patient, Date date, String description, ArrayList<Doctor> Doc){
        
        Appointment appointment = null ;
        ArrayList<Doctor> newDoc = new ArrayList<>();
        boolean a = false;
        //Goes trough Doc arraylist
        for(int i = 0 ; i < Doc.size() ; i++){
            //if doctor is free in that date and time set new appointment..
             if(checkDateForDoctor(Doc.get(i), date) == true){
                 newDoc.add(Doc.get(i));
                    a = true;
             }else{
                 a = false;
             }
        }         
        if(a == true){

                   appointment = new Appointment(date, description, patient, newDoc);
           
                  appointment.setAppID(appIdCounter++);
                  appointment.setAppCounter(appCounter++);
                  Appointment.add(appointment);
        }
        //Clears involved doctor arraylist..
        for(int i = 0 ; i < involvedDoctors.size();i++){ 
            involvedDoctors.remove(i);
        }
        
        
        
       
        return appointment;
    }
    
    public boolean deleteExistingAppointment(Patient patient, Date date){
        boolean x= false;
        //Goes trough Appointment arraylist 
        
        for(int i = 0 ; i < Appointment.size() ; i++){
            //if Patient and date matches remove Appointment 
            if(Appointment.get(i).getPatient() == patient && Appointment.get(i).getDate().equals(date)){
                Appointment.remove(i);
                x = true;
            }
        }
        
        return x;
    }
      
    
   public void printAllPatientsInHostpital(){
       
        for( Patient i : Patient  ){
            System.out.println(i);
        }
   }
   
    public void printAllDoctorstInHostpital(){
       
        for( Doctor i : Doctor ){
            System.out.println(i);
        }
   }
    
     public void printAllAppointmentsInHostpital(){
       
        for( Appointment i : Appointment  ){
            System.out.println(i);
        }
   }
     
    public void printAllPatientForDate(Date date){
       
        
         //set date to next day
      Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, 1); 
          
            for(int i = 0 ; i < Appointment.size() ; i++){                 
              //check if date is before next day 
             if( Appointment.get(i).getDate().before(cal.getTime()) && Appointment.get(i).getDate().after(date)){
                  System.out.println( "  "+ Appointment.get(i).getPatient() + "\n");
             }
          
          }
    }
    
    public void printAllAppointmentsForPatient(Patient patient){
        //Goes trough appointment arraylist
        for(int i = 0 ; i < Appointment.size(); i++){
            //checks if patient maches in appointment arraylist if maches prints that appointment
            if(Appointment.get(i).getPatient() == patient){
                System.out.println(Appointment.get(i));
            }
        }
        
        
    }
    
    public void generateAndPrintDayPlanForDoctor(Doctor doctor , Date date){
         
        System.out.println(" Day Plan for Dr." + doctor.getSurname());
      //Goes trough appointment arraylist
      
      //set date to next day
      Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, 1); 
         
       
          //For loop so getDoctor() doesnt go out of range 
          
            for(int i = 0 ; i < Appointment.size() ; i++){
                for(int j = 0 ; j < Appointment.get(i).getDoctor().size() ; j++){
                    if(Appointment.get(i).getDoctor().get(j) == doctor  ){
              //check if date is before next day 
             if( Appointment.get(i).getDate().before(cal.getTime()) && Appointment.get(i).getDate().after(date)){
                  System.out.println( "  "+ Appointment.get(i).getDate() + "\n");
             }
                }
          
             
              
          }
          }
      
        
    }

    @Override
    public String toString() {
        return "Hospital{" + "Hospital=" + Hospital + ", Doctor=" + Doctor + ", Appointment=" + Appointment + ", Patient=" + Patient + '}';
    }
    
    //Own created functions
    
    //Function for set date
    public static Date setDate(String strDate) throws ParseException{
        
         SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");  
         
        //Parse string to Date format
        Date date = formatter.parse(strDate);  
       
         return date;
     }
    
    public Doctor GenerateDoctor(short officeNum, Speciality speciality, String name, String surname, int[] identicator, Gender gender, Nationality nationality){
       
        Doctor doctor = new Doctor(officeNum, speciality , name, surname , identicator, gender, nationality);

       doctor.setDoctorID(doctorIdCounter++);
       doctor.setDoctorCounter(doctorCounter++);
       
       doctor.addNewDoctorInHospital(doctor);
        return doctor;
        
    }
    
       public Patient GeneratePatient(boolean isHospitalised, String name, String surname, int[] identicator, Gender gender, Nationality nationality){
        
        Patient patient = new Patient(isHospitalised , name, surname , identicator, gender, nationality);
        
        patient.setPatientId(patientIdCounter++);
       patient.setPatientCounter(patientCounter++);
       
       patient.addNewPatientInHospital(patient);
        return patient;
        
    }
       
     
 //Set identicator 
     public int[] setIdenticator(){
         
        int[]ident = new int[1];
        //Identicators starts from 10 and goes up by 10 on object
       for(int i = 0 ; i < ident.length; i++){
           ident[i] = identicatorCounter + 10 ;
       }
        identicatorCounter += 10;
      return ident;
    }
     
     public boolean checkDateForDoctor(Doctor doctor,Date date){
         
         boolean a = true;
         
         for(int i = 0 ; i < Appointment.size() ; i++){
             //checks if date matches.
             for(int j = 0 ; j< Appointment.get(i).getDoctor().size() ; j++)
                if(Appointment.get(i).getDoctor().get(j) == doctor)
                 if(Appointment.get(i).getDate().equals(date) ){
                 a = false;
             
             
         }
         }
     
             return a;
    }
     
     
}