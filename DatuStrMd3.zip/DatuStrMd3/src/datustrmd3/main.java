
package datustrmd3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


public class main {

   
    public static void main(String[] args) throws IOException {
           /*  MyBinarySearchTree testTree = new MyBinarySearchTree();

        testTree.insert(25);
        testTree.insert(15);
        testTree.insert(10);
        testTree.insert(4);
        testTree.insert(12);

        testTree.preOrderDisplay();
        
        System.out.println("4: " + testTree.isElementInTree(4));
        testTree.delete(4);*/
       
      
        
        MyBinarySearchTree expTree = new MyBinarySearchTree();
        File file = new File("/home/nz/DatuStrMd3/exp");
        String st = null;
      
        Scanner sc = new Scanner(file); 
        st = sc.next();
        System.out.println(st); 
       
        
        String e = "(((2+4)*3)-8)";
        String e1 = expTree.infixToPostfix(st);
        //String e1 = expTree.infixToPostfix(e);
        
        MyTreeNode root = expTree.expressionTree(e1);
        expTree.inOrderDisplayHelper(root);
        System.out.println("Result of expression tree is " + expTree.calculatePostfixTree(e1));
         
        
        
    }
    
}
