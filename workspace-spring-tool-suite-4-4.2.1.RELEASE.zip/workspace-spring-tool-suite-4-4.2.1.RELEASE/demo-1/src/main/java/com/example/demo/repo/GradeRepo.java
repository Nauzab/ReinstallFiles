package com.example.demo.repo;

import java.util.ArrayList;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Course;
import com.example.demo.model.Grade;
			//Class name // ID data type can't be int so Integer it is
public interface GradeRepo extends CrudRepository<Grade, Integer> {

	ArrayList<Grade> findByCourse(Course course);
	
}
