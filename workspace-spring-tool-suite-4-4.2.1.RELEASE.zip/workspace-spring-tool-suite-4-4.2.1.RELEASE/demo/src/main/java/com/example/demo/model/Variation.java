package com.example.demo.model;

import java.util.ArrayList;

import com.example.demo.controllers.User;

public class Variation {
	private ArrayList<Integer> selectedNumbers = new ArrayList<Integer>();
	private User user;
	private int correctNumbers;
	
	public ArrayList<Integer> getSelectedNumbers() {
		return selectedNumbers;
	}
	public void setSelectedNumbers(ArrayList<Integer> selectedNumbers) {
		this.selectedNumbers = selectedNumbers;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Variation(ArrayList<Integer> selectedNumbers, User user) {
		super();
		this.selectedNumbers = selectedNumbers;
		this.user = user;
	}
	public int getCorrectNumbers() {
		return correctNumbers;
	}
	public void setCorrectNumbers(int correctNumbers) {
		this.correctNumbers = correctNumbers;
	}
	
	
	
	
}