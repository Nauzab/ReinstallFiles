/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author nz
 */
public class Variation {
    
    private int variationId = 0;
    private int correctNumbers = 0;
    private ArrayList<Integer> selectedNumbers = new ArrayList<>();
    private User user;

    public Variation() {
    }

    public Variation( int correctNumbers, ArrayList<Integer> selectedNumbers, User user) {
       variationId++;
        setVariationId(variationId);
        this.user = user;
        setCorrectNumbers(correctNumbers);
        setSelectedNumbers(selectedNumbers);
        
    }

    public int getVariationId() {
        return variationId;
    }

    public void setVariationId(int variationId) {
        this.variationId = variationId;
    }

    public int getCorrectNumbers() {
        return correctNumbers;
    }

    public void setCorrectNumbers(int correctNumbers) {
        this.correctNumbers = correctNumbers;
    }

    public ArrayList<Integer> getSelectedNumbers() {
        return selectedNumbers;
    }

    public void setSelectedNumbers(ArrayList<Integer> selectedNumbers) {
        this.selectedNumbers = selectedNumbers;
    }
    
    
    
    
    
}
