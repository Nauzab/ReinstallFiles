<?php
// creating connection
$d = mysqli_connect('localhost','worldread','worldreadPaSS','pasakums') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");



session_start();
    $log = $_SESSION["numurs"];
 //if pressed input button submit
   
if($_POST["submit"]){
    //If all inputs are filled
    if($_POST["valsts"] && $_POST["pilseta"] && $_POST["adrese"] && $_POST["norise"] && $_POST["datums"]
            && $_POST["laiks"] && $_POST["tips"] && $_POST["maksa"])
    {
    //Set veriables to input values by input names;
   $valsts = $_POST["valsts"];
   $pilseta = $_POST["pilseta"];
   $adrese = $_POST["adrese"];
   $norise = $_POST["norise"];
   $datums = $_POST["datums"];
   $laiks = $_POST["laiks"];
   $tips = $_POST["tips"];
   $maksa = $_POST["maksa"];
        //check if is possible to insert date, because of trigger 
        $sql10 = "INSERT INTO Pasakums(Datums) Values ('$datums')";
        //if is then insert other values
        if(mysqli_query($d,$sql10)){
                 //Check if input valsts is already in database
                $result = mysqli_query($d,"SELECT * FROM Valstis WHERE nosaukums = '$valsts' ");
                $count = mysqli_num_rows($result); //check if there are row that matches $result statement
                //if not then insert new input value
                if($count != 1){

            //Insert into database 
                $sql="INSERT INTO Valstis (Nosaukums)values('$valsts')";
                if (mysqli_query($d, $sql)) {
                }

            //check if pilseta is already in database
            $result1 = mysqli_query($d,"SELECT * FROM Adrese WHERE Pilseta = '$pilseta' ");
            $count1 = mysqli_num_rows($result1);
             if($count1 >= 1){
            $sql1= "INSERT INTO Adrese (Pilseta, Adrese) VALUES ('$pilseta','$adrese')"; 
            $sql2= "UPDATE Adrese SET ValstsID = (SELECT ID FROM Valstis WHERE Nosaukums = '$valsts') ORDER BY ID DESC LIMIT 1";   
            $sql3 = "UPDATE Adrese SET PilsetasID = GetPID('$pilseta') WHERE ID = AID()";
            //Insertions of table Pasakums
            $sql4 = "UPDATE Pasakums SET Norise = '$norise', Laiks = '$laiks', PasakumaTips = '$tips', Ieeja = '$maksa' WHERE ID = PaID()";
            $sql5= "UPDATE Pasakums SET ValstsID = (SELECT ID FROM Valstis WHERE Nosaukums = '$valsts') ORDER BY ID DESC LIMIT 1";
            $sql6 = "UPDATE Pasakums SET AdresesID =(SELECT ID FROM Adrese WHERE Adrese ='$adrese') ORDER BY ID DESC LIMIT 1";
            $sql7 = "UPDATE Pasakums SET LietotajaID = (SELECT LietotajaID FROM Kontakti WHERE TelefonaNr = '$log') ORDER BY ID DESC LIMIT 1";
                if ( mysqli_query($d,$sql1) && mysqli_query($d,$sql2) && mysqli_query($d,$sql3) && mysqli_query($d,$sql4)
                && mysqli_query($d,$sql5) && mysqli_query($d,$sql6) && mysqli_query($d,$sql7)) {
                    
                } else{
                    echo "<span style = 'color:red;'>Something went wrong..!</span>";
                        echo "Error: ". mysqli_error($d);
                }
        }
        //if there is no existing data in database for pilseta then execute esle statement.
        else{
            $sql1= "INSERT INTO Adrese (Pilseta, Adrese) VALUES ('$pilseta','$adrese')"; 
            $sql2= "UPDATE Adrese SET ValstsID = (SELECT ID FROM Valstis WHERE Nosaukums = '$valsts') ORDER BY ID DESC LIMIT 1";   
            $sql3 = "UPDATE Adrese SET PilsetasID = PID() WHERE ID = AID()";
            //Insertions of table Pasakums
            $sql4 = "UPDATE Pasakums SET Norise = '$norise', Laiks = '$laiks', PasakumaTips = '$tips', Ieeja = '$maksa' WHERE ID = PaID()";
            $sql5= "UPDATE Pasakums SET ValstsID = (SELECT ID FROM Valstis WHERE Nosaukums = '$valsts') ORDER BY ID DESC LIMIT 1";
            $sql6 = "UPDATE Pasakums SET AdresesID =(SELECT ID FROM Adrese WHERE Adrese ='$adrese') ORDER BY ID DESC LIMIT 1";
            $sql7 = "UPDATE Pasakums SET LietotajaID = (SELECT LietotajaID FROM Kontakti WHERE TelefonaNr = '$log') ORDER BY ID DESC LIMIT 1";
                if ( mysqli_query($d,$sql1) && mysqli_query($d,$sql2) && mysqli_query($d,$sql3) && mysqli_query($d,$sql4)
                && mysqli_query($d,$sql5) && mysqli_query($d,$sql6) && mysqli_query($d,$sql7)) {
                    
                } else { 
                    
                    echo "<span style = 'color:red;'>Something went wrong..!</span>";
                        echo "Error: ". mysqli_error($d);
                    
                }

        }

       
    }
    //if there are mathcing valsts values in database - use existing value.
    else{

        //check if pilseta is already in database
        $result1 = mysqli_query($d,"SELECT * FROM Adrese WHERE Pilseta = '$pilseta' ");
        $count1 = mysqli_num_rows($result1);
         if($count1 >= 1){
                $sql1= "INSERT INTO Adrese (Pilseta, Adrese) VALUES ('$pilseta','$adrese')"; 
                $sql2= "UPDATE Adrese SET ValstsID = (SELECT ID FROM Valstis WHERE Nosaukums = '$valsts') ORDER BY ID DESC LIMIT 1";   
                $sql3 = "UPDATE Adrese SET PilsetasID = GetPID('$pilseta') WHERE ID = AID()";
                //Insertions of table Pasakums
                $sql4 = "UPDATE Pasakums SET Norise = '$norise', Laiks = '$laiks', PasakumaTips = '$tips', Ieeja = '$maksa' WHERE ID = PaID()";
                $sql5= "UPDATE Pasakums SET ValstsID = (SELECT ID FROM Valstis WHERE Nosaukums = '$valsts') ORDER BY ID DESC LIMIT 1";
                $sql6 = "UPDATE Pasakums SET AdresesID =(SELECT ID FROM Adrese WHERE Adrese ='$adrese') ORDER BY ID DESC LIMIT 1";
                $sql7 = "UPDATE Pasakums SET LietotajaID = (SELECT LietotajaID FROM Kontakti WHERE TelefonaNr = '$log') ORDER BY ID DESC LIMIT 1";
            if ( mysqli_query($d,$sql1) && mysqli_query($d,$sql2) && mysqli_query($d,$sql3) && mysqli_query($d,$sql4)
            && mysqli_query($d,$sql5) && mysqli_query($d,$sql6) && mysqli_query($d,$sql7)) {
                
            } else { 
                echo "<span style = 'color:red;'>Something went wrong..!</span>";
                echo "Error: ". mysqli_error($d);
            
            }
        }
    //if there is no existing data in database for pilseta then execute else statement.
            else{
                $sql1= "INSERT INTO Adrese (Pilseta, Adrese) VALUES ('$pilseta','$adrese')"; 
                $sql2= "UPDATE Adrese SET ValstsID = (SELECT ID FROM Valstis WHERE Nosaukums = '$valsts') ORDER BY ID DESC LIMIT 1";   
                $sql3 = "UPDATE Adrese SET PilsetasID = PID() WHERE ID = AID()"; 
                //Insertions of table Pasakums
                $sql4 = "UPDATE Pasakums SET Norise = '$norise', Laiks = '$laiks', PasakumaTips = '$tips', Ieeja = $maksa WHERE ID = PaID()";
                $sql5= "UPDATE Pasakums SET ValstsID = (SELECT ID FROM Valstis WHERE Nosaukums = '$valsts') ORDER BY ID DESC LIMIT 1";
                $sql6 = "UPDATE Pasakums SET AdresesID =(SELECT ID FROM Adrese WHERE Adrese ='$adrese') ORDER BY ID DESC LIMIT 1";
                $sql7 = "UPDATE Pasakums SET LietotajaID = (SELECT LietotajaID FROM Kontakti WHERE TelefonaNr = '$log') ORDER BY ID DESC LIMIT 1";
                    if ( mysqli_query($d,$sql1) && mysqli_query($d,$sql2) && mysqli_query($d,$sql3) && mysqli_query($d,$sql4)
                    && mysqli_query($d,$sql5) && mysqli_query($d,$sql6) && mysqli_query($d,$sql7)) {
                       
                        
                    } else { 
                        echo "<span style = 'color:red;'>Something went wrong..!</span>";
                        echo "Error: ". mysqli_error($d);
                    
                    }

            }
        

    }

        }
        else{
            echo "Error: ". mysqli_error($d);
        }
   
        
        //If post is submitted without input then else section sends erro message.
    } else{
         echo "<span style = 'color:red;'> Error:Aizpildiet visas ailes!</span>";
          }
          
          
}
?>


<html>
<body background="images.jpeg">
<head>
    <meta charset="UTF-8">
    <title>Pievienošana</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 300px; padding: 20px; }
         h2{
             font-size:20px;
         }
         h3{
             font-size:20px;
             text-decoration:underline;
             color: grey;
         }
         p{
            text-decoration:underline;
         }
    </style>
<h1>Pievienot pasākumu</h1>
<h3>Ievēro:</h3>
<h2>Pievienojot pasākuma tipu ievērot:</h2>
<p>S(sporta) TK(Teatris/Kino) K(Koncerts) C(cits)</p>
<h2>Pievienojot Maksu ievērot:</h2>
<p>M(Maksas) B(Bezmaksas)</p>

<FORM ACTION="izveide.php" METHOD="POST">
<table>
<tr>
<td>Valsts:</td><td><input name="valsts" type="text" ></td>
</tr>
<tr>
<td>Pilseta:</td><td><input name="pilseta" type="text"></td>
</tr>
<tr>
<td>Adrese:</td><td><input name="adrese" type="text" ></td>
</tr>
<tr>
<td>Norise:</td><td><input name="norise" type="text" ></td>
</tr>
<tr>
<td>Datums:</td><td><input name="datums" type="text" ></td>
</tr>
<tr>
<td>Laiks:</td><td><input name="laiks" type="text" ></td>
</tr>
<tr>
<td>Pasakumu tips:</td><td><input name="tips" type="text" ></td>
</tr>
<tr>
<td>Maksa:</td><td><input name="maksa" type="text" ></td>
</tr>
</table>
 <input type="submit" name = "submit" value="Pievienot"/>
              <div id = "Login" >
           
            
           <a href="logout.php">Iziet</a><br>
               
           
           <a href="pasakums.php">sakums</a>
               
           </div>
            
        </form>
    </div>    
</body>
</html>