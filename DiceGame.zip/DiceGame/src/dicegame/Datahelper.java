/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dicegame;

/**
 *
 * @author nz
 */
public class Datahelper {
	private String datahelper;

	public String getDatahelper() {
		return datahelper;
	}

	public void setDataHelper(String datahelper) {
		this.datahelper = datahelper;
	}

	public Datahelper(String datahelper) {
		this.datahelper = datahelper;
	}

	public Datahelper() {
	}
	
	
	
	
	
}