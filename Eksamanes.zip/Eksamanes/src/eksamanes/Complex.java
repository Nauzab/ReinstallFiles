
package eksamanes;


public class Complex {
    
    private  double re =0;   
    private  double im= 0;   

    
    
    public Complex() {
    }

   
   
    public Complex(double real, double imag) {
        re = real;
        im = imag;
    }

   public double getRe(){
       return re;
   }
   public double getIm(){
       return im;
   }
   
    public String toString() {
        if (im == 0) return re + "";
        if (re == 0) return im + "i";
        if (im <  0) return re + " - " + (-im) + "i";
        return re + " + " + im + "i";
    }
    
    public Complex times(Complex b) {
        Complex a = this;
        double real = a.re * b.re - a.im * b.im;
        double imag = a.re * b.im + a.im * b.re;
        return new Complex(real, imag);
    }
    
   
}
