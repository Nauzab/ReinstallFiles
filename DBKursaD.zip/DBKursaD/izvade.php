<?php
# Veidojam savienojumu ar savu serveri un datu bāzi
$d = mysqli_connect('localhost','worldread','worldreadPaSS','pasakums') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");


#Valsts Izvele;
$query = "SELECT * FROM Valstis;";
$result1 = mysqli_query($d,$query);

?>

    <html>
        
            <head >
            <link rel="stylesheet" href="pasakums.css" type="text/css" >
           
            <title background="event.jpg" >Pasakuma kalendars</title> 
            </head>
            <script type = "text/javascript " src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.min.js"></script>
            <script>

            function getState(val){
               $.ajax({
                   type:"POST",
                   url: "state.php",
                   data: 'ID= ' + val,
                   success: function(data){
                       $("#state-list").html(data);
                   }
               });
            }
            </script>
            <script>
            function showMsg()
            {
                $("#msgC").html($("#country-list option:selected").text());
                $("#msgS").html($("#state-list option:selected").text());
                return false;
            }

            </script>
          <body background="images.jpeg">
            <h1>Pasakuma kalendars</h1> 
            <form mothod = "post" action = "izvade.php">
               <p>Atlasit pasakumu :
                <!--Izveido valsts izveli -->
                <label> Valsts: </label>
            <select id = "country-list" onChange = "getState(this.value);"> 
            <option value = "">select country </option>
            <?php 
            $sql = "SELECT * FROM Valstis ;";
            $result = mysqli_query($d,$sql);
            while($rs = mysqli_fetch_array($result)){
                ?>
                <option value = "<?php echo $rs["ID"];?>"> <?php echo $rs["1"];?> </option>
                <?php
            }
            ?>
                 </select>
                 <label> Pilseta: </label>
                 <select id = "state-list">
                 <option value = "">Select city </option>
                  </select>
                  <button value = "submit" onClick = "return showMsg();">Submit </button>
                
                 
                         </form> </p>
                          
                         
                         
                
                


<?php

function tabula($sql_res) {
$first = true;
echo "<center><table class=\"schedule\">";
while ($row = mysqli_fetch_assoc($sql_res)) {
    if ($first) {
        echo "<tr>";
        foreach ($row as $k=>$v) {
            echo "<th>$k</th>";
        }
        echo "</tr>".PHP_EOL;
        $first = false;
    }
    echo "<tr>";
        foreach ($row as $v) {
            echo "<td>$v</td>";
        }
        echo "</tr>".PHP_EOL;
}
echo "</table></center>";

$row_cnt = mysqli_num_rows($sql_res);

/* close result set */
mysqli_free_result($sql_res);
}

?>


<?php

/* Nākamais bloks */

echo "<h3>Pasakuma/u ievietotajs</h3>";


$sql="SELECT l.Vards, l.Uzvards , k.Epasts , k.TelefonaNr from Lietotajs l JOIN Kontakti k ON l.ID = k.LietotajaID WHERE l.ID = 7";
echo "<!-- $sql -->";
$sql_res = mysqli_query($d,$sql) or die("<h1>".mysqli_error()."</h1>");
tabula($sql_res);

echo "<h3>Pasakums/i</h3>";
?>
                        <ul>
                            <li><a href="#">Rediģēt atzimeto pasākumus</a></li> 
                            </ul>
                            <ul>
                            <li><a href="#">Dzest atzimeto Pasakumu</a></li> 
                            </ul>
                            
<li><a href="#"><?php $sql="SELECT p.norise ,p.laiks,p.datums ,p.ieeja, p.PasakumaTips, v.nosaukums as valsts, a.pilseta, a.adrese  FROM Pasakums p JOIN Valstis v ON p.ValstsID = v.ID JOIN Adrese a ON p.AdresesID = a.ID WHERE p.LietotajaID = 7";
echo "<!-- $sql -->";
$sql_res = mysqli_query($d,$sql) or die("<h1>".mysqli_error()."</h1>");
tabula($sql_res);
?></li>


   </body>
    </html>


  