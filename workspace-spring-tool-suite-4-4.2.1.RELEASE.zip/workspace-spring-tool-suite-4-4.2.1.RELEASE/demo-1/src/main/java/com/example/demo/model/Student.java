package com.example.demo.model;


import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name ="StudentTable")

public class Student {
	@Column(name= "Name")
	private String name;
	@Column(name = "Surname")
	private String surename;
	
	@Id //id can't be null
	@GeneratedValue(strategy = GenerationType.AUTO) //auto generating id
	@Column(name = "Id_s")
	private int id_s;
	
	@OneToMany(mappedBy = "student")
	private Collection<Grade> grades;//collection of grades
	
	
	
	public Student(String name, String surename) {
		super();
		this.name = name;
		this.surename = surename;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSurename() {
		return surename;
	}
	public void setSurename(String surename) {
		this.surename = surename;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return  name + " " + surename;
	}
	public int getId() {
		return id_s;
	}
	public void setId(int id_s) {
		this.id_s = id_s;
	}
	public Student() {
		super();
	}
	
}
