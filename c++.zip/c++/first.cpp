#include <iostream>

using namespace std;


int main() {
        int x = 5,c = 3,y = 2;

        int mas[10] = {0};
        for(int i = 0 ; i < sizeof(mas);i++){
        if(i == x) {
        mas[i] = x ;}
        else if ( i == c ) {
        mas[i] = c; }
        else if(i == y){
        mas[i] = y;}
        else{
        mas[i] = 0;}

        }

}
