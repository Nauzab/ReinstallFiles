
package DatuSreSem1;

import DatuSreSem1.MyInteger;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;


/**
 *
 * @author nz
 */
public class Saraksts<T> {
    private Class<T> value;
    private int skaititajs;
    private List<T> saraksts = new ArrayList();
    private int elementCount = 0; 

    
    public Saraksts( int skaititajs){  
        
        this.skaititajs = skaititajs;
        saraksts = new ArrayList(skaititajs);
        elementCount = 0 ;        
        
    }
    
    public List getList(){
        return saraksts;
    }

  
    
    //Check if list is full
    public boolean CheckIfListsIsFull(){
        //If elementcount equals to the size of list then return true as full
        if(elementCount == skaititajs){
            return true;
        }
        else{
            return false;
        }
            
       
    } 
    
    //Check if list is empty
    public boolean CheckIfListsIsEmpty(){
        //if elementCount equals to 0 then return true as empty
        return(elementCount == 0)?true:false;
    }
    
    //Returns how many elements is initialize in list;
    public int getElementsCount(){
        
        return elementCount;
        
    }
    
    //Returns array with 2 time the size of constructur created array  
    public List SetTwoTimesArray(){
        
         List<T> NewSaraksts = new ArrayList(skaititajs);
         //Check if skaititajs is not bigger or equal to 100
        if(skaititajs >=100){
            //Set NewSkaititajs 1.5 times bigger
           int NewSkaititajs = (skaititajs * 2) - (skaititajs/ 2);// 
            NewSaraksts = new ArrayList(NewSkaititajs);
            
        }else{
            //else set NewSaraksts 2 times bigger
            NewSaraksts = new ArrayList(skaititajs * 2);
        }
        
        //Copy the list into newList
        for(int i = 0 ; i < skaititajs ; i++){
            NewSaraksts.add(i,saraksts.get(i));
        }
        
       return NewSaraksts;
    }
    
    //Add element to last index of array
    public boolean AddElementToEnd(T element){
      
            if(CheckIfListsIsFull()){
                System.out.println("List is full: cannot add element");
                return false;
            }
            else{
                
                saraksts.add(elementCount++,element);
                return true;
                
            }
    }
    
    //Add element based on array index
    public boolean AddElementByIndex(int index,T element) {
        //Check if index is in range of array 
        if(index >= skaititajs || index < 0){
            System.out.println("Unable to add element:\n Error:Incorrect Index");
            return false;
        }
        //Check if list is full already
        else if(CheckIfListsIsFull()){
            System.out.println("Unable to add element list is full");
            return false;
        }
        else{
            //Make space for new value 
            for(int i = index ; i <elementCount-1; i++){
                saraksts.set(i,saraksts.get(i));
            }
            saraksts.add(index,element);//Add element in index possition
           elementCount++;
                    return true;
        }

    }
    
  //Delete element by index
    public boolean deleteElement(int index){
        //Check if index is in range of array 
        if(index > skaititajs || index < 0){
            System.out.println("Unable to delete element:\n Error:Incorrect Index");
            return false;
        }
        else if(CheckIfListsIsEmpty()){
            return false;
        }
        else{
           saraksts.remove(index);
           elementCount--;
           return true;
        }
        
    }
    
    //Get element by index
    public T getElementByIndex(int index){
        
        //Check if index is in range of array 
        if(index > saraksts.size() || index < 0 ){
            System.out.println("Unable to get element:\n Error:Incorrect Index");
            return null;
        }else if(CheckIfListsIsEmpty()){
            System.out.println("List is empty");
            return null;
        }
        else{
            return saraksts.get(index);
        }
    }
    
    //Find element
    ///Help needed Here ---------------------------------------------------------
    public boolean SearchForElement(T element){
        boolean a = false;
        int found = 0 ;
        MyInteger inte = null;
        if(!CheckIfListsIsEmpty()){
                  
         inte.SearchForIntElement(element, saraksts);
        }else{
            System.out.println("List is empty");
            a=false; 
        }
        
    return a;
}
    
    //Returns next element from given element
    public T nextElement(T element){
        T a = null ;
        for(int i = 0 ; i < skaititajs -1; i++){
            if(element == saraksts.get(i) ){
                a = saraksts.get(i+1);
            }
        }
        if(a == null){
            System.out.println("Element was not found. ");
            return a;
        }return a;
    }
    
    //Array Sort Sorted from biggest to smallest
    
    //Help needed here -------------------------------------------------------------
   public void SortArray(){
       
      
        T temp;//temp element
        for(int i = 0 ; i < skaititajs;i++){
            for(int j = 0 ; j < skaititajs;j ++){
                //Check if next element is bigger
                if(saraksts.get(i).compareTo(saraksts.get(j))>0 ){
                    //changing  places 
                    temp = saraksts.get(i);
                    saraksts.set(i, saraksts.get(j));
                    saraksts.set(j,temp);
                }
            }
        }
    }
    
    //Take out all elements from list
    public void MakeEmpty(){
        saraksts.clear();
    }
    
    //Print the List
    public void PrintList(){
        
       System.out.println(Arrays.toString(saraksts.toArray()));
    }
  
}
