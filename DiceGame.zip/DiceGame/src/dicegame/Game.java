
package dicegame;

import java.util.Scanner;


/**
 *
 * @author nz
 */
public class Game {
         
    
    
    
    public static void main(String[] args) {
            
        Computer comp = new Computer();
        Thousand c1 = new Thousand(comp);
        
        Player pl = new Player("Zaps");
        Thousand p1 = new Thousand(pl);
        int chosen = 0;
        
     
        while(c1.getPoints() <= 1000 || p1.getPoints() <=1000){ 
            int turn = 3; //Round turns 
            System.out.println("Your turn " + p1.getPlayer().getName());
            p1.setElementCount(5);
            while(turn != 0){ //Player turn
                
               p1.rollDices();
               p1.printRolledDices(); 
               System.out.println("\nChoose witch rolls you would like to keep!\n Enter number ");
               
               do{
                    Scanner choise = new Scanner(System.in);
                     chosen = choise.nextInt();
                     if(chosen > 0){
                        System.out.println( p1.diceChoise(chosen)); 
                        p1.printRolledDices();
               
                    }
               }while(chosen != 0);
               p1.clearRolledDices();
               
                turn--;
            } 
                System.out.println("Round points: " + p1.getTempPoints());
                p1.setPoints(p1.getTempPoints());
                System.out.println("Total points: " + p1.getPoints());
                p1.clearChosenDices();
                
                turn = 3;
                 c1.setElementCount(5);
               while(turn != 0){
                   
                    c1.rollDices();
                    c1.printRolledDices();

                do{    

                  chosen = comp.choice(c1.getRolledDices());
                 if(chosen > 0){
                   
                    System.out.println( c1.diceChoise(chosen)); 
                    c1.printRolledDices();
                 }

                 }while(chosen != 0);

               
               c1.clearRolledDices();


             turn--;
             }
                System.out.println("Round points: " + c1.getTempPoints());
                c1.setPoints(c1.getTempPoints());
                System.out.println("Total points: " + c1.getPoints());
                c1.clearChosenDices();
      }
        
        
       
       
   }
                 
}
    

