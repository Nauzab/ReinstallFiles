
package mylinkedqueue;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author nz
 */
public class main {

   
    public static void main(String[] args) throws FileNotFoundException {
       /* Queue rinda = new Queue(5);
        if(!rinda.isFull()){ //while queue isn't full
            rinda.enqueue('A');
            rinda.enqueue('B');
            rinda.enqueue('C');
            rinda.enqueue('D');
            rinda.print();
            
            rinda.dequeue();
            rinda.print();
            rinda.dequeue();
            rinda.print();
            
            rinda.clearQueue();
            rinda.print();
        }
        
        rinda.generateNumber();
        
        Queue newRinda = new Queue(3);
        newRinda.queueFunction(newRinda.isFull()); 
        newRinda.queueFunction(newRinda.isEmpty());
        newRinda.queueFunction(newRinda.returnCounter());
       
        newRinda.print();
       
       //Stack
       Stack stack = new Stack(5);
       stack.push('a');
       
       System.out.println("At top: " +stack.top() );
       stack.push('b');
       stack.push('c');
       System.out.println("At top: " +stack.top() );
       stack.pop();
       System.out.println("At top: " +stack.top() );
       stack.push('d');
       stack.push('e');
       stack.push('f');
       System.out.println("At top: " +stack.top() );
       stack.push('g');
       System.out.println("At top: " +stack.top() );
       stack.pop();
       stack.push('h');
       System.out.println("At top: " +stack.top() );
       
       
       //Stundet scanner
       
       File fileName = new File("/home/nz/Downloads/grades.txt");
       Scanner scan = new Scanner(fileName);
       float grade;
       String name;
       float temp = 0;
       Stack stack = new Stack(10);
       Student student = new Student();
       while(scan.hasNextLine()){ 
               grade = scan.nextFloat();
               name = scan.nextLine();
           if(temp < grade){
               temp = grade;
               stack.makeEmpty();
               //student = new Student(grade, name);
               stack.push(name);
           }else if(temp == grade){
               stack.push(name);
           }else{
               continue;
           }
           
           
       }
       System.out.println("Highest GPA = " + temp + "\nStudents with highest GPA:");
       stack.print();
       
       File fileName = new File("/home/nz/MyLinkedQueue/src/mylinkedqueue/Student.java");
       Stack stack = new Stack(100);
       System.out.println(stack.Syntax(fileName));
       
       
       
       MyLinkedStack stack = new MyLinkedStack();
       
      stack.push(20);
      stack.push(23);
      stack.push(11);
      
      stack.display();
     
      stack.pop();
      stack.display();
      System.out.println("\n" + stack.top());
        
        */
    }
       
       
    
    
    
}
