package com.example.demo.model;

import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "CourseTable")
public class Course {	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id_c")
	private int id_c;
	
	@Column(name = "Title")
	private String title;
	@Column (name = "Cp")
	private int cp;
	
	@OneToOne //sasaiste ar prof table
	@JoinColumn(name = "Id_p")
	private Professor professor;
	
	@OneToMany(mappedBy = "course")
	private Collection<Grade> gradesInCourse;//collection of grades
	
	public int getId_c() {
		return id_c;
	}
	public void setId_c(int id_c) {
		this.id_c = id_c;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String Title) {
		this.title = Title;
	}
	public int getCp() {
		return cp;
	}
	public void setCp(int cp) {
		this.cp = cp;
	}
	public Professor getProfessor() {
		return professor;
	}
	public void setProfessor(Professor professor) {
		this.professor = professor;
	}
	public Course(String Title, int cp, Professor professor) {
		super();
		this.title = Title;
		this.cp = cp;
		this.professor = professor;
	}
	public Course() {
		super();
	}
	
	
}
