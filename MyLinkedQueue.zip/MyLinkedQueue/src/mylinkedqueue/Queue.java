
package mylinkedqueue;

import java.util.Random;

/**
 *
 * @author nz
 */
public class Queue<T> {
    private int rear; //rear element
    private int front ; //Front element
    private int size =0; //Array size
    private int counter = 0 ; //element counter
    private T[] array  ; //Array
    
    public Queue(int size){
        if(size >=0){//Check if inserted size is bigger or euqual to 0
            this.size = size;
        }else{
            this.size = 1;
        }
        
        this.array = (T[]) new Object[size]; //Creating T element array
        this.counter = 0 ;
    }
    
    public boolean isEmpty(){ //Check if queue is empty
        if(rear == 0){
            return true;
        }else{
            return false;
        }
    }
    
    public boolean isFull(){ //check if queue is full 
        if(rear == size){
            return true;
        }else{
            return false;
        }
    }
    
    public int returnCounter(){//returns how many elements is in queue
        return counter;
        
    }
    
    public void enqueue( T item){ //Adding element to queue
        if(isFull()){//check if queue is full
            System.out.println("Queue is full");
        }
        else{
            array [rear] = item; //Add element in that possition or last in queue
            rear++; //Move rear position by one 
            counter++; //Element counter
        }   
    }
    
    public T dequeue(){ //Remove element for queue
        if(isEmpty()){ //chekc if queue is empty
            System.out.println("Queue is empty");
            return null;
        }else{
            T item = array[0]; //Initialize with queue priority element
            for(int i = 0; i < rear; i++){ //goes trougth queue
                array[i] = array[i+1]; //moves all elments by one possition to front
            }
            rear--; //decrease rear
            counter--; //decrease counter
            return item; //return priority element witch is removed
        }
        
    
    }
    
    public void print(){ //Prints queue
        for(int i = 0 ; i < counter ; i++){
            System.out.print(array[i] +" ");
        }System.out.println();
    }
    
    public void clearQueue(){ //Clears queue
        rear = 0;
        counter = 0 ;
    }
    
    public void generateNumber(){ //Genare emergancy nummber
        Queue rinda = new Queue(5);
        Random r = new Random();
        int temp = 0;
        while (temp != 5){
            int index = r.nextInt(6) + 110; //generate from 0 to 5 addind 100 for number
            rinda.enqueue(index); //Addind number to the queue
            temp++;
        }
        
        
        System.out.print("Trying to call... " );
        rinda.print();
    }
    
    public void queueFunction(T function){ //Function that inputs queue elements as functions
        enqueue(function);
    }
}
