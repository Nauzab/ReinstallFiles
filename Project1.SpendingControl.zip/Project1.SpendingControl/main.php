<?php
  // Create connection with database
  $d = mysqli_connect('localhost','Nz','SpentCalc','SpenC') or die('Can not connect to database');
  $chs=mysqli_set_charset($d, "utf8");

  //start session 
  session_start();
?>

<!--WEB PAGE -->
<!DOCTYPE html>
<html>
<title>Personal Website</title>
<link rel="stylesheet" href="main.css" type="text/css" >
<body>
<div class = "body">
<!--Buttons-->
<div class = "button">
    <?php
    //if username has not set yet, then echo login/singin buttons with popfunction 
    if(!isset($_SESSION['username'])){
        //LOGIN button
    $value = '"modal-wrapper"'; 
    echo "<button onclick='popfunction($value)' >
    Log in</button> ";

     /* SING UP button  
    $value1 = '"modal-wrapper1"'; //id for sing up 
    echo "<button onclick='popfunction($value1)'>
    Sing up</button> ";*/
    }

    else{
        //LOGOUT button
        echo "<form><button class = 'logout' formaction = 'logout.php' >Leave</button></form>";

    }
    ?>
</div>

<!--Buttons realizations -->
<div id="modal-wrapper" class="modal">
  
  <form class="modal-content animate" action="Login.php" method = "POST">
    <div class="container">   

      <input type="text" placeholder="Enter Username" name="username">
      <input type="password" placeholder="Enter Password" name="password">        
      <input type="submit" name = "Lsubmit" value = "Login"><br>

    </div>
    
  </form>
</div>

<!--Icon -->
<section id="section3" class="demo">
  
 <?php 
  if(isset($_SESSION['username'])){

  
  ?>
  <div class = "imgconteiner">
  <img src="avatar.jpg" alt="Avatar" class="avatar"> 
  <a  href="#section3"><span></span><img src = "arrow.png" alt = "Arrow" class= "arrow"></a><br>
  <?php echo "<p class = 'p'>",$_SESSION['username'], "</p>"?>
  </div>
 <?php
  }
 ?>
</section>

<!-- Calculator Button -->
<section id="section" class="demo">
  <a class = "Cbutton" href="#section2"><span></span>Calculator</a>
</section>

<!--Social FB/IG  infomations imges. -->
<div class = "contact">
  <a class = "soc" href = "https://www.facebook.com/nauris.zablovskis.3"  > <img src="fb.png" class = "soc"> </a>
  <a class = "soc" href = "https://www.instagram.com/zaps_lv/"> <img src = "ing.png" class = "soc" ></a>
</div>
</div> <!-- Body class -->

<!--Calculator divisio -->
<section id="section2" class="demo">
  <?php
  if(isset($_SESSION['username'])){

  ?>
  <form class  = 'Userform' action = 'Index.php' method = 'POST'>
   <div class = "index">
    <div class = 'Cinput'>
      
      <input class = 'input'   name='amount' type='text' placeholder = 'Amount' required>
      <input name = 'asubmit'  type = 'image' src = 'calc.png' required></p>
      
      <input class = 'input' name='spent' type='text'   placeholder = 'Spences' required >
      <input name = 'ssubmit' type = 'image' src = 'calc.png' required></p>
    </div>
    <div class="Table">
         
         <?php
         $sql = "SELECT s.id as 'Purchase', s.Spent, left(s.date,10) as date ,s.Aleft as 'Left' from spenc s JOIN User u ON Uid = u.id order by Purchase DESC";  
         $sql_res = mysqli_query($d,$sql) or die("<h1>".mysqli_error()."</h1>");
         table($sql_res);
        ?>
     </div>
  
    </form>
    <?php
    }
    else{
    ?>
      <div class = "text">
        You have to be loged in
      </div>
    <?php
    }
    ?>
</section>
<!--Footer-->
<div><footer>@Created by Nz 2019 </footer></div>
  
</body>
<!--Function for Login/Singup -->
<script class ='function'>
  // If user clicks anywhere outside of the modal, Modal will close
  //For login
  var modal = document.getElementById('modal-wrapper');
  //For sing up 
  var modal1 = document.getElementById('modal-wrapper1');
  //For user info / USERFORM FORM
  var modal2 = document.getElementById('modal-wrapper2');
  
  window.onclick = function(event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
    if(event.target == modal1){
      modal1.style.display = "none";
    }
    if(event.target == modal2){
      modal2.style.display = "none";
    }
  };
  
  function popfunction(parameter){
      document.getElementById(parameter).style.display = "block";
  }
</script>

<!--Function for Scrolling down -->
<script>
  $(function() {
  $('a[href*=#]').on('click', function(e) {
    e.preventDefault();
    $('html, body').animate({ scrollTop: $($(this).attr('href')).offset().top}, 500, 'linear');
  });
 });
</script>

<!--Function that prints resaults from database-->
<?php
 function table($sql_res){
    echo "<center><table class=\"table\">";
    $first = true;
    while ($row = mysqli_fetch_assoc($sql_res)) {
        if ($first) {
            echo "<tr>";
            foreach ($row as $k=>$v) { 
                
                echo  "<th>$k</th>";
            
            }
            echo "</tr>".PHP_EOL;
            $first = false;
        }
        echo "<tr> ";
        
            foreach ($row as $v) {
                echo "<td>$v</td>";
                
            }
            
            echo "</tr>".PHP_EOL;
            
    }
    
    
    echo "</table></center>";
    
    $row_cnt = mysqli_num_rows($sql_res);
    
    /* close result set */
    mysqli_free_result($sql_res);
 }
?>
</html>



