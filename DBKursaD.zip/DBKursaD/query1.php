<?php
if (get_magic_quotes_gpc()) {
    function stripslashes_deep($value)
    {
        $value = is_array($value) ?
                    array_map('stripslashes_deep', $value) :
                    stripslashes($value);
        return $value;
    }

    $_POST = array_map('stripslashes_deep', $_POST);
    $_GET = array_map('stripslashes_deep', $_GET);
    $_COOKIE = array_map('stripslashes_deep', $_COOKIE);
    $_REQUEST = array_map('stripslashes_deep', $_REQUEST);
}

if (!isset($_GET['query'])) {
    $_GET['query'] = "SHOW TABLES;";
}

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<form action="query1.php" type="GET">
<textarea style="width: 93%;" cols="100" rows="10" name="query"><?php echo $_GET['query']; ?></textarea> <input type="submit" />

<?php
$conn=  mysqli_connect('localhost','worldread','worldreadPaSS','pasakums');
/* change character set to utf8 */
$chs=mysqli_set_charset($conn, "utf8");

$r = mysqli_query($conn,$_GET['query']) or die("<h1>".mysqli_error($conn)."</h1>");
$first = true;
echo "<center><table class=\"schedule\">";
while ($row = mysqli_fetch_assoc($r)) {
    if ($first) {
        echo "<tr>";
        foreach ($row as $k=>$v) {
            echo "<th>$k</th>";
        }    
        echo "</tr>";
        $first = false;
    }
    echo "<tr>";
        foreach ($row as $v) {
            echo "<td>$v</td>";
        }
        echo "</tr>";
}
echo "</table></center>";
mysqli_close($conn);

?>
