
package DatuSreSem1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author nz
 */
public class Main {
    
     public static void main(String[] args) throws FileNotFoundException {
        //Scanner veriable for scnannig files
       Scanner scanner = new Scanner(new File("numbers.txt"));
       Saraksts saraksts = new Saraksts(7);
       
       //Add file elements to list 
       System.out.println("Adding elements to the list from file....");
        MyInteger inte=null;
       while(scanner.hasNextInt() ){
           //Check if list is not full if is break the while loop
           if(!saraksts.CheckIfListsIsFull()){
               inte = new MyInteger(scanner.nextInt());
              saraksts.AddElementToEnd(inte); 
           }else{
               break;
           }
           
       }
       
      
       
       
      
       
      
      
    }
}
