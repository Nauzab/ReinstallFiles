package com.example.demo.model;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;


public class Lingo extends Player{
    
    private final String[] words = {"SKAPIS", "AKMENS" , "ASMENS", "ZIBENS", "MENESS", "MEDUS",
    "GALDS", "PAVARDS", "REKORDS", "STRAZDS", "ZVIRGZDS", "DRAUGS", "KAROGS",
    "ZIEDS", "ZIRGS", "KUNGS", "MIEGS", "PARAUGS", "LAUKS", "IENAIDNIEKS",
    "RAKSTNIEKS"};
    
    private int points = 0;
    private int guesses;
    private int life = 3;
    private String corretcWord;
    private String guessWord;
    private String shuffled = "";
    private char[] guessChar;
    private int index = 0;
    private String guessedChar;
    public Lingo(){
        
    }
    
    public Lingo(String name){
    	super(name);
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
       this.points = points;
        
    }

    public int getGuesses() {
        return guesses;
    }

    public void setGuesses(int guesses) {
        this.guesses = guesses;
    }
    
    public String getGuessWord() {
        return guessWord;
    }
    
   
    public String getGuessedChar() {
		return guessedChar;
	}

	public void setGuessedChar(String guessedChar) {
		this.guessedChar = guessedChar;
	}

	public void setGuessWord(String guessWord) {
        this.guessWord = guessWord;
    }
    
    public void clearGuessChar() {
    	this.guessChar = null;
    }
    public int getLife() {
        return life;
    }

    public void setLife(int life) {
        this.life = life;
    }
    public String getCorrectWord() {
        return corretcWord;
    }

    public void setCorrectWord(String correctWord) {
        this.corretcWord = correctWord;
    }
    public String getRandomWord(){
        Random ran = new Random();
        int n = ran.nextInt(words.length);
        
        String word = words[n];
        setCorrectWord(word);
        return word;
    }
    
   public String shuffleWord(String word){
	   shuffled = " ";
         List<String> letters = Arrays.asList(word.split(""));
        Collections.shuffle(letters);
        
        for (String letter : letters) {
          shuffled += letter;
        }
        return shuffled;
        
      
    } 
   public String getShuffleWord() {
	   return shuffled;
   }
   
   public String Upper(String inputWord){
       return inputWord.toUpperCase();
   }
  
   
   
   public void printInfo(){
       System.out.println("Life: " + getLife() + "\nPoints: " + getPoints());
   }
   
    
    
}
