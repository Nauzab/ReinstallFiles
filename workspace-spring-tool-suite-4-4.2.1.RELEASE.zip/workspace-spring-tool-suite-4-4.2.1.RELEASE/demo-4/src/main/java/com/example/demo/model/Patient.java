/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "Patient")
public class Patient extends User{
	

        
		@Column(name = "Name")
        private String name;
		@Column(name = "Surname")
        private String surname;
        
        @Column(name = "isHospitalised")
        private boolean isHospitalised = false;
        
        @OneToOne(mappedBy = "patient")
        private Appointment appointment;
        
        
        @OneToOne
    	@JoinColumn(name = "Id_u")
        private User user;
        
        private int patientId ;
        private static int patientCounter = 1;

        
        
    public Patient() {}
    
    public Patient(boolean isHospitalised, String name, String surname, String username , String password) {
    	super(username, password);
        this.isHospitalised = isHospitalised;
        this.name = name;
        this.surname = surname;
        this.patientId = patientCounter;
        patientCounter++;
    }

        
    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public int getPatientCounter() {
        return patientCounter;
    }

    public void setPatientCounter(int patientCounter) {
        this.patientCounter = patientCounter;
    }
    
    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public boolean isIsHospitalised() {
        return isHospitalised;
    }

    public void setIsHospitalised(boolean isHospitalised) {
        this.isHospitalised = isHospitalised;
    }

    @Override
    public String toString() {
        return   "Patient{" + "patientId=" + patientId + ", patientCounter=" + patientCounter + ", isHospitalised=" + isHospitalised + '}';
    }
        
        
    
}
