/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package md1;

import java.util.Arrays;

/**
 *
 * @author nz
 */
public class Person extends Hospital {
    private String name;
    private String surname;
    private int[] identicator;
    private Gender gender;
    private Nationality nationality;

    
     public Person() {
       
    }
    
     
    public Person(String name, String surname, int[] identicator) {
        setName(name);
        setSurname(surname);
        setIdenticator(identicator);
    }

    public Person(String name, String surname, int[] identicator, Gender gender, Nationality nationality) {
        this.name = name;
        this.surname = surname;
        this.identicator = identicator;
        setNationality(nationality);
        setGender(gender);
        
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public int[] getIdenticator() {
        return identicator;
    }

    public void setIdenticator(int[] identicator) {
        if(identicator != null)
        this.identicator = identicator;
        
    }

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        
        //set check to last char at name
        char check = name.charAt(name.length() - 1);
        
        if( check == 'e' || check == 'a'){
            if(nationality.equals(Nationality.Latvian)  && gender.equals(Gender.Famele)){
                this.gender = gender.Famele;
            }
            
        }else if(check == 's' && nationality == Nationality.Latvian && gender == Gender.Male){
            this.gender = gender.Male;
        }else if ( nationality.equals(Nationality.Estonian)){
            this.gender = gender;
        }
        else{
            this.gender = Gender.Unset;
        }
        
    }
    
    

    public Nationality getNationality() {
        return nationality;
    }

    public void setNationality(Nationality nationality) {
        
        //Just to show that i know , but check is not needed here because it's enum .
        this.nationality = (nationality == Nationality.Latvian || nationality == Nationality.Estonian)?nationality:Nationality.Unset;
    }

    
    @Override
    public String toString() {
        return "Person{" + "name=" + name + ", surname=" + surname + ", identicator=" + Arrays.toString(identicator) + ", gender=" + gender + ", nationality=" + nationality + '}';
    }
    
    
    
}


    