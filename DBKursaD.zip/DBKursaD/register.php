<?php
// Include config file
$d = mysqli_connect('localhost','worldread','worldreadPaSS','pasakums') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");
 


 session_start();
if($_POST["name"] && $_POST["surname"] && $_POST["email"] && $_POST["numurs"] )
{
   $name = $_POST["name"];
   $surname = $_POST["surname"];
   $email = $_POST["email"];
   $number = $_POST["numurs"];
    
   

    $sql="INSERT INTO Lietotajs (Vards,Uzvards)values('$name','$surname')";
    $sql1= "INSERT INTO Kontakti (Epasts, TelefonaNr) VALUES ('$email','$number')"; 
    $sql2= "UPDATE Kontakti SET LietotajaID = (SELECT MAX(ID) FROM Lietotajs) ORDER BY ID DESC LIMIT 1";   
   
      
    if (mysqli_query($d, $sql) && mysqli_query($d,$sql1) && mysqli_query($d,$sql2)) {
        $_SESSION['numurs'] = $number; 
        header("Location: izveide.php");
    } else {
        echo "Error: ". mysqli_error($d);
        echo "Something went wrong..!";
    }
    
}



?>
 
<!DOCTYPE html>
<html lang="en">
<body background="images.jpeg">
<head>
    <meta charset="UTF-8">
    <title>Reģistrēties</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
    </style>
<h1>Reģistreties</h1>
<FORM ACTION="register.php" METHOD="POST">
<table >
<tr>
<td>Vards:</td><td><input name="name" type="text" ></td>
</tr>
<tr>
<td>Uzvards :</td><td><input name="surname" type="text"></td>
</tr>
<tr>
<td>Epasts</td><td><input name="email" type="email" ></td>
</tr>
<tr>
<td>Telefona numurs :</td><td><input name="numurs" type="text" ></td>
</tr>
</table>
 <input type="submit" value="registreties"/>

 <div id = "Login" >
           
            <a href="pasakums.php">sakums</a>
           
               <br>
           <a href="login.php">Pieslēgties</a>
           
               
           </div>
</FORM>
</body>
</html>