/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author s6_zablov_n
 */
public  class Person {
    //1.verialbes
    
    private String name;
    private String surname;
    
    //2.constructors
    
    public Person(){
        name = "Janis";
        surname = "Berzins";
        
    }
    
    //3.get and set
    public Person(String name, String surname){
        setName(name);
        setSurname(surname);
    }
    
    //4.toString() function

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }
    @Override
public String toString() {
        return "Student{" + name + surname + '}';
    }

}


    