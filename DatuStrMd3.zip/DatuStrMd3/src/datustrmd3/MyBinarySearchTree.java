
package datustrmd3;


import java.util.Stack; 

public class MyBinarySearchTree<T> {
    private MyTreeNode<T> root;
    private int elementCounter = 0;

    public MyBinarySearchTree() {
        root = new MyTreeNode<>();
        root.setData(null);
        root.setLeftC(null);
        root.setRightC(null);
    }

    public boolean isFull() {
        try {
            MyTreeNode<T> temp = new MyTreeNode<>();
        } catch (OutOfMemoryError e) {
            return true;
        }
        return false;
    }

    public boolean isEmpty() {
        return elementCounter == 0;
    }

    public void clear() {
        elementCounter = 0;
        root = new MyTreeNode<>();
    }

    //insert
    public boolean insert(T element) {
        if (isFull()) {
            return false;
        } else {
            //verify if element exists already using search method
            if (isEmpty()) {
                root.setData(element);
                elementCounter++;
            } else {
                
                insertHelper(root, element);
            }
            return true;
        }
    }

    public void insertHelper(MyTreeNode<T> currentNode, T element) {

        if (currentNode.getData() == null) {
            currentNode.setData(element);
        }

        if (((Comparable) currentNode.getData()).compareTo(element) > 0){
                if(currentNode.getLeftC() == null){
                    currentNode.setLeftC(new MyTreeNode<>(element));
                }else{
                    insertHelper(currentNode.getLeftC(), element);
                }
                
                
            
        } else if (((Comparable) currentNode.getData()).compareTo(element) < 0) { 
                if(currentNode.getRightC() == null){
                    currentNode.setRightC(new MyTreeNode<>(element));
                }else{
                    insertHelper(currentNode.getRightC(), element);
                }

            }
    }

    public boolean isElementInTree(T element) {
        if (isEmpty()) {
            return false;
        } else {
            boolean isElementInTreeHelperResult = isElementInTreeHelper(root, element);
            return isElementInTreeHelperResult;
        }
    }

    private boolean isElementInTreeHelper(MyTreeNode currentNode, T element) {
        //verify is current node is the right one - return one
        // else verify if element is smaller than node or bigger
        // call function  recursive to right or left sub-tree
        boolean result = false;

        if (currentNode.getData().equals(element)) {
            return true;

        } else {
            //currentNode my data > element
            if (((Comparable) currentNode.getData()).compareTo(element) == 1) {
                if (currentNode.getLeftC() != null)
                    result = isElementInTreeHelper(currentNode.getLeftC(), element);

            } else {
                if (currentNode.getRightC() != null)
                    result = isElementInTreeHelper(currentNode.getRightC(), element);
            }
        }
        return result;
    }


    public boolean delete(T element) {
        if (isEmpty() || (!isElementInTree(element))) {
            return false;
        } else {
            deleteHelper(root, element);
            return true;
        }
    }

    private void deleteHelper(MyTreeNode currentNode, T element) {
        //is current is the node what I want to delete
        // if current node is on children
        //if current node has only left
        // if current node has only right child
        //if current node has both child
            if(currentNode.getData().equals(element)){
                currentNode = null ;
                
            }
            
            else if (((Comparable) currentNode.getData()).compareTo(element) == 1) {
                    deleteHelper(currentNode.getLeftC(), element);
            } else {
                    deleteHelper(currentNode.getRightC(), element);
            }
        
    }


    private MyTreeNode<T> getPredecessor(MyTreeNode<T> currentNode) {
        MyTreeNode<T> temp = currentNode.getLeftC();

        while (temp.getRightC() != null) {
            temp = temp.getRightC();
        }
        return temp;
    }

    public void preOrderDisplay() {
        //preOrderDisplayHelper(root);
       inOrderDisplayHelper(root);
        //postOrderDisplayHelper(root);
    }

    

    private void preOrderDisplayHelper(MyTreeNode currentNode) {
        
        if(currentNode.getLeftC() != null){
                 preOrderDisplayHelper(currentNode.getLeftC());
             }

             System.out.println(currentNode.getData());

             if(currentNode.getRightC() != null){
                preOrderDisplayHelper(currentNode.getRightC());
             }
       
    }
   public void  inOrderDisplayHelper(MyTreeNode currentNode){
       
        if(currentNode == null)
            return;
        
       inOrderDisplayHelper(currentNode.getLeftC());
       
       System.out.println(currentNode.getData());
       
      inOrderDisplayHelper(currentNode.getRightC());
       
       
   }
   private void  postOrderDisplayHelper(MyTreeNode currentNode){
       
       if(currentNode == null)
           return;
       
       postOrderDisplayHelper(currentNode.getLeftC());
       
       postOrderDisplayHelper(currentNode.getRightC());
       
       System.out.println(currentNode.getData());
       
   }

   public String infixToPostfix(String exp) 
    { 
        // initializing empty String for result 
        String result = new String(""); 
          
        // initializing empty stack 
        Stack<Character> stack = new Stack<>(); 
          int a = 0;
        for (int i = 0; i<exp.length(); ++i) 
        { 
            
            if(a != exp.length() -1){
                a = i +1;
            }
            char c = exp.charAt(i); 
              
             // If the scanned character is an operand, add it to output. 
            if (Character.isLetterOrDigit(c)) {
                result += c; 
                if(Character.isLetterOrDigit(exp.charAt(a)) && a != i){
                    
                    result += exp.charAt(a);
                    
                    i++;
                    
                }
                }
                
            
               
            // If the scanned character is an '(', push it to the stack. 
            else if (c == '(') 
                stack.push(c); 
              
            //  If the scanned character is an ')', pop and output from the stack  
            // until an '(' is encountered. 
            else if (c == ')') 
            { 
                while (!stack.isEmpty() && stack.peek() != '(') 
                    result += stack.pop(); 
                  
                if (!stack.isEmpty() && stack.peek() != '(') 
                    return "Invalid Expression"; // invalid expression                 
                else
                    stack.pop(); 
            } 
            else // an operator is encountered 
            { 
                while (!stack.isEmpty() && Prec(c) <= Prec(stack.peek())){ 
                    if(stack.peek() == '(') 
                        return "Invalid Expression"; 
                    result += stack.pop(); 
             } 
                stack.push(c); 
            } 
       
        } 
       
        // pop all the operators from the stack 
        while (!stack.isEmpty()){ 
            if(stack.peek() == '(') 
                return "Invalid Expression"; 
            result += stack.pop(); 
         } 
        
        System.out.println(result);
        return result; 
    } 
   
   public boolean isOperator(char element){
       
       return  element == '+' || element == '-' ||element == '*' ||
               element == '/';
   }
   
     static int Prec(char element){
       
       switch(element)
               {
           case '+':
           case '-':
               return 1;
           case '*':
           case '/':
               return 2;
               }
       return -1;
   }
   
   public MyTreeNode expressionTree(String exp){
       Stack <MyTreeNode> st = new Stack();
       MyTreeNode t, t1, t2;
       int a = 0;
       char c = 0;
       for(int i = 0 ; i < exp.length(); i++){
           if(a != exp.length() -1){
               a = i + 1;
           }
            
           
           if(!isOperator(exp.charAt(i))){
               c = exp.charAt(i);   
              if(i == 0){
                  int aa = Character.getNumericValue(c) *10;
                  aa += exp.charAt(a) ;
                  c = (char) ((char) aa );
                  System.out.println(aa);
                  i++;
              }

                   t = new MyTreeNode(c);
               st.push(t);
               
               
               
           }else{
               t = new MyTreeNode(exp.charAt(i));
               
               t1 = st.pop();
               t2 = st.pop();
               
               t.setRightC(t1);
               t.setLeftC(t2);
               
               st.push(t);
           }
       }
       
       t = st.peek();
       st.pop();
       
       return t;
       
   }
   
   public int calculatePostfixTree(String exp){
       Stack<Integer> st = new Stack<>();
      
       for(int i = 0; i < exp.length(); i++){
           char c = exp.charAt(i);
           
           if(Character.isDigit(c)){
               st.push(c - '0');
           }else{
               int rigth = st.pop();
               int left = st.pop();
               
               switch(c){
                   case '+':
                       st.push(left + rigth);
                       break;
                   case '-':
                       st.push(left - rigth);
                       break;
                   case '/':
                       st.push(left / rigth);
                       break;
                   case '*':
                       st.push(left * rigth);
                       break;
               }
           }
       }
       return st.pop();
   }
  

} 