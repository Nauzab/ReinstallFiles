/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Doctor")
public class Doctor extends User{
	
	@Column(name = "OfficeNum")
     private short officeNum  ;
 	
 	
 	@Column(name = "Name")
    private String name;
 	
	@Column(name = "Surname")
    private String surname;
     
 	 @OneToOne(mappedBy = "doctor")
     private Appointment appointment;
 	 
 	@OneToOne
	@JoinColumn(name = "Id_u")
	private User user;
 	
 	  private int doctorID  ;
     private static int doctorCounter = 1;
 	 
 	public Doctor() {}
 	
    public Doctor(short officeNum, String name, String surname, String username, String password) {
       super(username, password);
       setOfficeNum(officeNum);
       this.name = name;
       this.surname = surname;
       this.doctorID = doctorCounter ;
       doctorCounter ++;
    
    }

    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public short getOfficeNum() {
        return (short) officeNum;
    }

    public void setOfficeNum(short officeNum) {
        
    	this.officeNum = officeNum;
    }

    public int getDoctorID() {
        return doctorID;
    }

    public void setDoctorID(int doctorID) {
        this.doctorID = doctorID;
        
    }
    
    public void getUserid() {
    	
    }
    public int getDoctorCounter() {
        return doctorCounter;
    }

  


    public String toString() {
        return   "Doctor{" + "officeNum=" + officeNum + ", doctorID=" + doctorID + ", doctorCounter=" + doctorCounter +  '}';
    }
     

   
}
