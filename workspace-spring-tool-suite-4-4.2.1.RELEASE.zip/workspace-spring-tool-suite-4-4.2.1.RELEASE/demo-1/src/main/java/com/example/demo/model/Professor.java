package com.example.demo.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity 
@Table(name = "ProfessorTable") //database table
public class Professor {
		
		@Id //Id can't be null 
		@GeneratedValue(strategy = GenerationType.AUTO) //Generating id 
		@Column(name = "Id_p") //create column works on each line 
		private int id_p;
		
		@Column(name = "Name")
		private String name;
		
		@Column(name = "Surname")
		private String surname;
		
		@Column(name = "Degree")
		private String degree;
		
		@OneToOne(mappedBy = "professor") //name of course Proffesor verialbe
		private Course course;
		
		public int getId_p() {
			return id_p;
		}
		public void setId_p(int id_p) {
			this.id_p = id_p;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getSurname() {
			return surname;
		}
		public void setSurname(String surname) {
			this.surname = surname;
		}
		
		public String getDegree() {
			return degree;
		}
		public void setDegree(String Degree) {
			this.degree = Degree;
		}
		public Professor() {
			super();
		}
		public Professor( String name, String surname, String Degree) {
			super();
			
			this.name = name;
			this.surname = surname;
			this.degree = Degree;
		}
		
		
}
