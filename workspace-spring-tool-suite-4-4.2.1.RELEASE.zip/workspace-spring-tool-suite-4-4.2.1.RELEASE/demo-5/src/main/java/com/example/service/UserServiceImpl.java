package com.example.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.example.model.User;

@Service
public class UserServiceImpl implements UserService {

	@Override
	public ArrayList<User> findAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean authorizeByEmail(String email, String password) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean authorizeByUsername(String username, String password) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateById(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean newUser(User user) {
		// TODO Auto-generated method stub
		return false;
	}

}
