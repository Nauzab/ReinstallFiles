package com.example.demo.Controllier;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.demo.model.Course;
import com.example.demo.model.Grade;
import com.example.demo.model.Professor;
import com.example.demo.model.Student;
import com.example.demo.repo.CourseRepo;
import com.example.demo.repo.GradeRepo;
import com.example.demo.repo.ProfessorRepo;
import com.example.demo.repo.StudentRepo;

@Controller
public class DataBaseController {
	
	@Autowired
	StudentRepo studentRepo;
	
	@Autowired
	ProfessorRepo professroRepo;
	
	@Autowired
	CourseRepo courseRepo;
	
	@Autowired
	GradeRepo gradeRepo; 
	
	@GetMapping(value = "/testingdata")
	public String testingData() {
		Student s1 = new Student("Janis", "Brics");
		Student s2 =new Student("Marcis" , "Keiss");
		Student s3 = new Student("Kristaps", "Melnais");
		studentRepo.save(s1);
		studentRepo.save(s2);
		studentRepo.save(s3);
		
		Professor p1 = new Professor("Janis", "Meistars", "Doctors");
		Professor p2 = new Professor("Dace", "Meistare", "Doctors");
		professroRepo.save(p1);
		professroRepo.save(p2);
		
		Course c1 = new Course("Java", 4, p1);
		courseRepo.save(c1);
		
		
		Grade g1 = new Grade(s1, c1, 6);
		Grade g2 = new Grade(s2, c1, 7);
		Grade g3 = new Grade(s3, c1, 5);
		
		gradeRepo.save(g1);
		gradeRepo.save(g2);
		gradeRepo.save(g3);
		
		System.out.println(professroRepo.count());
		System.out.println(studentRepo.count());
		System.out.println(courseRepo.count());
		System.out.println(gradeRepo.count());
		return "ok";
	}
	@GetMapping(value = "/showAllStudents")
	public String showAllStudents() {
		
		ArrayList<Student> allStudentsFromDB = (ArrayList<Student>)studentRepo.findAll();
		
		for(Student student: allStudentsFromDB) {
			System.out.println(student.getName());
		}
		return "ok";
	}
	
	@GetMapping(value = "/findJavaProfessor")
	public String findJavaProfessor() {
		//FIND PROFESSOR OF JAVA COURSE 
		
		Course c = courseRepo.findByTitle("Java");
		
		System.out.println(c.getProfessor().getName() + c.getCp());
		
		ArrayList<Course> allCoursesWith4Cp = courseRepo.findByCp(4);
		
		for(Course course: allCoursesWith4Cp) {
			System.out.println(course.getTitle() + " " + course.getCp());
		}
		
		//find all grades in java and calculate avg grade
		ArrayList<Grade> grade = gradeRepo.findByCourse(c);
		int avg = 0 ;
		
		for(int i = 0 ; i < grade.size(); i++) {
			avg = avg + grade.get(i).getGadeValue();
		}
		int sum = avg / grade.size();
		
		System.out.println("AVG = " + sum);
		
		return "ok";
	}
}
