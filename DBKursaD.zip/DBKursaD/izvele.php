<?php
# Veidojam savienojumu ar savu serveri un datu bāzi
$d = mysqli_connect('localhost','worldread','worldreadPaSS','pasakums') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");


function fill_brand($d)  
{  
     $output = '';  
     $sql = "SELECT  * FROM Valstis";  
     $result = mysqli_query($d, $sql);  
     while($row = mysqli_fetch_array($result))  
     {  
         
          $output .= '<option value="'.$row["ID"].'">'.$row["1"].'</option>';  
     }  
     return $output;  
}  

function fill_product($d)  
{  
    
     $sql = "SELECT * FROM Pasakums p Join Adrese a WHERE a.ID = p.AdresesID";  
     $result = mysqli_query($cd, $sql); 
       
      
}  

?>
    <html>
            <head >
            <link rel="stylesheet" href="pasakums.css" type="text/css" >
            <title background="event.jpg" >Pasakuma kalendars</title> 
            </head>
            <script type = "text/javascript " src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.min.js"></script>
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
             <body background="images.jpeg">
                <div id = "log">
             <a href="pasakums.php" >sakums</a>
             </div>
            <h1>Pasakuma kalendars</h1> 
            <form mothod = "get" action = "izvele.php">
               <p>Atlasit pasakumu :
                <!--Izveido valsts izveli -->
                <label> Valsts: </label>
            <select id = "country-list" name = "Valsts" onChange = "getData(this.value);"> 
            <option value = "<?php echo $rs["ID"];?>">select country </option>
            
            <?php 
            $sql = "SELECT * FROM Valstis ;";
            $result = mysqli_query($d,$sql);
            while($rs = mysqli_fetch_array($result)){
                ?>
                <option value = "<?php echo $rs["ID"];?>"> <?php echo $rs["1"];?> </option>
                <?php
            }
            ?> 
                 </select>
                 
                 <label> Pilseta: </label>
                 <select id = "state-list" name ="getData(this.value);" >
                 <option value = "<?php echo $rs["ID"];?>">Select city </option>
                  
            
                  </select>
                
                 <label> Datums: </label>
                 <select id = "Date-list" name ="Datums">
                 <option value = "<?php echo $rs["ID"];?>">Select Date</option>  
                 </select>

                 <br>
               
                         </form>
                         <div class="row" id="show_product">  
                         <?php echo fill_product($d);?>  
                    </div>  
                   
                          </p>
<?php
function tabula($sql_res) {
$first = true;
echo "<center><table class=\"schedule\">";
while ($row = mysqli_fetch_assoc($sql_res)) {
    if ($first) {
        echo "<tr>";
        foreach ($row as $k=>$v) {
            echo "<th>$k</th>";
        }
        echo "</tr>".PHP_EOL;
        $first = false;
    }
    echo "<tr>";
        foreach ($row as $v) {
            echo "<td>$v</td>";
        }
        echo "</tr>".PHP_EOL;
}
echo "</table></center>";

$row_cnt = mysqli_num_rows($sql_res);

/* close result set */
mysqli_free_result($sql_res);
}
?>
  <script>
            function getData(val){
                $.ajax({
                   type:"POST",
                   url: "GetCity.php",
                   data: 'ID= ' + val,
                   success: function(data){
                       $("#state-list").html(data);
                       
                   }
               });

                $.ajax({
                   type:"POST",
                   url: "GetData.php",
                   data: 'ID= ' + val,
                   success: function(data){
                       $("#Date-list").html(data);
                   }
               });

            }
            </script>
            <script>  
$(document).ready(function(){  
     $('#country-list').change(function(){  
          var brand_id = $(this).val();  
          $.ajax({  
               url:"GetInfo.php",  
               method:"POST",  
               data:{brand_id:brand_id},  
               success:function(data){  
                    $('#show_product').html(data);  
               }  
          });  
     });  
});  
</script>

            <script>  
$(document).ready(function(){  
     $('#state-list').change(function(){  
          var brand_id = $(this).val();  
          $.ajax({  
               url:"GetType.php",  
               method:"POST",  
               data:{brand_id:brand_id},  
               success:function(data){  
                    $('#show_product').html(data);  
               }  
          });  
     });  
});  

</script>

            <script>  
$(document).ready(function(){  
     $('#Date-list').change(function(){  
          var brand_id = $(this).val();  
          $.ajax({  
               url:"GetDataInfo.php",  
               method:"POST",  
               data:{brand_id:brand_id},  
               success:function(data){  
                    $('#show_product').html(data);  
               }  
          });  
     });  
});  

</script>
          

   </body>
    </html>


  