/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Arrays;
import model.Grade;

/**
 *
 * @author s6_zablov_n
 */
public class Student extends Person {
    
    private Grade[] studentgrades = new Grade[5];

    
    
    public Student(String name,  String surname, Grade[] studentgrades) {
        super(name, surname); //get name from Person class
        setStundentgrades(studentgrades);
        
        
    }
    
     public Student( Grade[] studentgrades) {
        super(); 
         setStundentgrades(studentgrades);
        
        
    }
    
    

    
    public Grade[] getStundentgrades() {
        return studentgrades;
    }

    public void setStundentgrades(Grade[] stundentgrades) {
       
            this.studentgrades = stundentgrades;
        
        
    }

    @Override
    public String toString() {
        return super.toString() + "Student{" + "stundentgrades=" + Arrays.toString(studentgrades) + '}';
    }
    
    
    public double getAveragegrade(){
        double result = 0;
        for (Grade studentgrade : studentgrades) {
            result += studentgrade.getGradeValue();
        }
        return result/studentgrades.length;
    }
    
    
}