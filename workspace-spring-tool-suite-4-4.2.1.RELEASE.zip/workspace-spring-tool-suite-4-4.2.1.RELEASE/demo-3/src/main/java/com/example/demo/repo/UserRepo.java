package com.example.demo.repo;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.User;

public interface UserRepo extends CrudRepository<User, Integer>{
	
	User findByUsernameAndPassword(String username, String password);
}
