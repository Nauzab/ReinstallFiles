<html>


<?php
    # Veidojam savienojumu ar savu serveri un datu bāzi
$d = mysqli_connect('localhost','worldread','worldreadPaSS','pasakums') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");

$query = "SELECT Distinct pilseta FROM Adrese  WHERE ValstsID = '".$_POST["ID"]."'";
$result = mysqli_query($d,$query);

function fill_brand1($d)  
{  
     $output = '';  
     $sql = "SELECT Distinct * FROM Adrese WHERE ValstsID = '".$_POST["ID"]."' ";  
     $result = mysqli_query($d, $sql);  
     while($row = mysqli_fetch_array($result))  
     {  
         
          $output .= '<option value="'.$row["ID"].'">'.$row["Pilseta"].'</option>';  
     }  
     return $output;  
}  
function fill_product1($d)  
{  
    
     $sql = "SELECT * FROM Pasakums";  
     $result = mysqli_query($cd, $sql);  
    
}  
?>


<option> Select city</option>
<?php echo fill_brand1($d); ?> 


    


</html>