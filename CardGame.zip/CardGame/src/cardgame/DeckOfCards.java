
package cardgame;

import java.awt.BorderLayout;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.security.SecureRandom;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author nz
 */
public class DeckOfCards {
    
    
    private static Card[] deck;
    private int currentCard; // index of the next cards to be dealt
    
    public DeckOfCards() throws IOException{
        String[] faces = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"};
        String[] suits = {"Diamonds", "Clubs", "Hearts", "Spades"};
        deck = new Card[52];
        currentCard = 0 ;
        
        //Information used to extract individual cards form the 1 image holding all 
        
        final int  width = 52;
        final int heigth = 73;
        final int rows = 4;  //images row
        final int cols = 13; //images colums
        
        BufferedImage bigImage = ImageIO.read(new File("Deck_of_cards.jpg"));//Whole image of deck of cards
        BufferedImage tempCardImage; //smaller image
        for(int suit = 0 ; suit < 4 ; suit ++){
            for(int faceNum = 0 ; faceNum < 13 ; faceNum++){
                //extract the image
                tempCardImage = bigImage.getSubimage(
                        faceNum*width +11,    //Starting x-cordinate (whit pixels)
                        suit * heigth + 20,       //Starting y-cordinate
                        width,                          //images width
                        heigth);                        //images heigth
                
          deck[(faceNum +(suit*13))] = new Card(
                faces[faceNum], //valls the faces array to get the faces name
                suits[suit], //Calls the suit array to get the name of the suit
                faceNum+2, //
                 tempCardImage);
            }
            
        }
        
        
    } //end of constructor
    
    public void displayDeck(){
        for(Card card: deck)
            System.out.println(card);
    }
    
    public void shuffleDeck(){
        currentCard = 0;
        SecureRandom shuffle = new SecureRandom(); 
        
        for(int i = 0 ; i < deck.length ; i ++){
            //select a random card.
            int second = shuffle.nextInt(52);
            
            //swap the cards
            Card temp = deck[i];
            deck[i] = deck[second];
            deck[second] = temp;
        }
    }
    
    //will deal the card of the deck and advance the currentCards instance veriable
    public Card dealCards(){
        if(currentCard < deck.length)
            return deck[currentCard++];
        else
            return null;
            
    }
    
    public static void main(String[] args) throws IOException {
        DeckOfCards theDeck = new DeckOfCards();
        //theDeck.displayDeck();
        theDeck.shuffleDeck();
        //System.out.println("\n After shuffling the deck: ");
        //theDeck.displayDeck();
        
        //System.out.println("\n Dealt card: ");
       // System.out.println(theDeck.dealCards());
        
        
          
        //Create Jframe to display our card .
        JFrame window = new JFrame("Zolišu spēle");
        window.setSize(800,800); //Set size by pixel size
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //On click closes the Jframe
        window.setVisible(true);//Set frame visible by value true;
        
        //Create Jpanel - similar to JFrame
        
       JPanel contentPanel = new JPanel(new BorderLayout() ); //Create and Set panel layout
       
       
       //Create a JLabel - this is lika a sticky note you stick to your panel..
       JLabel cardLabel = new JLabel(new ImageIcon(deck[0].getCardImage()));
       cardLabel.setSize(2,4); // set sticky note size
       
       contentPanel.add(cardLabel); //Add sticky note to a panel or JPanel
       window.add(contentPanel); //Add panel to a window or JFrame
       
       window.setVisible(true);
    }
}

