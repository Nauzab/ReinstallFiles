package javasem02;

import java.text.DecimalFormat;
import java.util.Random;
import java.util.Scanner;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author s6_zablov_n
 */
public class JavaSem02 {

    public static void main(String[] args) {
        
        //Exercise 0
        System.out.println ( "Task 0");
        System.out.println ( "  ");
        String[] names = { "Elena" , "Thomas" , "Hamilton", "Suzie", "Phil",
            "Matt", "Alex", "Emma", "Jhon", "Jane", " Emily", "Daniel" , "Neda",
            "Aaron", "Kate"
        };
        int[] times= { 341,273,278,329,445,402,388,275,243,334,412,399,
            299,343,371,265
        };
        for( int i = 0 ; i < names.length ;i++){
            System.out.println("Name - " + names[i] + " /time = " + times[i] );
        }
        //Exercise 1
        System.out.println ( "  ");
        System.out.println ( "Task 1");
        System.out.println ( "  ");
        double gravity = -9.81;
        double initialVelocity = 0.0;
        double fallingTime = 10.0;
        double initialPosition = 0.0;
        double finalPosition = 0.0;
        JavaSem02 Position = new JavaSem02();
        double sec = Position.PositionCalc(gravity,initialVelocity,initialPosition,fallingTime);
        System.out.println ("Pos in " + fallingTime + " sec :" + sec);
        
        //Exercise 2
        System.out.println ( "  ");
        System.out.println ( "Task 2");
        System.out.println ( "  ");
        Scanner src  = new Scanner(System.in);
        System.out.println("Please enter a number => ") ;
        int num = src.nextInt();
        if(num > 0){
        System.out.println("Factorial using ForLoop is " + num + " is " + new JavaSem02().facttorialForLoop(num));
        System.out.println("Factorial using Recrusive is " + num + " is " + new JavaSem02().FactorialRecursive(num));
        }
        else{
            System.out.println("Error / Returned 0;");
        }
        
        //Exercise 3;
        System.out.println ( "  ");
       System.out.println ( "Task 3");
       System.out.println ( "  ");
      JavaSem02 test = new JavaSem02();
         int n =10;
        double[] all= new double [n];
        
        for(int i = 0 ; i< n ; i++){
        all[i] = test.generateArray( n, 10, 20);
        System.out.println(all[i]);
        }
        double max = test.getMax(all);
        System.out.println( "Maximum value is => " +max);
        double min = test.getMin(all);
        System.out.println( "Minimum value is => " +min);
        double mean = test.getMean(all);
        System.out.println( "Mean(Average) value is => " +mean);
        System.out.println( "-------BUBBLE SORTED ARRAY------- " );
       for(int i = 0 ; i < n ; i++){ 
           test.arraySort(all);
           System.out.println(all[i]);
       }
        //Exercise 4;
        System.out.println ( "  ");
        System.out.println ( "Task 4");
        System.out.println ( "  ");
        JavaSem02 mat = new JavaSem02();
        
            int matrix;
            
            matrix = mat.generateMatrix(0);
            
            Scanner src1  = new Scanner(System.in);
            System.out.println("Please enter a row => ") ;
             int row = src1.nextInt();
             System.out.println("Please enter a collom => ") ;
             int collom = src1.nextInt();
             final int SIZE = 5;
             int[] product = new int [SIZE];
            // getProduct(product,row,collom);
            
        
        //Exercise 5; 
        System.out.println ( "  ");
        System.out.println ( "Task 5");
        System.out.println ( "  ");
        //part 1
        JavaSem02 coin = new JavaSem02();
        double flip = coin.coinFlip(10);
        //part 2 
        int dice = coin.rollDice(10);
        //part 3
        int dice1 = coin.roll2Dices();
        System.out.println("You had to flip " + dice1 + " time(s) to roll two 6" );
        
        
        //Exercise 7;
        System.out.println ( "  ");
        System.out.println ( "Task 7");
        System.out.println ( "  ");
        JavaSem02 pascal = new JavaSem02();
        String tri = pascal.pascalsTriangle(7);
         
        //Exercise 8;
        System.out.println ( "  ");
        System.out.println ( "Task 8");
        System.out.println ( "  ");
            JavaSem02 strin = new JavaSem02();
            String equation = "1 - 3 * 18 / 4 + 2";

            double sum = strin.executeStringEquation(equation);
                  
       
        
    }

    
    double PositionCalc(double a , double v , double x , double t) { //Exercise 1;
        double finalPosition = 0.5 * a * (t*t) + v * t + x; 
        return finalPosition;
    }
 
    
    int facttorialForLoop(int N){ //Exercise 2;
        int result = 1;
        for(int  i = 1; i < N +1 ; i++){
            result *=i; 
        }
        return result;
    }


    int FactorialRecursive(int N) { //Exercise 2;
        if(N == 1)
            return 1;
        else 
            return N*(FactorialRecursive(N-1));
    }
    
    double generateArray( int N, double lower, double upper){ //Exercise 3;
        double[] array = new double[N];
        Random rand = new Random();  
        if(lower < upper ){
        for(int i = 0 ; i <array.length ; i++){
            array[i] =rand.nextInt((int) (upper - lower)) + lower; //making random bounds
           //System.out.println(array[i]);
           return array[i];
        }
        }
        else{
            return 0;
        } 
        return 0 ;
    }
    
    double getMean(double[] array){
        double sum = 0 ; 
        double result = 0 ;
        for(int i = 0  ; i < array.length;i++){
                sum += array[i]; //counts all value total
        }
        result = sum / array.length; //calculate average
        return result;
       
    }
double getMax(double[] array) //Exercise 3;
    {
        double max = array[0];
        
       for( int i = 1 ; i < array.length; i++){
           if(array[i] > max) //If value in array[i] is bigger then max value
               max = array[i];//replace it with that value ;
       }
        return max; //returning max value;
    }
double getMin(double[] array){
    double min = array[0];
    
    for(int i = 1; i < array.length; i++){
        if(array[i] < min){ //if value in arra[i] is smaller then min value
            min = array[i];//replace it with array[i] value;
        }
        
    }
    return min;//returnin min value
}
    int arraySort(double[] array){ //bubble sort
    double temp = 0 ;
    for(int i = 0 ; i < array.length - 1 ; i++){
        for( int j = 1; j < array.length ; j++){
             if(array[j-1] > array[j]){ //if j-1 bigger than j , make a swich
                 temp = array[j-1];
                 array[j-1] = array[j];
                 array[j] = temp;
                }
        }
        }
    return 0;
   
    }
    
   int generateMatrix(int N){
       char m = ' ';
      
        int[][] matrix = new int [][]{{10,12,43,11,22} , {20,45,56,1,33} , {30,67,32,14,44},
        {40,12,87,14,44}, {50,86,66,13,66} , {60,53,44,12,12}};
        //int [] izm = new int [] {0,1,2,3,4,5};
        System.out.println("  A  " + "  B  " + "  C  " + "  D  " + "  E  " );
        for (int[] matrix1 : matrix) {
           
            for (int j = 0; j < matrix1.length; j++) {
                
                
                System.out.print("  " + matrix1[j] + " ");
            }
            System.out.print("\n");
            
        } return m;
}
   double getProduct(double[][] matrix, int i, int j){
       char o = ' ';
       int m = matrix.length;
        for (int a = 0 ; a < m ; a++) {
            for(int x = 0 ;  x < m ;x++){
                System.out.println(matrix[i][j]);
            }
        }return o ;
       
   }

 double coinFlip(int N){
       int randomInt = 0;
       char m = ' ';
       
           
           Random flip = new Random();
           int heads = 0 ; 
           int tails = 0;
           for(int i = 1; i <=N ;i++){ 
           randomInt = flip.nextInt(2); //50% chance 
       
           if(randomInt == 1){ //if 1 that's heads
               heads++;
           }else{ //else tails
               tails++;
           }
           }
           double ratio = heads/tails; //ratio 
           double [] max = new double[] {heads , tails , ratio};
         
              System.out.println("Of " + N +" try(s) ,you flipped heads = " + max[0] + " time(s) " + ", tails = " + max[1] + " time(s)" +
                      ", and ratio is = " + ratio);
          
       
       return m;
   }
 int rollDice(int N){
     Random rand = new Random();
     char m = ' ';
      
     int roll = 0;
     for(int i = 0 ; i < N ; i++){
         roll = rand.nextInt(6)+1; //dice roll  value
         System.out.println(" you rolled " +roll);
     }
     return m;
     
 }
 int roll2Dices(){
     Random rand = new Random();
     int times = 0 ;
     int roll = 0;
     int roll1 = 0;
     while(roll != 6 && roll1 != 6){
         roll = rand.nextInt(6)+1; //first dice roll value
         roll1 = rand.nextInt(6) + 1;//second dice roll value
         times++; // total times of flips
         
     }
     return times;
 }
 String pascalsTriangle(int level){
     int  k;
     int number=1; //starting value
     String [] m = new String [] {" "};
	for(int i=0;i<level;i++)
	{
		for(k=level; k>i; k--)
		{
                    System.out.print(" ");
		}
                    number = 1;
		for(int j=0;j<=i;j++)
		{
                     System.out.print(number+ " ");
                    number = number * (i - j) / (j + 1);
		}
		System.out.println();
        }
        return m[0];
 }
 double executeStringEquation(String inputEquation){
     char m = ' ';
     ScriptEngine engine = new ScriptEngineManager().getEngineByExtension("js"); //using build in functions
 
        try {
            // Evaluate the expression
            Object result = engine.eval(inputEquation);
 
            System.out.println(inputEquation + " = " + result); //print out equatin and result
        }
        catch (ScriptException e) {
            // Something went wrong
            e.printStackTrace();
        }
        return m ;
 }
}




