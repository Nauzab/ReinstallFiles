package com.example.demo.model;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author nz
 */
public class Thousand {
    
        private int points; //Player total points
        private int tempPoints;//Player round points 
        private Player player; //Player
        private Computer computer; //computer
        private ArrayList<Integer> rolledDices = new ArrayList<>();//Arraylist for rolled dices
        private int elementCount; //element counter in rolled dices arraylist
        private ArrayList<Integer> chosenDices = new ArrayList<>(); //new arraylist for chosen dices
    Thousand(Player player){
           points = 0 ;
           setPlayer(player);
           rolledDices = new ArrayList<>();
           setElementCount(elementCount);
    }
    Thousand(Computer computer){
           points = 0 ;
           setComputer(computer);
           rolledDices = new ArrayList<>();
           setElementCount(elementCount);
    }
    Thousand(){
           
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }
    
    public Computer getComputer(){
        return computer;
    }
    
    public void setComputer(Computer computer){
        this.computer = computer;
    }
    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        if(points >= 25){
            this.points = points;
        }else{
            System.out.println("Not enough round points to add them to total points!..");
        }
    }

    public int getTempPoints() {
        return tempPoints;
    }

    public void setTempPoints(int tempPoints) {
        this.tempPoints += tempPoints;
    }
    
    public int getElementCount() {
        return elementCount;
    }

    public void setElementCount(int elementCount) {
        this.elementCount = elementCount;
    }
    

    public ArrayList<Integer> getRolledDices() {
        return rolledDices;
    }

    public void setRolledDices(ArrayList<Integer> rolledDices) {
        this.rolledDices = rolledDices;
    }
        
    public void rollDices(){    
        Random rand = new Random();
        int dicesLeft = getElementCount();
        if(dicesLeft == 0){
            dicesLeft = 5;
        }
        elementCount = 0;
        for(int i = 0 ; i < dicesLeft ; i ++){
            
            int r = rand.nextInt(6) +1 ; //gets random number form 1-6
            rolledDices.add(r); //adds generated number in rolledDices arraylist
            elementCount++;
        }
        
 
    }
    public ArrayList diceChoise(int chosen){
       
        boolean temp = false;
        int count = 0 ; //counter for chosen dices
        
        for(int i = 0 ; i < rolledDices.size() ; i++){//count how many chosen dices is in rolledDices
            if(rolledDices.get(i) == chosen){
                count++;    
            }
        }
        
        temp = checkForPoints(chosen, count); //check if chosen dices are allowed to be add to points 
        if(temp){
            for(int i = 0 ; i < count ; i++){
                chosenDices.add(chosen); //adding dices  to chosenDices arraylist          
            }
            removeFromRolledDices(chosen);//remove added dices from rolledDices arraylist
        }else{
            System.out.println("Error:CANNOT CHOOSE");
        }
        
        
        return chosenDices; //return chosen dices
    }
    
    public boolean checkForPoints(int chosen, int count){ //counts points 
       
            
        if(count == 3){
            switch(chosen){
                case 1:
                    setTempPoints(100);
                    break;
                case 2:
                    setTempPoints(20);
                    break;
                case 3:
                    setTempPoints(30);
                    break;
                case 4:
                    setTempPoints(40);
                    break;
                case 5:
                    setTempPoints(50);
                    break;
                case 6:
                    setTempPoints(60);
                    break;
            }
    
            return true;
        }else if(count == 4){
            switch(chosen){
                case 1:
                    setTempPoints(200);
                    break;
                case 2:
                    setTempPoints(40);
                    break;
                case 3:
                    setTempPoints(60);
                    break;
                case 4:
                    setTempPoints(80);
                    break;
                case 5:
                    setTempPoints(100);
                    break;
                case 6:
                    setTempPoints(120);
                    break;
            }
            return true;
        }  
        else if(count == 5){
            switch(chosen){
                case 1:
                    setTempPoints(500);
                    break;
                case 2:
                    setTempPoints(100);
                    break;
                case 3:
                    setTempPoints(100);
                    break;
                case 4:
                    setTempPoints(100);
                    break;
                case 5:
                    setTempPoints(100);
                    break;
                case 6:
                    setTempPoints(100);
                    break;
            }
            return true;
        }  
       
        else if(count <=2 && chosen == 1 || chosen == 5){
            if(count == 1 ){
                switch(chosen){
                    case 1:
                        setTempPoints(10);
                        break;
                    case 5:
                        setTempPoints(5);
                        break;
                }
            }else{
                switch(chosen){
                    case 1:
                        setTempPoints(20);
                        break;
                    case 5:
                        setTempPoints(10);
                        break;
                }
            } return true;  
        }
        else{
            System.out.println("Cannot count your points whit that rolled dice");
            return false;
        }
               
    }
    
    public void removeFromRolledDices(int chosen){ //removes dice form rolledDices arraylist
        for(int j = 0 ; j < rolledDices.size();j++)
        for(int i = 0 ; i < rolledDices.size(); i++){
            if(rolledDices.get(i) == chosen){
                rolledDices.remove(i);
                elementCount--;
            }
        }
    }
    public void clearRolledDices(){ //clears arraylist
        rolledDices.clear();
        
    }
    public void clearChosenDices(){ //clears arraylist
        chosenDices.clear();
        
    }
    public void printRolledDices(){ //prints arraylist
        System.out.println();
        for( int i = 0 ; i < rolledDices.size() ; i++  ){
            System.out.print( rolledDices.get(i) + " ");
        }  System.out.println();
    }
    
   
    
}
