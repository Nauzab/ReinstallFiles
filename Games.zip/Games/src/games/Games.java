
package games;

import java.util.Scanner;

public class Games {

   
    public static void main(String[] args) {
       
        Lingo l = new Lingo();
        int tempLife = 3; 
        Scanner scan = new Scanner(System.in);
        
      while(l.getLife() != 0 ){
          l.printInfo(); //print info
          String w = l.shuffleWord(l.getRandomWord()); //get word
          System.out.println("te" +w);
          l.Upper(w); //set to upper
          int setGuess = w.length() -1;
          int pointCounter = 0;
          l.setGuesses(setGuess); //set guessing times
          
          l.setLife(--tempLife);
          
          do{
              System.out.println("Guess word: " + w + "\nYour guess: ");
              String guessWord = scan.nextLine();
              guessWord = l.Upper(guessWord);
            
              if(guessWord.equals("STOP")){
                  System.out.println("The word was: " + l.getCorrectWord());
                  break;
              }
              
              if(guessWord.equals(l.getCorrectWord())){
                  if(pointCounter ==0 ){
                      l.setLife(++tempLife);
                  }
                  System.out.println("Correct!");
                  l.setPoints(pointCounter);
                  break;
              }else{
                  setGuess--;
                  pointCounter++;
                  
                  for(int  i = 0 ; i < l.getCorrectWord().length(); i++){
                      if(guessWord.charAt(i) == l.getCorrectWord().charAt(i)){
                          System.out.println(guessWord.charAt(i));
                      }
                  }
              }
              
          }while(l.getGuesses() != 0);
      }
        
    }
    
}
