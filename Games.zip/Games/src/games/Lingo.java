
package games;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;


public class Lingo {
    
    private final String[] words = {"SKAPIS", "AKMENS" , "ASMENS", "ZIBENS", "MENESS", "MEDUS",
    "GALDS", "PAVARDS", "REKORDS", "STRAZDS", "ZVIRGZDS", "DRAUGS", "KAROGS",
    "ZIEDS", "ZIRGS", "KUNGS", "MIEGS", "PARAUGS", "LAUKS", "IENAIDNIEKS",
    "RAKSTNIEKS"};
    
    private int points = 0;
    private int guesses;
    private int life = 3;
    private String corretcWord;
    
    Lingo(){
        
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        if(points > 0 && points < 6){
            this.points += 0; 
        }else{
            switch(points){
                case 0:
                    this.points += 10;
                    break;
                case 1:
                    this.points += 8;
                    break;
                case 2:
                    this.points += 6;
                    break;
                case 3:
                    this.points += 4;
                    break;
                case 4:
                    this.points += 3;
                    break;
                case 5:
                    this.points += 1;
                    break;

            }
        }
        
    }

    public int getGuesses() {
        return guesses;
    }

    public void setGuesses(int guesses) {
        this.guesses = guesses;
    }

    public int getLife() {
        return life;
    }

    public void setLife(int life) {
        this.life = life;
    }
    public String getCorrectWord() {
        return corretcWord;
    }

    public void setCorrectWord(String correctWord) {
        this.corretcWord = correctWord;
    }
    public String getRandomWord(){
        Random ran = new Random();
        int n = ran.nextInt(words.length);
        
        String word = words[n];
        setCorrectWord(word);
        return word;
    }
    
   public String shuffleWord(String word){
         List<String> letters = Arrays.asList(word.split(""));
        Collections.shuffle(letters);
        String shuffled = "";
        for (String letter : letters) {
          shuffled += letter;
        }
        return shuffled;
        
      
    } 
   
   public String Upper(String inputWord){
       return inputWord.toUpperCase();
   }
  
   
   
   public void printInfo(){
       System.out.println("Life: " + getLife() + "\nPoints: " + getPoints());
   }
   
    
    
}
