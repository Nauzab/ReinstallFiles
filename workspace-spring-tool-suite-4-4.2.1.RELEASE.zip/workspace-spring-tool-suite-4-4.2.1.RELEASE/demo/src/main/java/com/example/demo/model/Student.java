package com.example.demo.model;

public class Student {
	
	private String name;
	private String surename;
	
	public Student() {
		
	}
	public Student(String name, String surename) {
		super();
		this.name = name;
		this.surename = surename;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSurename() {
		return surename;
	}
	public void setSurename(String surename) {
		this.surename = surename;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return  name + " " + surename;
	}
}
