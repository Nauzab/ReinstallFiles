#include <iostream>

using namespace std;
int ToBin(int a){
    int b = 0;
    while (a >0){
    b= a % 2;
    a /=2;

    cout << b << endl;
    }
}
int main(){
    int a ;
    cout << "Enter digit ==> " ;
    cin >> a;
    ToBin(a);
    char answ ;
    cout << "DO YOU WANT TO CONTINUE?[Y/N] ";
    cin >> answ;
    while (answ != 'N' && answ != 'n'){
    cout << "Enter digit ==> " ;
    cin >> a;
    ToBin(a);
    cout << "DO YOU WANT TO CONTINUE?[Y/N] ";
    cin >> answ;



    }


}
