package com.example.demo.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.model.Lingo;

@Controller
public class GameController {
		
		private Lingo l = new Lingo();
		private int tempLife = 3;
		private int pointCounter = 0;
		private int temp;
		private boolean tempG = true;
		private int guessCounter =0;
		private int wordCounter = 0;
		private int lefiTime = 2;
		private int points =0 ;
		String ce = new String("");
		@GetMapping(value = "/showGames")
		public String showGames() {
			
			return "main";
			
		}
		
		@GetMapping(value = "/thousandGame")
		public String thousandGameGet( Integer count) {
			
			return "thousand";
		}
		
		
		@PostMapping(value = "/thousandGame")
		public String thousandGamePost( Integer count) {
			
			return "redirect:/thousandGame";
		}
		
		@GetMapping(value = "/guessPairsGame")
		public String guessPairs() {
			
			return "guessPairs";
		}
		
		@GetMapping(value = "/lingo")
		public String LingoGet(Lingo lingo) {
			
		
			return "Lingo";
		}
		
		@PostMapping(value = "/lingo")
		public String LingoPost(Lingo lingo) {
			l = lingo;
			
			return "redirect:/LingoGame";
		}
		
		@GetMapping(value = "LingoGame")
		public String LingoGameGet(Model model, Lingo lingo) {
			l.clearGuessChar();
			if(tempLife == 0) {
				return "redirect:/EndLingo";
			}
			if( lefiTime == 0) {
				l.setLife(--tempLife);
				temp = 0;
				tempG = true;
				
			}
			
			OUTTER:
			if(temp ==1) {//TO AVOID ERRORS
				
				if(l.getGuessWord().equals("STOP")) {
					tempG = true;
					l.setLife(--tempLife);
					lefiTime = 2;
					break OUTTER;

				}
				
				if(l.getGuessWord().equals(l.getCorrectWord())) {
					
					tempG = true;
					wordCounter++;
					guessCounter++;
					switch(pointCounter){
	                case 0:
	                    points += 10;
	                    break;
	                case 1:
	                    points += 8;
	                    break;
	                case 2:
	                    points += 6;
	                    break;
	                case 3:
	                   points += 4;
	                    break;
	            }
					lefiTime = 2;
					l.setPoints(points);
					pointCounter = 0;
					ce = "Correct!";
					
				}else {
					pointCounter++;
					guessCounter++;
					
					lefiTime--;
					
					ce = new String("");
						
					
					for(int i = 0 ; i < l.getCorrectWord().length(); i++) {
						
						if(l.getGuessWord().charAt(i) == l.getCorrectWord().charAt(i)) {
							
							ce +=l.getGuessWord().charAt(i);
							
						}else {
							ce += " _ " ;
							
							}
					
					}
					l.setGuessedChar(ce);
					
			}
				
			}	
			
			if(tempG) { //Get new word only when first is guessed // or when player has given up 
				l.shuffleWord(l.getRandomWord());
				lefiTime = 2;
				tempG = false;
				l.setGuessedChar(ce);
				
			}
			
			model.addAttribute("lingo" , l);
			model.addAttribute("checkLingo", lingo);
			
			
			
			
			return "lingoGame";
		}
		
		@PostMapping(value = "LingoGame")
		public String LingoGamePost(Model model ,Lingo lingo) {
			l.setGuessWord(l.Upper(lingo.getGuessWord())); //Insert player guessed word
			
			temp = 1;
			
			
			return LingoGameGet(model, lingo);

		}
		
		@GetMapping(value = "EndLingo")
			public String endLingo(Model model) {
				
				model.addAttribute("l", l);
				model.addAttribute("gc", guessCounter);
				model.addAttribute("wc", wordCounter);
				String name = l.getName();
				l = new Lingo(name);
				tempLife = 3;
				points = 0;
				guessCounter = 0;
				wordCounter = 0;
				temp = 0 ;
				tempG = true;
				ce = new String("");
				return "endLingo";
			
			}
		
}
