
package mylinkedqueue;

import java.util.Arrays;

/**
 *
 * @author nz
 */
public class Rinda<T> {
    
    private MyNode frontNode; //first element in the queue
    private MyNode rearNode; // last element in the queue
    private int length; //elements in the queue
    
    public Rinda(){
        frontNode = null;
        rearNode = null;
        length = 0;
                
    }
    
    public boolean isFull(){ //check if queue is full
        if(rearNode.getNext() == null ){
            return true;
        }else{
            return false;
        }
              
    }
    
    public boolean isEmpty(){ //check if queue is empty
        if(frontNode == null){
            return true;
        }else{
            return false;
        }
    }
    
    public int counter(){//return how many elements is in queue
        return length; 
    }
    
    public T inFront(){ //return front element of the queue
        if(isEmpty()){ //check if queue isn't empty
            System.out.println("Queue is empty");
            return null;
        }else{
            return (T)frontNode.element;//return front queue element
        }
        
    }
    
    public T inRear(){ //return rear element in the queue
        if(isEmpty()){ //check if queue isn't empty
            System.out.println("Queue is empty");
            return null;
        }else{
           return (T)rearNode.element; //return rear queue element
        }
    }
    
      public void enqueue( T item){ //Adding element to queue
          MyNode temp = rearNode; //Create MyNode veriable 
          rearNode = new MyNode(item); //set item to created veriable
          rearNode.element = item; //set queue element 
          rearNode.setNext(null); //set next element to the null
           length++;//increase length 
        if(isEmpty()){//check if queue is full
            frontNode = rearNode;   
        }
        else{
            
            temp.setNext(rearNode);//set next element to the rear queue element
             
        }   
    }
    
    public T dequeue(){ //Remove element for queue
        if(isEmpty()) //chekc if queue is empty
          System.out.println("Queue is empty");
       T item = (T) frontNode; //initialize item to front element of the queue
       frontNode = frontNode.getNext(); // initialize front elment to the next element of the queue
       length--; //decrease length by one

       return item; //return removed item .. 
        
    
    }
    
    public void makeEmpty(){ //Make queue empty
        rearNode = null; //set rear to null
        frontNode = null;//set fornt to null
        length = 0; //set lengt to 0
    }
    
   public void print(){ //print queue
       MyNode n = frontNode;
    while (n != null) { //while next elements isnt null
        System.out.print(n.getElement() + " "); //print elment
        n = n.getNext(); //set n to the next element
    }
   }
    
    
    public static void main(String[] args){
        Rinda rinda = new Rinda();
        System.out.print("Adding elements to the queue...\nQueue: ");
        rinda.enqueue(20); //Adding elements to the queue
        rinda.enqueue(22);
        rinda.enqueue(30);
        rinda.enqueue(35);
        rinda.enqueue(42);
        rinda.print(); //print queue
        System.out.println("\nThere is " + rinda.counter() + " elements int the queue"); //return how many elements is in queue
        System.out.println("Removing element from the queue");
        rinda.dequeue(); //remove front elment 
        System.out.print("Queue: ");
        rinda.print(); //print queue
        System.out.println("\nElements left in the queue " +rinda.counter()); //return how many elements is in queue
         System.out.println("First in the queue " + rinda.inFront()); //return front element
        System.out.println("Last in the queue " +rinda.inRear()); //return rear elements
        System.out.println("Making queue empty...");
         rinda.makeEmpty();//make queue empty
         
        System.out.println("Elements in queue: " + rinda.counter() ); //return how many elements is in queue
        System.out.println( "First in the queu " + rinda.inFront() + "\nLast in the queue " + rinda.inRear()); //returns front and rear element of the queue
  
}
}
