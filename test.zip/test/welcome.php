
<link rel="stylesheet" href="Regstyle.css">
<?php session_start(); 
 
 // Show registered users
 $mysqli = new mysqli("localhost", "root", "", "members");
 //Select queries return a resultset
 $sql = "SELECT username, avatar FROM users";
 $result = $mysqli->query($sql); //$result = mysqli_result object
 
 


?>
<div class = "return">
        <a href="index.html"><h6>Home page</h6>
        </a>
        </div>
        <div class = "bwelcome">
<div class="body content">
    <div class="welcome">
    
        <div class="alert alert-error"><?= $_SESSION['message'] ?> </br>
        Welcome </div>
        <?php
        $numResults = mysqli_num_rows($result);
        $counter = 0;
        while($row = mysqli_fetch_array($result)) {
            if (++$counter == $numResults) {
                echo "<div class='img'><span>$row[username]</span><br />";
            echo "<img src='$row[avatar]'></div>";
            } 
        } //returns associative array of fetched row
             
        
        ?>  
       <a href = 'welcome.php?action=ci'>Change avatar</a>
        
    
    <?php  //<button class = "update" onClick="window.location.reload()" > Update </button>
    //change picture

        

        if(@$_GET['action'] == 'ci'){
            echo'<form action = "welcome.php?action=ci" method = "POST" enctype ="multipart/form-data">
            <input type="file" name="avatar">
            <input type="submit" name = "change_pic" value= "Update" header("location: welcome.php") >';
            if(isset($_POST['change_pic'])){
               $errors = array();
               $allowed_e = array('png' , 'jpg' , 'jpeg' , 'gif');

               $file_name = $_FILES['avatar']['name'];
               $file_e = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
               $file_tmp= $_FILES['avatar']['tmp_name'];

                if(in_array($file_e, $allowed_e) === false){
                    $errors[] = '';
                }
                if(empty($errors)){
                    move_uploaded_file($file_tmp, 'images/' .$file_name);
                    $image_up = 'images/' .$file_name;
                    $sql = "SELECT * FROM users WHERE  username ='".@$_SESSION['username']."'";
                    $chech = mysqli_query($mysqli ,$sql);
                    $rows = mysqli_num_rows($chech);

                    while($row = mysqli_fetch_assoc($chech)){
                        $db_image = $row['avatar'];
                        
                    }
                    if($query = mysqli_query($mysqli,"UPDATE users SET avatar = '".$image_up."' WHERE username = '".$_SESSION['username']."'")){
                        echo "Your avatar has been updated.</br>";
                        echo "press 'Update' again to relode" ;
                    }
                } else{
                    foreach($errors as $error){
                        echo $error, '</br>';
                    }
                }
                    
                    
            }
            echo '</form>';
        }
        
        
        ?>

        <?php
        // Show registered users
        
        //Select queries return a resultset
        $sql = "SELECT username, avatar FROM users";
        $result = $mysqli->query($sql); //$result = mysqli_result object
        
        ?>
        <div id='registered'>
        <span>All registered users:</span></br>
        <?php
        while($row = $result->fetch_assoc()){ //returns associative array of fetched row
             echo "<div class='userlist'><span>$row[username]</span><br />";
            echo "<img src='$row[avatar]'></div>";
        }
        ?>  
        </div> 
       
    </div>
  
</div>
    </div>

