
package cardgame;

import javax.swing.JFrame;

/**
 *
 * @author nz
 */
public class CardGame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        
        JFrame window = new JFrame();
        
    }
    
}
