
package mylinkedqueue;
import static java.lang.System.exit;

/**
 *
 * @author nz
 */
class MyLinkedStack<T> { 
  
    // A linked list node 
    private class MyNode<T> { 
  
        int data; // integer data 
        MyNode next; // reference variavle Node type 
    } 
    // create globle top reference variable 
    MyNode topNode; 
    
    MyLinkedStack() 
    { 
        this.topNode = null; 
    } 
  
    // Add element to stack
    public void push(int x) 
    { 
        // create new node temp  
        MyNode temp = new MyNode(); 
  
        // check if stack is full. Then inserting an 
        //  element would lead to stack overflow 
        if (temp == null) { 
            System.out.print("\nHeap Overflow"); 
            return; 
        } 
  
        // initialize data into temp data field 
        temp.data = x; 
           
        // put top reference into temp link 
        temp.next = topNode; 
  
        // update top reference 
        topNode = temp; 
    } 
  
    // Utility function to check if the stack is empty or not 
    public boolean isEmpty() 
    { 
        return topNode == null; 
    } 
  
    // Utility function to return top element in a stack 
    public int top() 
    { 
        // check for empty stack 
        if (!isEmpty()) { 
            return topNode.data; 
        } 
        else { 
            System.out.println("Stack is empty"); 
            return -1; 
        } 
    } 
  
    //  pop top element from the stack 
    public void pop() // remove at the beginning 
    { 
        // check for stack underflow 
        if (topNode == null) { 
            System.out.print("\nStack Underflow"); 
            return; 
        } 
  
        // update the top pointer to point to the next node 
        topNode = (topNode).next; 
    } 
  
    public void display() 
    { 
        // check for stack underflow 
        if (topNode == null) { 
            System.out.printf("\nStack Underflow"); 
            exit(1); 
        } 
        else { 
            MyNode temp = topNode; 
            while (temp != null) { 
  
                // print node data 
                System.out.printf("%d->", temp.data); 
  
                // assign temp link to temp 
                temp = temp.next; 
            } 
        } 
    } 
} 
