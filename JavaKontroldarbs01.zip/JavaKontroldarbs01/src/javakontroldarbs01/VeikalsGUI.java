
package javakontroldarbs01;



import javafx.scene.control.Button;
import javafx.application.Application;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;




/**
 *
 * @author nz
 */
public class VeikalsGUI extends Application  {
    static public ArrayList<Product> AllProducts = new ArrayList<Product>();
    static int b1Count =0 ;
    static int b2Count =0;
    static int b3Count = 0;
    public static void main(String args[]){
        
        GenerateProductsInStore();
        GenerateProductsInStore();
        GenerateProductsInStore();
       launch(args);
       
       
      
    }

    
    public static void GenerateProductsInStore(){
        Random r = new Random();
        PhoneManufacturer shopPhone;
        boolean add = false;
        
        while(!add){
             int p = r.nextInt() % 2;
        Product product= null;
        if(p == 0){
            int phone = r.nextInt() % 2;
           Phone phone1 = new Phone((short) 16, PhoneManufacturer.Samsung, (short) 12, (float) 300.99 , "Galaxy s10", 10);
           Phone phone2 = new Phone((short) 8, PhoneManufacturer.SonyEricson, (short) 10, (float) 199.99, "X5", 19 );
           
           if( phone == 0 ){
               
               product = phone1;
      
        }else{
                product = phone2;
           }
        }else{
            int bread = r.nextInt() % 3;
            Calendar calendar  = Calendar.getInstance();
            calendar.add(Calendar.DATE, 2);
            Date now = calendar.getTime();
      
            Bread bread1 = new Bread((float) 0.5, now , BreadType.BlackBread,(float) 1.12 , "Fazer", 99);
             calendar.add(Calendar.DATE, 4);
             now = calendar.getTime();
            Bread bread2 = new Bread((float) 0.75, now , BreadType.FullGrain,(float) 0.99 , "Balta", 66);
            
             calendar.add(Calendar.DATE, 1);
             now = calendar.getTime();
             
            Bread bread3 = new Bread((float) 1, now , BreadType.whiteBread,(float) 1.75 , "Fazer", 45);
            switch (bread) {
                case 0:
                    product = bread1;
                    break;
                case 1:
                    product = bread2;
                    break;
                default:
                    product = bread3;
                    break;
            }
            
        }
        
        for(int i = 0; i < AllProducts.size() ; i++){
            if(AllProducts.get(i) == product){
                add = false;
                break;
        } else{
                add = true;
            }
        }
           
                AllProducts.add(product);  
            
             
  
        }
    
        
}
    
 
    
    @Override
    public void start(Stage stage) throws Exception {
    
         createShoppingScene(stage);
         
    }

    private void createShoppingScene(Stage stage) {
        
       stage.setTitle("Veikals");     
       VBox root = new VBox();
        Text text1 = new Text("Click on product to add product to shopping cart, click 'pirkt' to get check\n");
        root.getChildren().add(text1);
      ArrayList<Product> chosenProducts = new ArrayList<Product>();
       Button b1 = new Button(AllProducts.get(0).toString());
    
       b1.setOnAction(new EventHandler<ActionEvent>() {
           
           @Override        
           public void handle(ActionEvent t) {
               
               chosenProducts.add(AllProducts.get(0));
               Text b1Text = new Text(AllProducts.get(0).getTitle() + " cena "+ AllProducts.get(0).getPrice() + " daudzums "+ (++b1Count));
               //AllProducts.get(0).setAmount(AllProducts.get(0).getAmount() - b1Count);
               root.getChildren().add(b1Text);
           }
       });
       Button b2 = new Button(AllProducts.get(1).toString());
        b2.setOnAction(new EventHandler<ActionEvent>() {
           @Override
           public void handle(ActionEvent t) {
               chosenProducts.add(AllProducts.get(1));
               Text b2Text = new Text(AllProducts.get(1).getTitle() + " cena "+ AllProducts.get(1).getPrice() + " daudzums "+ (++b2Count));
               root.getChildren().add(b2Text);
           }
       });
        
       Button b3 = new Button(AllProducts.get(2).toString());
        b3.setOnAction(new EventHandler<ActionEvent>() {
           @Override
           public void handle(ActionEvent t) {
               chosenProducts.add(AllProducts.get(2));
               Text b3Text = new Text(AllProducts.get(2).getTitle() + " cena "+ AllProducts.get(2).getPrice() + " daudzums "+ (++b3Count));
               root.getChildren().add(b3Text);
           }
       });
       Button b = new Button("Pirkt");
        b.setOnAction(new EventHandler<ActionEvent>() {
           @Override
           public void handle(ActionEvent t) {
             Alert alert = new Alert (Alert.AlertType.INFORMATION, "", ButtonType.OK);
             alert.setTitle("Pirkums");
             
             
             for(int i = 0 ; i < chosenProducts.size(); i++){
                 alert.setHeaderText(chosenProducts.get(i).toString());
                 
             }
             Check check = new Check(chosenProducts);
             alert.setContentText("Kopa ar PVN: " + check.calcutaleTotalSum());
             alert.showAndWait();
           
               chosenProducts.clear();
           }
       });
       
       root.getChildren().addAll(b1,b2,b3,b);

     
      
      Scene scene = new Scene(root, 1000, 500);
      stage.setScene(scene);
      stage.show();
     
    }
    

  
    
    
  
    
    
    
}
