<?php
    //Create connection 
    $d = mysqli_connect('localhost','Nz','SpentCalc','SpenC') or die('Can not connect to database');
    $chs=mysqli_set_charset($d, "utf8");

    session_start();
    //declare session message
    $_SESSION['message'] = " ";
    if (isset($_POST['username']) and isset($_POST['password'])){
    
    $username = $_POST['username'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM User WHERE Username = '$username'" ;
    $res = mysqli_query($d,$sql);
    //check if there is matching username by row count
    $count = mysqli_num_rows($res); 
        if($count == 1 ){
        $row = mysqli_fetch_array($res);
            //check if hashed password match 
            if(password_verify($password,$row["Password"])){
                $_SESSION['username'] = $username;
                //Proceed to index.php page or main page. 
                header("Location: main.php");
            }else{
                $_SESSION["message"]="<span style = 'color:red;'>Incorect password or username!</span>";
            }
        
        }else{
            $_SESSION["message"]="<span style = 'color:red;'>Incorect password or username!</span>";
        }
}
?>

<html>
<body background="images.jpeg">
<head>
    <meta charset="UTF-8">
    <title > Log in </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
    </style>
   <h1>Log in</h1>
            <form action = "" method = "POST">
            <table>
            <tr>
            <td>Username:<input name="username" type="text" required></td>
            </tr>
            <?php echo $_SESSION["message"] ?>
            <tr>
            <td>Password:<input name="password" type="password" required ></td>
            </tr>
            </form>
            </table>
            <input type="submit" value="Log in" text-align:center;/>
         </div>
      </div>     
   </div> 
   <div id = "Login" >    
            <a href="Account.php">Sing Up</a>
            </div>
</body>
</html></div>