
package mylinkedqueue;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


/**
 *
 * @author nz
 */
public class Stack<T> {
    private int size;
    private int counter;
    private T[] stack;
    public Stack(int size){
        stack = (T[]) new Object[size]; //Creating T element array
        counter = 0 ;
        if(size < 0){
            this.size = 0;
        }else{
            this.size = size;
        }
    }
    public boolean isEmpty(){ //Check if stack is empty
        if(counter == 0){
            return true;
        }else{
            return false;
        }
    }
    
    public boolean isFull(){ //check if stack is full 
        if(counter == size){
            return true;
        }else{
            return false;
        }
    }
    
    public int returnCounter(){//returns how many elements is in stack
        return counter;
        
    }
    
    public void push(T element){//Add element on top of the stack
        if(isFull()){
            System.out.println("Stack is full");
        }else{
            stack[counter] = element;
            counter++;
        }
    }
    
    public void pop(){//Remove element from top of the stack
        if(isEmpty()){
            System.out.println("Stack is empty");
        }else{
            counter--;
        }
    }
    
    public T top(){//Returns stack top element
        if(isEmpty()){
            System.out.println("stack is empty");
            return null;
        }else{
            return stack[counter-1];
        }
    }
    
    public void print(){ //Prints stack
        for(int i = 0 ; i < counter; i++){
            System.out.print(stack[i]);
        }
    }
    
    public void makeEmpty(){ //Make stack empty
        counter = 0 ;//set counter to 0
    }
    
    public boolean Syntax(File code) throws FileNotFoundException{ //Check file syntax is correct by parenthese syntax
            boolean check = true; //return veriable
            Stack stack = new Stack(100);
            Scanner scan  = new Scanner(code); //set scanner veriable
            String c = null; //Scanned veriable
                
        while(scan.hasNextLine()){
            
             c = scan.nextLine(); //Set to scanned line
              
              for(int i = 0 ; i < c.length();i++){ //Goes trougth scanned string line
                  if(c.charAt(i) == '{' || c.charAt(i) == '[' || c.charAt(i) == '('){ //checks for opening parenthese
                      stack.push(c.charAt(i)); //Put in stack if find one
                      
                  }else if(c.charAt(i) == '}' || c.charAt(i) == ']' || c.charAt(i) == ')'){ //check for closing parenthese
                      char temp = (char) stack.top(); //set char to top of the stack element

                            if(c.charAt(i) == '}' && temp == '{' ){ //checks if parenthese maches
                                stack.pop();//remove top of stack element
                               
                            }
                            else if(c.charAt(i) == ']' && temp == '[' ){//checks if parenthese maches
                                stack.pop();//remove top of stack element
                               
                            }
                            else if(c.charAt(i) == ')' && temp == '(' ){//checks if parenthese maches
                                stack.pop();//remove top of stack element
                                
                            }else if (stack.isEmpty()){ //check if stack ist'n empty
                                 check = false; //set return veriable on false if stack is empty
                            }else{
                                check = false;//if no top opening parenthese machess to closing parenthese then set return veriable on false
                            }
                        
                  }
              }
        }
        if(!stack.isEmpty()){ //if stack is not empty
            check = false; //set return veriable to false
        }
        
       return check; //return
        
    }
}
