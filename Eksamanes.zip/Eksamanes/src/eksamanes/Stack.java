/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eksamanes;

/**
 *
 * @author nz
 */
public class Stack<T> {
    private int size;
    private int counter;
    private T[] stack;
    public Stack(int size){
        stack = (T[]) new Object[size]; //Creating T element array
        counter = 0 ;
        if(size < 0){
            this.size = 0;
        }else{
            this.size = size;
        }
    }
    public boolean isEmpty(){ //Check if stack is empty
        if(counter == 0){
            return true;
        }else{
            return false;
        }
    }
    
    public boolean isFull(){ //check if stack is full 
        if(counter == size){
            return true;
        }else{
            return false;
        }
    }
    
    public int returnCounter(){//returns how many elements is in stack
        return counter;
        
    }
    
    public void push(T element){//Add element on top of the stack
        if(isFull()){
            System.out.println("Stack is full");
        }else{
            stack[counter] = element;
            counter++;
        }
    }
    
    public void pop(){//Remove element from top of the stack
        if(isEmpty()){
            System.out.println("Stack is empty");
        }else{
            counter--;
        }
    }
    
    public T top(){//Returns stack top element
        if(isEmpty()){
            System.out.println("stack is empty");
            
            return null;
        }else{
            return stack[counter-1];
        }
    }
    
    public void print(){ //Prints stack
        for(int i = 0 ; i < counter; i++){
            System.out.print(stack[i]);
        }
    }
    
    public void makeEmpty(){ //Make stack empty
        counter = 0 ;//set counter to 0
    }
    
}