package com.example.demo.model;

public class Datahelper {
	private String datahelper;

	public String getDatahelper() {
		return datahelper;
	}

	public void setDataHelper(String datahelper) {
		this.datahelper = datahelper;
	}

	public Datahelper(String datahelper) {
		this.datahelper = datahelper;
	}

	public Datahelper() {
	}
	
	
	
	
	
}