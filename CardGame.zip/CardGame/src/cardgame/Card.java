
package cardgame;

import java.awt.BorderLayout;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author nz
 */


public class Card {
    private String  cardName, Suit;
    private  int facaValue;
    private BufferedImage cardImage;
    
      public static void main(String[] args) throws IOException {
        String Ace = "Ace";
        String Spade = "Spades";
        Card AceOfSpades = new Card(Ace, Spade, 14,ImageIO.read(new File("Ace_of_spades.png")) );
        
        
        
        //Create Jframe to display our card .
        JFrame window = new JFrame("Zolišu spēle");
        window.setSize(800,800); //Set size by pixel size
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //On click closes the Jframe
        window.setVisible(true);//Set frame visible by value true;
        
        //Create Jpanel - similar to JFrame
        
       JPanel contentPanel = new JPanel(new BorderLayout() ); //Create and Set panel layout
       
       
       //Create a JLabel - this is lika a sticky note you stick to your panel..
       JLabel cardLabel = new JLabel(new ImageIcon(AceOfSpades.getCardImage()));
       cardLabel.setSize(2,4); // set sticky note size
       
       contentPanel.add(cardLabel); //Add sticky note to a panel or JPanel
       window.add(contentPanel); //Add panel to a window or JFrame
       
       window.setVisible(true);
       
        
        
    }
      
    public Card(String cardName, String Suit, int facaValue, BufferedImage cardImage) {
        setCardName(cardName); 
        this.Suit = Suit;
        this.facaValue = facaValue;
        this.cardImage = cardImage;
    }

    public String getCardName() {
        return cardName;
    }

    public void setCardName(String cardName) {
        this.cardName = cardName;
    }

    public String getSuit() {
        return Suit;
    }

    public void setSuit(String Suit) {
        this.Suit = Suit;
    }

    public int getFacaValue() {
        return facaValue;
    }

    public void setFacaValue(int facaValue) {
        this.facaValue = facaValue;
    }

    public BufferedImage getCardImage() {
        return cardImage;
    }

    public void setCardImage(BufferedImage cardImage) {
        this.cardImage = cardImage;
    }

    @Override
    public String toString() {
        return "Card{" + "cardName=" + cardName + ", Suit=" + Suit + ", facaValue=" + facaValue +  '}';
    }

   
    
    
    
    
}
