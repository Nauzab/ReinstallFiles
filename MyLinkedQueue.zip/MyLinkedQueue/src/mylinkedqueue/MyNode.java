
package mylinkedqueue;

/**
 *
 * @author nz
 */
public class MyNode<T> {
    T element; //Data type
    private MyNode next;//indication to the next element
    
    public MyNode(T elemenet){
        setElement(element);
        setNext(next);
    }

    public T getElement() { //retuns element
        return element;
    }

    public void setElement(T element) { //set element
        this.element = element;
    }

    public MyNode getNext() { //retunrs indication to the next element
        return next;
    }

    public void setNext(MyNode next) {//sets indication to the next element
        this.next = next;
    }
    
    
}
