package com.example.demo.controllers;

import java.util.ArrayList;
import java.util.Random;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.Datahelper;
import com.example.demo.model.Student;
import com.example.demo.model.Variation;

@Controller
public class bingoController {
	
	public static ArrayList<User> allUsers = new ArrayList<>();
	private int id;
	public static ArrayList<Variation> allvariations = new ArrayList<Variation>();
	@GetMapping(value= "/hello")
	public String greeting() {
		
		System.out.print("hello");
		return "greeting";
	}
	
	@GetMapping(value= "/student")
	public String show(Model model) {
		Student newStudent = new Student("Nauris" , "Zablovskis");
		model.addAttribute("veriable", newStudent);
		return "student";
	}
	
	
	@GetMapping(value= "/auth")
	public String getAuth(User user) {
		
		return "auth";
	}
	
	@PostMapping(value= "/auth")
	public String postAuth(User user) {
		System.out.print(user);
		
		boolean isInSystem = false;
		
		for(User u: allUsers) { //check if match password and username 
			if(u.getPassword().equals(user.getPassword()) && u.getUsername().equals(user.getUsername())) {
				isInSystem = true;
				id = u.getId();
				break;
			}
		}
		if(!isInSystem) { //if user exists
			return "redirect:/insertvariation/" + id; //variation page .html
		}else { //else
			return "redirect:/error"; //erropage.html
		}
	}
	@GetMapping(value = "/insertvariation/{id}")
	public String insertvarioationGet(Datahelper dataHelper, Model model, @PathVariable(name = "id") int id)
	{
		model.addAttribute("actualUser", allUsers.get(id));//TODO pass actual user which is authorize
		return "insertvariation";
	}
	
	@PostMapping(value = "/insertvariation/{id}")
	public String insertvarioationPost(Datahelper datahelper, @PathVariable(name = "id") int id)
	{
		System.out.println(datahelper.getDatahelper());
		System.out.println(id);
		//TODO create Variation object, split string to 5 integers
		
		String[] numbersInString = datahelper.getDatahelper().split(",");
		ArrayList<Integer> numbersInInt = new ArrayList<>();
		for(int i = 0 ; i < numbersInString.length;i++) {
			numbersInInt.add(Integer.parseInt(numbersInString[i]));
		}
		
		//TODO get user object id
		User tempUser = null;
		for(int i = 0 ; i < allUsers.size() ; i++) {
			if(allUsers.get(i).getId() == id ) {
				tempUser = allUsers.get(i);
				break;
			}
		}
		
		Variation var = new Variation(numbersInInt, tempUser);
		allvariations.add(var);
		
		return "redirect:/showallvariations";
		
	}
			
	public String showAllVariations(Model model)
	{
		model.addAttribute("allvariationstopass", allvariations);
		
		return "showvariations";// showusers.html
	}
	
	
	@GetMapping(value="/showallusers")
	public String showAllUsers(Model model)
	{
		model.addAttribute("alluserstopass", allUsers);
		
		return "showusers";// showusers.html
	}
	
	@GetMapping(value= "/game")
	public String game(Model model) {
		//TODO generate 5 winning numbers
		Random rand = new Random();
		ArrayList<Integer> winningNumbers = new ArrayList<>();
		
		while(winningNumbers.size() < 5) {
			int tempNumber = rand.nextInt(35) + 1;
			if(!winningNumbers.contains(tempNumber)) //check if number is already in arraylist 
				winningNumbers.add(tempNumber); //if not then put number in arraylist
			
		}
		System.out.println(winningNumbers);
		//TODO check how many numbers are equals with winning numbers -  for each variations - for loop
		for(int i = 0 ; i < allvariations.size(); i++) {
			int howMany = 0 ;
			for(int j = 0 ; j < allvariations.get(i).getSelectedNumbers().size(); j++) {
				for(int j2 = 0 ; j2 < winningNumbers.size(); j2++) {
					
				if(allvariations.get(i).getSelectedNumbers().get(j) == winningNumbers.get(j2)) {
					howMany++;
				}
				}
			}
			allvariations.get(i).setCorrectNumbers(howMany);
					
		}
		//TODO send result to html
		model.addAttribute("winningNumbers", winningNumbers);
		model.addAttribute("allVariations", allvariations);
		
		//TODO create string from all variation include username, selected numbers and correct numbers
		return "game";
	}
}
