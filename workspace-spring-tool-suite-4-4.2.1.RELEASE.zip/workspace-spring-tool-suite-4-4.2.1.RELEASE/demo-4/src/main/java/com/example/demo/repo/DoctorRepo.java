package com.example.demo.repo;

import org.springframework.data.repository.CrudRepository;


import com.example.demo.model.Doctor;


public interface DoctorRepo extends CrudRepository<Doctor, Integer> {
	Doctor findById(int id);
}
