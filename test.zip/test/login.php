

<link rel = "stylesheet" href="Regstyle.css">
    <div class="body-content">
  <div class="module">
  <div class = "return">
        <a href="index.html"><h6>Home page</h6>
        </a>
        </div>
    <h1>Log In</h1>
   
    <form class="form" action="login.php" method="POST" enctype="multipart/form-data" autocomplete = "OFF" >
      
      <input type="text"placeholder="Username" name="username" autocomplete = "OFF" required />
      <input type="password" placeholder="Password" name="password" autocomplete="new-password" required />
      <input type="submit" value="Login" name="submit" class="btn-primary" require/>
      <a href="register.php"><h4>Create an accont !</h4> </a></br>
   
      
    </form>
  </div>
</div></br>

<?php
$mysqli = new mysqli("localhost", "root", "", "members");   
   
$username = @$_POST['username'];
$password = @$_POST['password'];

if(isset($_POST['submit'])){
  if($username && $password){
    $sql = "SELECT * FROM users WHERE  username ='".$username."'";
    $chech = mysqli_query($mysqli ,$sql);
    $rows = mysqli_num_rows($chech);

    //Finds username in database
    
    if(mysqli_num_rows($chech) != 0){
      $db_username = "";
      $db_password = "";
      while($row = mysqli_fetch_assoc($chech)){
       $db_password = $row['password'];
       $db_username = $row['username'];
       echo $row['username'];
      } //sha1 gives code to password; 
      if($username == $db_username && md5($password) != $db_password){
        echo "Logged in ";
        header("location:welcome.php");
      }else{
        echo "Your password is wrong";
      }
    }
    }else{
      die("Could't find username.");
  }
}

?>
<?php /*
  if(isset($_POST['submit'])){
    if(!empty($_POST['username']) && !empty($_POST['password'])){
      $username = $_POST['username'];
      $password = $_POST['password'];
      //Data base connection

      $mysqli = new mysqli("localhost", "root", "", "members" ) or die(mysqli_error());   
      //selecting database
      $sql = "SELECT * FROM users WHERE  username ='".$username."' AND password = '".$password."'";
      $db = mysqli_select_db($mysqli, $sql);
      $chech = mysqli_query($mysqli ,$sql);
      $rows = mysqli_num_rows($chech);

      if($rows == 0){
        $dbusername = '' ;
        $dbpassword ='' ;
        while($row = mysqli_fetch_assoc($chech)){
            $dbusername = $row['username'];
            $dbpassword = $row['password'];
        }
        if($username == $dbusername && $password == $dbpassword){
          session_start();
          $_SESSION['sess_user'] = $username;
          //redirect browser
          header("Location:welcome.php");
        }
      }
      else{
        echo "Invalid Username or Password!";
      }
      
    }else{
        echo "Required ALL fields!";
  }
    }
?>*/
?>