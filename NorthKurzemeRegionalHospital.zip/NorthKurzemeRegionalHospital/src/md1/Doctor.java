/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package md1;

/**
 *
 * @author nz
 */
public class Doctor extends Person{
     private short officeNum  ;
     private int doctorID ;
     private int doctorCounter;
     private Speciality speciality;

    public Doctor(short officeNum, Speciality speciality, String name, String surname, int[] identicator, Gender gender, Nationality nationality) {
        super(name, surname, identicator, gender, nationality);
        
       setOfficeNum(officeNum);
        
        this.speciality = speciality;
    }
     
     
     
    public short getOfficeNum() {
        return (short) officeNum;
    }

    public void setOfficeNum(short officeNum) {
        //check if Doctor arraylists is not empty
       
        if(Doctor.isEmpty()){
            this.officeNum = officeNum;
      }else{
            //Checks if there is doctor in that office already
            for(int i = 0 ; i < Doctor.size() ; i++){
                //if is then change office number to one bigger
                if(Doctor.get(i).getOfficeNum() == officeNum){
                    this.officeNum = (short) (Doctor.get(Doctor.size() -1).getOfficeNum() +1);
                    
                }
               
            }
        }
        
    }

    public int getDoctorID() {
        return doctorID;
    }

    public void setDoctorID(int doctorID) {
        this.doctorID = doctorID;
        
    }

    public int getDoctorCounter() {
        return doctorCounter;
    }

    public void setDoctorCounter(int doctorCounter) {
        this.doctorCounter = doctorCounter;
    }

    public Speciality getSpeciality() {
        return speciality;
    }

    public void setSpeciality(Speciality speciality) {
        this.speciality = speciality;
    }

    @Override
    public String toString() {
        return super.toString() + "Doctor{" + "officeNum=" + officeNum + ", doctorID=" + doctorID + ", doctorCounter=" + doctorCounter + ", speciality=" + speciality + '}';
    }
     

   
}
