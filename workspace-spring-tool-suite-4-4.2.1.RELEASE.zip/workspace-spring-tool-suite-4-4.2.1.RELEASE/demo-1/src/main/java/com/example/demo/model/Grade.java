package com.example.demo.model;




import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "GradeTable")

public class Grade {
	@Id //id can't be null
	@GeneratedValue(strategy = GenerationType.AUTO) //auto generating id
	@Column(name = "Id_g")
	private int id_g;
	
	@Column(name = "GradeValue")
	private int gradeValue;
		
	@ManyToOne
	@JoinColumn(name = "Id_s")
	private Student student;
	
	
	@ManyToOne
	@JoinColumn(name = "Id_c")
	private Course course;
	
	
	
	public int getId_g() {
		return id_g;
	}
	public void setId_g(int id_g) {
		this.id_g = id_g;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public Course getCourse() {
		return course;
	}
	public void setCourse(Course course) {
		this.course = course;
	}
	
	

	public int getGadeValue() {
		return gradeValue;
	}
	public void setGadeValue(int gradeValue) {
		this.gradeValue = gradeValue;
	}
	
	public Grade( Student student, Course course, int gradeValue) {
		super();
		
		this.student = student;
		this.course = course;
		this.gradeValue = gradeValue;
	}
	
	public Grade() {
		super();
	}
	
	
}
