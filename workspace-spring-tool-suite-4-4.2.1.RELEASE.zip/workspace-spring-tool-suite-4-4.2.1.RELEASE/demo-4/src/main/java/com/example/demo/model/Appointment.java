/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.demo.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name = "Appointment")
public class Appointment {
    
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id_a")
	private int appID;
    
	
	@Column(name = "appCounter")
    private int appCounter =1;
	
	@Column(name = "Date")
    private Date date;
	
	@Column(name = "description")
	private String description;

	@OneToOne(cascade = {CascadeType.ALL})
	@JoinColumn(name = "Id_d")
	private Doctor doctor;
	
	@OneToOne(cascade = {CascadeType.ALL})
	@JoinColumn(name = "Id_p")
    private Patient patient;
	
    
    public Appointment() {}
    
    public Appointment(Date date, String description, Patient patient, Doctor d1) {
        
        setDoctor(d1);
        setDate(date);
        this.description = description;
        this.patient = patient;
        setAppCounter(appCounter);
        appCounter++;
        
        
    }

    public int getAppID() {
        return appID;
    }

    public void setAppID(int appID) {
        this.appID = appID;
    }

    public int getAppCounter() {
        return appCounter;
    }

    public void setAppCounter(int appCounter) {
        this.appCounter = appCounter;
    }


    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        //checks if date is between 1 and 31 AND checks if month is between 1 and 12  //getMonth starts with 0 
        if(date.getDate() >= 1 || date.getDate() <= 31 || date.getMonth() +1 >= 1 || date.getMonth() +1 <= 12){
            this.date = date;
        }
        else {
        this.date = null;
        }
        
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Doctor getDoctor() {
       
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        
        this.doctor = doctor;
        
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }


  
    @Override
    public String toString() {
        return "Appointment{" + "appID=" + appID + ", appCounter=" + appCounter + ", date=" + date + ", description=" + description + ", Doctor=" + doctor + ", patient=" + patient + '}';
    }
    
    
}