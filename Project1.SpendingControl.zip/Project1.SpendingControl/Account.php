<?php 


// Create connection
$d = mysqli_connect('localhost','Nz','SpentCalc','SpenC') or die('Can not connect to database');
$chs=mysqli_set_charset($d, "utf8");
 
 session_start();

 $_SESSION["message"] = " ";
if ($_POST["submit"]){
    //Check if all ailes are filled
    if($_POST["username"] && $_POST["password"] && $_POST["repassword"] )
    {   
        //set veriables
    $username = $_POST["username"];
    $password = $_POST["password"];
    $hash = password_hash($password, PASSWORD_DEFAULT); //Hash password
    $repassword = $_POST["repassword"];
    //check if password is atleast 8 characters long
    if(strlen($password) >= 8 ){

        //Check if password matches a hash 
    if(password_verify($password, $hash)){
    //check if two passwords match 
        if( $password == $repassword){

            $sql = "SELECT * from User WHERE Username = '$username'";
            $res = mysqli_query($d,$sql);
            $count = mysqli_num_rows($res);
            if($count == 0){
            //Insertions into database
            $sql="INSERT INTO User (Username, password)values('$username','$hash')";
       
            if (mysqli_query($d, $sql)) {
                $_SESSION['username'] = $username; 
                header("Location: main.php");
            } else {
                $_SESSION["message"] = "<span style = 'color:red;'>Something went wrong..!</span>"; 
            }
        } 
        else{
           $_SESSION["message"] = "<span style = 'color:red;'>Username already exist!</span>";    
        }
    }
    else{
        $_SESSION["message"]="<span style = 'color:red;'>Passwords do not match!</span>";
    }
    }else{
        $_SESSION["message"] = "<span style = 'color:red;'>Password is not valid!</span>";
    }
    }
    else{
        $_SESSION["message"] = "<span style = 'color:red;'>Password must contain atleast 8 characters!</span>";
    }
    }
      
}
?>
 
<!DOCTYPE html>
<html lang="en">
<body background="images.jpeg">
<head>
    <meta charset="UTF-8">
    <title>Reģistrēties</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
    </style>
<h1>Create accont</h1>
<FORM ACTION="" METHOD="POST">
<table >
<div id = "Style" >
<tr>
<td>Username:</td><td><input name="username" type="text" required></td>
</tr><?php echo $_SESSION["message"] ?>
<tr>
<td>Password:</td><td><input name="password" type="password" required></td>
</tr>
<tr>
<td>Re-enter Password:</td><td><input name="repassword" type="password" required></td>
</tr>
</table>
 <input type="submit" name = "submit" value="Submit"/>
</div>

</FORM>
</body>
</html>