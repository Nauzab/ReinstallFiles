
package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "User")
public class User {
	
	@Column(name = "Username")
	private String username;
	
	@Column(name = "Password")
	private String password;
	
	@Column(name = "IsVoted")
	boolean isVoted = false;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id_u")
	private int id_u;
	
	private static int userCounter = 1;
	
	public User() {
		
	}
	public User(String username, String password) {
		
		this.username = username;
		this.password = password;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getId() {
		return id_u;
	}
	public void setId(int id_u) {
		this.id_u = id_u;
	}
	public static int getUserCounter() {
		return userCounter;
	}
	public static void setUserCounter(int userCounter) {
		User.userCounter = userCounter;
	}
	public boolean isVoted() {
		return isVoted;
	}
	public void setVoted(boolean isVoted) {
		this.isVoted = isVoted;
	}
	@Override
	public String toString() {
		return "User [username=" + username + ", password=" + password + ", isVoted=" + isVoted + ", id_u=" + id_u
				+ "]";
	}
	
	
	
	
}
