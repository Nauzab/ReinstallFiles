
package javasem04;

import java.util.ArrayList;

/**
 *
 * @author nz
 */
public  class Person {
    //1.verialbes
    
    private String name;
    private String surname;
    private ArrayList person = new ArrayList<>();
    
    //2.constructors
    
    public Person(){
        name = "Annonymous";
        surname = "wannabe";
        
    }
    
    //3.get and set
    public Person(String name, String surname){
        setName(name);
        setSurname(surname);
    }
    
    //4.toString() function

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }
    @Override
public String toString() {
        return "Student{" + name + surname + '}';
    }

}