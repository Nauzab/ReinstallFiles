package com.example.demo.repo;


import java.util.ArrayList;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Appointment;
import com.example.demo.model.Doctor;
import com.example.demo.model.Patient;



public interface AppointmentRepo extends CrudRepository<Appointment, Integer> {

	
		ArrayList<Appointment> findByPatient(Patient patient);
		ArrayList<Appointment> findByDoctor(Doctor doctor);
}
