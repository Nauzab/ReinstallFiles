<?php
  // Create connection
  $d = mysqli_connect('localhost','Nz','SpentCalc','SpenC') or die('Can not connect to database');
  $chs=mysqli_set_charset($d, "utf8");
 
 session_start();
 echo $_SESSION['amount'];

?>

<!DOCTYPE html>
<html>
<title>Follow your expenses</title>
<link rel="stylesheet" href="main.css" type="text/css" >
<body background="../background1.png">


<!-- Login/Singin buttons -->
<div class = "button">

 <?php
 //if username has not set yet, then echo login/singin buttons with popfunction 
 if(!isset($_SESSION['username'])){
 $value = '"modal-wrapper"'; //id for login
 $value1 = '"modal-wrapper1"'; //id for sing up 
  echo "<button onclick='popfunction($value)' >
  Log in</button> ";

  echo "<button onclick='popfunction($value1)'>
  Sing up</button> ";}
  else{
    echo "<form><button class = 'logout' formaction = 'logout.php' >Log out</button></form>";

  }
    ?>
</div>



<!--Login form -->
<div id="modal-wrapper" class="modal">
  
  <form class="modal-content animate" action="Login.php" method = "POST">
        
    <div class="imgcontainer">
      <span onclick="document.getElementById('modal-wrapper').style.display='none'" class="close" title="Close">&times;</span>
      <img src="1.png" alt="Avatar" class="avatar">
      <h2 style="text-align:center">Log in</h2>
    </div>
    <div class="container">
   
      <input type="text" placeholder="Enter Username" name="username">
      <input type="password" placeholder="Enter Password" name="password">        
      <input type="submit" name = "Lsubmit" value = "Login">
      <input type="checkbox" style="margin:26px 30px;"> Remember me      
      <a href="#" style="text-decoration:none; float:right; margin-right:34px; margin-top:26px;">Forgot Password ?</a>
        
    </div>
    
  </form>
  
</div><h1>Fallow your expenses</h1>



<!--Sing up form -->
<div id="modal-wrapper1" class="modal1">
  
  <form class="modal-content1 animate" action="Account.php" method = "POST">
        
    <div class="imgcontainer">
      <span onclick="document.getElementById('modal-wrapper1').style.display='none'" class="close" title="Close">&times;</span>
      <h2 style="text-align:center">Sing up</h2>
    </div>

    <div class="container">
      <input type="text" placeholder="Enter Username" name="username">
      <input type="password" placeholder="Enter Password" name="password"> 
      <input type="password" placeholder="Re-Enter Password" name="repassword">        
      <input type="submit"  name = "Ssubmit" value = "Sing up">
    
    </div>
    
  </form>
  
</div>


<div class = "blank"></div>



<!--IF USER HAS BEEN LOGGED IN DISPLAY USER TABLE PHP -->


<?php
  if(isset($_SESSION['username'])){
        
  ?>
  <form class  = 'Userform' action = 'Index.php' method = 'POST'>
  <div class = 'index' >
  <table>

  <div class = 'main'>
    <?php echo $_SESSION['username']?><br>
    Income
    <input class = 'input'   name='amount' type='text' value = ' ' required ><br>
    <input name = 'asubmit' type = 'submit' value = 'Submit' required ><br>
    
    
    Spences
    <input class = 'input' name='spent' type='text' value = ' ' required >
    <input name = 'ssubmit' type = 'submit' value = 'Submit' required>
  </div>
  </div> 
  </table>
  </form>

    <div class = 'output'>
        <?php
            $sql1 = "SELECT SUM(s.Spent) from spenc s JOIN Amount a where s.Uid = a.Uid";
            
            $sql_res1 = mysqli_query($d,$sql1) or die("<h1>".mysqli_error()."</h1>");
            $row = mysqli_fetch_array($sql_res1);
            echo "This month spending total <br>";
            echo "<h2>".$row[0]."</h2>";
        ?>
    
    </div>
    </div>
  <button type = "button" onclick = 'popfunction("modal-wrapper2")'>Calculator </button>
    
    <div id="modal-wrapper2" class="modal2">
  
  <form class="modal-content2 animate" action="" method = "POST">
        
    <div class="imgcontainer1">
      <span onclick="document.getElementById('modal-wrapper2').style.display='none'" class="close" title="Close">&times;</span>
      <h2 style="text-align:center">Calculator</h2>
    </div>

    <div class="container">
         
        <?php
        $sql = "SELECT s.id as 'Nr', s.Spent, s.date ,s.Aleft as 'Left' from spenc s JOIN User u ON Uid = u.id order by Nr DESC";  
        $sql_res = mysqli_query($d,$sql) or die("<h1>".mysqli_error()."</h1>");
        table($sql_res);
       ?>
    </div>
    </div>
    </form>
    
  <?php
    }
?>



<!--Information slides -->
<div class = "info">
    <h2> 10 ways to save money </h2> 
    <p>Tips given by ordenary people</p><br>
    <img src = "Infimg.jpg" alt = "" heigth = "450" width = "650">
    <p>It’s easy to waltz down the grocery store aisle and fill up your basket with things that aren’t on the list.
        Maybe it’s the florescent lighting, strategically placed products at checkout, or that squeaky wheel on the cart 
        that messes with our sanity—and our budget.</p><br>

        <p>We get it. Shopping for groceries can kind of bring out your crazy side! But it doesn’t have to be that way.
        We enlisted the help of <a href = "https://www.facebook.com/daveramsey" color = 'blue' >Dave’s Facebook fans</a> 
        to share how they save money on groceries while keeping their budget on track.
        Check out some of their best tips!</p><br>
        
        <h3>1. Crunch some numbers while you shop. </h3>
        <p class = "p">“Stick to your list and use a calculator as you shop to stay under budget. We’re under $50 a week for our family 
        (two adults and a toddler). No junk food either. It’s doable!” — Amanda N.</p><br>

        <h3>2. Get creative with the food you have on hand.</h3>
        <p class = "p">“Don’t feel like you need to buy something just because you’re out of it. Raid your pantry and fridge for substitutes first.
        Make your meal plans around what you already have.” — Carla A.</p><br>

        <h3>3. Start freezing and storing meals now.</h3>
        <p class = "p">“Cook big meals and divide leftovers into portions and freeze them. Freeze as much as you can from your shopping. 
            Nothing beats already having it.” — Anthony R.</p><br>

        <h3>4. Round up your grocery cost estimates.</h3>
        <p class = "p">“I use tally marks to keep track of what I’m spending, and I always round up every item. Even if the item is $1.29,
            it gets two tally marks. That way, by the time I check out, I’m both aware of approximately what to expect and surprised 
            to still be under what I wanted to spend.” — Jilian H.</p><br>

        <h3>5. Use the envelope system.</h3>
        <p class = "p">“Use the envelope system and put unnecessary items at the end of the counter. I would tell the cashier I only had a certain 
            amount of money to spend and to stop when I got to that point. Instead of it being an embarrassment, it was a bonding moment 
            for me and the cashier when I made my goal, or even if it didn’t work out.” — Jan B.</p><br>

        <h3>6. Don’t allow for budget-breaking surprises.</h3>
        <p class = "p">“Our grocery store offers ‘scan it.’ You can walk around with a scanner and scan your items as you shop. 
            It keeps a total for you so you’re never surprised at the register—and you can decide if you really need certain things.” — Jamie M.</p><br>

        <h3>7. Stick to a meal plan.</h3>
        <p class = "p">“Meal plan ahead of time with your favorite store’s ad in hand. Buy larger quantities of what’s on sale and freeze it. Stick to your list. 
            And never grocery shop hungry!” — Nikki G.</p><br>

        <h3>8. Don’t buy more than you need.</h3>
        <p class = "p">“Just because something is marked two for $5, four for $10, etc., doesn’t mean you have to buy that many items. 
            You get the same discounted price if you buy just one.” — Stacy H.</p><br>

        <h3>9. Test out your green thumb.</h3>
        <p class = "p" >“Try growing a garden. There’s an initial investment, but it pays off in terms of produce for the year.” — Ash B.</p><br>

        <h3>10. Shop online and pick up at the store.</h3>
        <p class = "p">“My wife makes a list and then orders all the groceries online. We pull up at the store and they bring them out to the car and help load them in. 
            It is convenient, saves time, and there is no impulse buying inside the store while walking around with the kids.” — Matthew G.</p><br>

      
</div>



  <!--Function for Login/Singup -->
<script class ='function'>
  // If user clicks anywhere outside of the modal, Modal will close
  //For login
  var modal = document.getElementById('modal-wrapper');
  //For sing up 
  var modal1 = document.getElementById('modal-wrapper1');
  //For user info / USERFORM FORM
  var modal2 = document.getElementById('modal-wrapper2');
  
  window.onclick = function(event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
    if(event.target == modal1){
      modal1.style.display = "none";
    }
    if(event.target == modal2){
      modal2.style.display = "none";
    }
  };
  
  function popfunction(parameter){
      document.getElementById(parameter).style.display = "block";
  }
</script>






<!--LOGIN PHP FORM  // DELETE THIS -->
<?php
    //declare session message
    $_SESSION['message'] = " ";
    if($_POST['Lsubmit']){

      if ($_POST['username'] and $_POST['password']){
      
      $username = $_POST['username'];
      $password = $_POST['password'];
      $sql = "SELECT * FROM User WHERE Username = '$username'" ;
      $res = mysqli_query($d,$sql);
      //check if there is matching username by row count
      $count = mysqli_num_rows($res); 
          if($count == 1 ){
          $row = mysqli_fetch_array($res);
              //check if hashed password match 
              if(password_verify($password,$row["Password"])){
                  $_SESSION['username'] = $username;
                  //Proceed to index.php page or main page. 
                  header("location: test.php");
              }else{
                  $_SESSION["message"]="<span style = 'color:red;'>Incorect password or username!</span>";
              }
          
          }else{
              $_SESSION["message"]="<span style = 'color:red;'>Incorect password or username!</span>";
          }
      }
    }
?>



<!--SINGUP PHP FORM // DELETE THIS-->
<?php
 $_SESSION["message"] = " ";
 if ($_POST["Ssubmit"]){
     //Check if all ailes are filled
     if($_POST["username"] && $_POST["password"] && $_POST["repassword"] )
     {   
         //set veriables
     $username = $_POST["username"];
     $password = $_POST["password"];
     $hash = password_hash($password, PASSWORD_DEFAULT); //Hash password
     $repassword = $_POST["repassword"];
     //check if password is atleast 8 characters long
     if(strlen($password) >= 8 ){
 
         //Check if password matches a hash 
     if(password_verify($password, $hash)){
     //check if two passwords match 
         if( $password == $repassword){
 
             $sql = "SELECT * from User WHERE Username = '$username'";
             $res = mysqli_query($d,$sql);
             $count = mysqli_num_rows($res);
             if($count == 0){
             //Insertions into database
             $sql="INSERT INTO User (Username, password)values('$username','$hash')";
        
             if (mysqli_query($d, $sql)) {
                 $_SESSION['username'] = $username; 
                 header("Location: main.php");
             } else {
                 $_SESSION["message"] = "<span style = 'color:red;'>Something went wrong..!</span>"; 
             }
         } 
         else{
            $_SESSION["message"] = "<span style = 'color:red;'>Username already exist!</span>";    
         }
     }
     else{
         $_SESSION["message"]="<span style = 'color:red;'>Passwords do not match!</span>";
     }
     }else{
         $_SESSION["message"] = "<span style = 'color:red;'>Password is not valid!</span>";
     }
     }
     else{
         $_SESSION["message"] = "<span style = 'color:red;'>Password must contain atleast 8 characters!</span>";
     }
     }
       
 }
 
?>



<!--SET UP USER INSERTION PHP / SHOWS DB INFO IN USERFORM FORM / DELETE OR TAKE COMMENT OFF--> 
 
<?php
 function table($sql_res){
    echo "<center><table class=\"table\">";
    $first = true;
    while ($row = mysqli_fetch_assoc($sql_res)) {
        if ($first) {
            echo "<tr>";
            foreach ($row as $k=>$v) { 
                
                echo  "<th>$k</th>";
            
            }
            echo "</tr>".PHP_EOL;
            $first = false;
        }
        echo "<tr> ";
        
            foreach ($row as $v) {
                echo "<td>$v</td>";
                
            }
            
            echo "</tr>".PHP_EOL;
            
    }
    
    
    echo "</table></center>";
    
    $row_cnt = mysqli_num_rows($sql_res);
    
    /* close result set */
    mysqli_free_result($sql_res);
}
?>


</body>
</html>