package com.example.service;

import java.util.ArrayList;

import com.example.model.User;

public interface UserService {
	
	ArrayList<User> findAllUsers();
	boolean authorizeByEmail(String email, String password);
	boolean authorizeByUsername(String username, String password);
	boolean updateById(int id);
	boolean newUser(User user);
	
}
