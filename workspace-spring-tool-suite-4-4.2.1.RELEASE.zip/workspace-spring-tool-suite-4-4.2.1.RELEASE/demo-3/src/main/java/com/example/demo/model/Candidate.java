package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;



@Entity
@Table(name = "Candidate")
public class Candidate {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id_c")
	private int Id_c;
	
	@Column(name = "Name")
	private String name;
	
	@Column(name = "Surname")
	private String surname;
	
	@Column(name = "Votes")
	private int votes;
	
	@ManyToOne
	@JoinColumn(name = "Id_p")
	private Party party;
	
	Candidate(){
		super();
	}


	public Candidate( String name, String surname, int votes, Party party) {
		super();
		this.party = party;
		this.name = name;
		this.surname = surname;
		this.votes = votes;
	}


	public int getId_c() {
		return Id_c;
	}


	public void setId_c(int id_c) {
		Id_c = id_c;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getSurname() {
		return surname;
	}


	public void setSurname(String surname) {
		this.surname = surname;
	}


	public int getVotes() {
		return votes;
	}


	public void setVotes(int votes) {
		this.votes = votes;
	}


	public Party getParty() {
		return party;
	}


	public void setParty(Party party) {
		this.party = party;
	}


	@Override
	public String toString() {
		return super.toString() + "Candidate [Id_c=" + Id_c + ", name=" + name + ", surname=" + surname + ", votes=" + votes + ", party="
				+ party + "]";
	}
	
	
}

