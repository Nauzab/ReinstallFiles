package com.example.demo.model;

import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Party")
public class Party {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id_u")
	private int Id_p;
	
	@Column(name = "Title")
	private String title;
	

	@OneToMany(mappedBy = "party")
	private Collection<Candidate> candidatesInParty;//collection of grades
	
	public Party() {}
	
	public Party(String title) {
		super();
		
		this.title = title;
	}

	public int getId_p() {
		return Id_p;
	}

	public void setId_p(int id_p) {
		Id_p = id_p;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public String toString() {
		return "Party [Id_p=" + Id_p + ", title=" + title + "]";
	}
	
	
}
