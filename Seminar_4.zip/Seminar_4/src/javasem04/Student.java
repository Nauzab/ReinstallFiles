/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javasem04;

import java.util.Arrays;

/**
 *
 * @author nz
 */
public class Student extends Person {
    private int kurss;
    private String faculty;
   
    
    public Student(String name,  String surname, String faculty, int kurss) {
        super(name, surname); //get name from Person class
       setFaculty(faculty);
       setKurss(kurss);
        
        
    }

    public int getKurss() {
        return kurss;
    }

    public void setKurss(int kurss) {
        this.kurss = kurss;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    @Override
    public String toString() {
        return "Student{" + "kurss=" + kurss + ", faculty=" + faculty + '}';
    }
    
    
}    
    


    