/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javasem04;

import java.util.ArrayList;

/**
 *
 * @author nz
 */
public class Professor extends Person {
    
   private ArrayList subject = new ArrayList<>();

    public Professor(String name, String surname, ArrayList subject ) {
        super(name, surname);
       
        
    }

    public ArrayList getSubject() {
        return subject;
    }

    public void setSubject(ArrayList subject) {
        this.subject = subject;
    }

    @Override
    public String toString() {
        return "Professor{" + "subject=" + subject + '}';
    }

  
    
    
}
