
package javasem04;
import javasem04.activity.*;
import javax.swing.text.html.ListView;
/**
 *
 * @author nz
 */
public class lectureApp {
        
    private String topic;
    private String date;
    private String time;
    private String place;
    Person lecture;
    StudentList participants;
   
    
    public static void main(String[] args) {
        ListView participants;
     
    }

    public lectureApp(String topic, String date, String time, String place, javasem04.Person lecture, StudentList participants) {
        this.topic = topic;
        this.date = date;
        this.time = time;
        this.place = place;
        this.lecture = lecture;
        this.participants = participants;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }
    
    public int getNumberOfParticipants(){
        return participants.getList().size();
    }
    
    public String getLectureName(){
        return lecture.getName();
    }

    @Override
    public String toString() {
        return "lectureApp{" + ", date=" + date + ", time=" + time +  "topic=" + topic + ", lecturer=" + getLectureName() + ", place=" + place +", participants=" + getNumberOfParticipants() + '}';
    }
    
    
}
