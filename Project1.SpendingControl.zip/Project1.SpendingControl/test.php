<?php 

  // Create connection
  $d = mysqli_connect('localhost','Nz','SpentCalc','SpenC') or die('Can not connect to database');
  $chs=mysqli_set_charset($d, "utf8");
 
  session_start(); 

  $Susername = $_SESSION["username"];//set session username 
  $message = $_SESSION['message'] = "";//set session message
  
  echo "THERE IT IS  = ", $samount , " // " , $_SESSION['amount'],"/"; 

  

  //----------FOR AMOUNT TABLE-------------//
 if(isset($_SESSION['username'])){ 
  if($_POST['asubmit']){//if submited amount 
      if($_POST['amount']){//if set amount
          $amount = $_POST['amount'];
          
          //Check if user has already set amount in amount table  
          $res = mysqli_query($d,"SELECT a.* FROM Amount a JOIN User u ON a.Uid = u.id WHERE u.Username = '$Susername'");
          $count = mysqli_num_rows($res);
          $row = mysqli_fetch_array($res);
          //if there are row/s that matche/s
          if($count >= 1 ){
          
              //allow next insert after 28 days 
                  $res1 = mysqli_query($d,"SELECT date + INTERVAL 28 DAY FROM Amount WHERE Uid = $row[1]");
                  $count1 = mysqli_num_rows($res1);
                  $row1 = mysqli_fetch_array($res1);
                  $date = $row1[0]; //set veriable to database date
                  //compare todays date vs database date + 28 days
                  
                  if( date('Y-m-d h:i:s') == $date){ //if todays date is bigger, then execute
                      $sql = "INSERT INTO Amount (Amount) VALUES ('$amount')";
                      $sql1 = "UPDATE Amount SET Uid = (SELECT id From User WHERE Username = '$Susername')";
                      $sql2 = "UPDATE Amount SET month = Month(date) where id = MAX(id)";
                      if(mysqli_query($d,$sql) && mysqli_query($d,$sql1) && mysqli_query($d,$sql2)){   
                          $_SESSION['amount'] = $amount;
                          //header("Refresh:1");
                      }  
                  }  
              else{
                      $message ="You will be able to add after ".$date."";
                      
              } 
          } 
          else{ //if NEW user input.
              $sql = "INSERT INTO Amount (Amount) VALUES ('$amount')";
              $sql1 = "UPDATE Amount SET Uid = (SELECT id From User WHERE Username = '$Susername') WHERE AID()";
              $sql2 = "UPDATE Amount SET month = Month(date)";
              if(mysqli_query($d,$sql) && mysqli_query($d,$sql1) && mysqli_query($d,$sql2)){
                  $_SESSION['amount'] = $amount;
                  
              //header("Refresh:1");
              }
          }
          
      }
      else{
          $message = "No amount inserted!";
      }
  }

  //----------FOR SPENC TABLE-------------//
  if($_POST['ssubmit']){//if submited
  if($_POST['spent']){//if filled input
      $spent = $_POST['spent'];

      $sql = "INSERT INTO spenc (Spent) VALUES ('$spent')";
      $sql1 = "UPDATE spenc SET Aid = AID(), Uid = UID() WHERE id = SID()";
     
      if(mysqli_query($d, $sql) && mysqli_query($d, $sql1) ){
            $check = "SELECT id FROM User where Username  = '$Susername'";
            $crow  = mysqli_fetch_array(mysqli_query($d,$check));
            $check1 = "SELECT month FROM Amount WHERE Uid = $crow[0] order by id DESC LIMIT 1 ";
            $crow1 =  mysqli_fetch_array(mysqli_query($d,$check1));
            $check2 = "SELECT month FROM spenc WHERE Uid = $crow[0] order by id DESC LIMIT 1 ";
            $crow2 =  mysqli_fetch_array(mysqli_query($d,$check2));
          if($_SESSION['amount'] != " " ){
            if($crow1[0] != $crow2[0] ){
              $sql = "SELECT a.Amount from Amount a JOIN User u where u.id = a.Uid order by a.id DESC limit 1";
              $res = mysqli_query($d,$sql);
              $row = mysqli_fetch_array($res);
              $sql2 = "UPDATE spenc s SET s.Aleft = FLeft('$row[0]') where id = SID()";
              if(mysqli_query($d,$sql2)){
                  $_SESSION['amount'] = " ";
                  echo " IF ";
                 //header("Refresh:1");
              }
            }
          }

          if($_SESSION['amount'] == " "){
              $sql3 = "UPDATE spenc SET Aleft = CLeft() where id = SID()";
              if(mysqli_query($d,$sql3)){
                  echo " ELSE ";
                 // header("Refresh:1");
                  
              }
          }
          //Update month in spenc table .
          $sql2 = "UPDATE spenc s inner join Amount a on s.Uid = a.Uid AND a.id = AID() set s.month = Month(a.date) where s.id = SID() " ;
          if(mysqli_query($d, $sql2));
      }
  }
  }
}


?>
<link rel="stylesheet" href="test.css" type="text/css" >
<button onclick='popfunction("modal-wrapper1")'>
  Calculator</button>


<div id="modal-wrapper1" class="modal1">
<form action = '' method = 'POST'>

<div class="imgcontainer">
      <span onclick="document.getElementById('modal-wrapper1').style.display='none'" class="close" title="Close">&times;</span>
      <h2 style="text-align:center">Calculator</h2>
    </div>

  <div class = 'index' >
  <table>
  <div class = 'main'>
  <tr>
  <td class = 'td'>Income</td>
  <td><input class = 'input'   name='amount' type='text' value = ' ' required ></td>
  <td><br><input name = 'asubmit' type = 'submit' value = 'Submit' required  ></td>
  </tr>
  <tr>
  <td class = 'td'>Spences</td>
  <td><input class = 'input' name='spent' type='text' value = ' ' required ></td>
  <td><input name = 'ssubmit' type = 'submit' value = 'Submit' required></td>

  </tr>
  </div>
  </table></div> 
  <div class  = "tabula">
<?php

            
          
        $sql1 = "SELECT SUM(s.Spent) as 'You have spent:' from spenc s JOIN Amount a where s.Uid = a.Uid";
        echo "<!-- $sql1 -->";
        $sql_res1 = mysqli_query($d,$sql1) or die("<h1>".mysqli_error()."</h1>");
        $row = mysqli_fetch_array($sql_res1);
        echo "<p>Spended  ".$row[0]."</p>";
        
        $sql = "SELECT s.id as 'Nr', s.Spent, s.date ,s.Aleft as 'Left' from spenc s JOIN User u ON Uid = u.id order by Nr DESC";
       
        $sql_res = mysqli_query($d,$sql) or die("<h1>".mysqli_error()."</h1>");
        table($sql_res);
?> </div>
  </form>
  <div>

<script class ='function'>
  // If user clicks anywhere outside of the modal, Modal will close
  //For login
  var modal = document.getElementById('modal-wrapper');
  //For sing up 
  var modal1 = document.getElementById('modal-wrapper1');
  
  window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
        
    }
    if(event.target == modal1){
      modal1.style.display = "none";
    }
  };
  
  function popfunction(parameter){
      document.getElementById(parameter).style.display = "block";
  }
</script>

<?php
  function table($sql_res){
      echo "<center><table class=\"table\">";
      $first = true;
      while ($row = mysqli_fetch_assoc($sql_res)) {
          if ($first) {
              echo "<tr>";
              foreach ($row as $k=>$v) {    
                  echo  "<th>$k</th>";
              }
              echo "</tr>".PHP_EOL;
              $first = false;
          }
          echo "<tr> ";
          
              foreach ($row as $v) {
                  echo "<td>$v</td>";
                  
              }
              echo "</tr>".PHP_EOL;  
      }
      echo "</table></center>";
      
      $row_cnt = mysqli_num_rows($sql_res);
      
      /* close result set */
      mysqli_free_result($sql_res);
  }
?>