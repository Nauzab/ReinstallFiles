
package dicegame;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author nz
 */
public class Computer {
    private String name;
    
    
     Computer(){
         generateName(); 
     }

    public String getName() {
        return name;
    }

    public void setName(String name) {
       
        
        this.name = name;
    }
    
    public void generateName(){//Generate name for computer
         String[] names = {"Andrea", "Joric" , "Greek" , "Moist" , "Kate" , "Embri"};
          Random rand = new Random();
          int n = rand.nextInt(names.length);
          name = names[n];
          setName(name);
    }
    
    public int choice(ArrayList<Integer> rolledDices){ //return chosen number 
        int number = 0;
        int two= 0; //Counter for two
        int three =0;//Counter for three
        int four = 0;//Counter for four
        int six = 0 ;//Counter for six
        OUTER:
        for (int i = 0; i < rolledDices.size(); i++) { 
            if (null != rolledDices.get(i)) {
                switch (rolledDices.get(i)) {
                    case 1:
                        number = 1;
                        break OUTER;
                    case 5:
                        number = 5;
                        break OUTER;
                    case 2:
                        two++;
                        if (two == 3) {
                            number = 2;
                            break OUTER;
                        }
                        break;
                    case 3:
                        three++;
                        if (three == 3) {
                            number = 3;
                            break OUTER;
                        }
                        break;
                    case 4:
                        four++;
                        if (four == 3) {
                            number = 4;
                            break OUTER;
                        }
                        break;
                    case 6:
                        six++;
                        if (six == 3) {
                            number = 6;
                            break OUTER;
                        }
                        break;
                    default:
                        break;
                }
            }
        }return number;
                
        
    }
    
     
    
}
