
import java.util.Arrays;
import java.util.Random;
//import java.util.Scanner;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author nz
 */

 class Seminar_1_PART2{
    
    public static void main(String[] arguments) throws ScriptException{
        //----------------------Exercise 1---------------------
        System.out.println("Exercise 1");
        //positionCalc function
        double gravity = -9.81; //Earth's gravity  in m/s^2
        double initialVelocity = 0.0;
        double fallingTime = 10.0;
        double initialPosition = 0.0;
        double finalPosition = 0.0;
       
        double ret;
        ret = positionCalc(gravity, initialVelocity, initialPosition, fallingTime);
     
        System.out.println("Pos in " + fallingTime+"sec :" +finalPosition);
        System.out.println( "Positions after 10 sec: " + ret);
        finalPosition = ret;
       
        //-----------------------------------------------------
        //------------------Exercise 2--------------------
        System.out.println();
        System.out.println("Exercise 2");
      //Using my function factorial
        int digit =5 ;
        int factorial = factorial(digit);
        System.out.println("Factorial of " + digit + " is " + factorial );
       
        //Example given
        //using factorialRecursive function
        int edigit = -2;
        System.out.println("Factorial of " + edigit + " is " + factorialRecursive(edigit));
     //------------------------------------------------------
   
          //----------Exercise 3-------------
          System.out.println();
          System.out.println("Exercise 3");
          //generateArray function
          int adigit = 5;
          double lower = 1;
          double upper = 20;
          double [] array = new double [adigit];
          array = generateArray(adigit,lower,upper);
         
         
          System.out.println("Random generated array "+Arrays.toString(array));
        //getMax function
        double max = getMax(array);
        System.out.println("Biggest value is "+ max);
       
        //GetMIn function
        double min = getMin(array);
        System.out.println("Smallest value is "+ min);
       
        //getMean function
        double mean = getMean(array);
        System.out.println("Mean is " + mean);
       
        //Bubble sort function
       
        System.out.println("Sorted array " + Arrays.toString(arraySort(array))) ;
       
        //-----------------------Exercise 4-------
         System.out.println();
          System.out.println("Exercise 4");
        double[][] marray = new double[5][5];
        double[][] karray = new double[1][1];
        marray = generateMatrix(5);
        
        /*//To print out matrix
        for (int i = 0; i < marray.length; i++) {
        for (int j = 0; j < marray[i].length; j++) {
        System.out.print(marray[i][j] + " ");
            }
            System.out.println();
        }*/
        
        System.out.println("Get dot product: " + getProduct(marray, 1, 1));
        
         System.out.println();
    
        //----------------------------------------
        //------------Exercise 5 -----------------
            System.out.println();
            System.out.println("Exercise 5");
            System.out.println("Coin flip" + Arrays.toString(coinFlip(10)));
            
            //Part 2;
            int roll = 5;
            System.out.println("Rolled dice of " + roll + " times " + Arrays.toString(rollDice(roll)));
        
            //Part 3
            System.out.println("Tries to roll both dices of number 6 is " + roll2Dices());
            
       
        //----------------------------------------
        
        //------------Exercise 6-------------------
        System.out.println();
        System.out.println("Exercise 6");
        byte[] barray = new byte[] {72, 101, 108, 108, 111, 33, 32, 77, 121, 32, 115, 107, 105, 
        108, 108, 115, 32, 97, 114, 101, 32, 103, 114, 101, 97, 116, 32, 97, 
        108, 114, 101, 97, 100, 121, 33};
        
        
        System.out.println("Bytes to String " + getTextFromBytes(barray));
        
        //-----------------------------------------
        
        //------------------Exercise 7-----------------
         System.out.println();
        System.out.println("Exercise 7");
        pascalsTriangle(6);
        
        //---------------------------------------------
        
        //------------Exercise 8-----------------------
         System.out.println();
        System.out.println("Exercise 8");
         //Scanner reader = new Scanner(System.in);
        //System.out.println("Enter a equation: ");
        
        String input = "1 - 3 * 18 / 4 + 2";
        System.out.println("Calculation " + executeStringEquation(input));
        
       
        
        //---------------------------------------------
        
        //---------Exercise 9--------------------------
        
        System.out.println("\nExercise 9");
        
        String operand = "[1,2,3]+[3,5,7]";
            setOperations(operand);
            operand = "[10, 9, 8, 7] * [2, 4, 6, 8]";
             setOperations(operand);
             operand = "[ 5, 10, 15, 20 ] - [ 10, 20, 80 ]"; 
             setOperations(operand);
         
        //---------------------------------------------
    }
    //Exercise 1
     public static double positionCalc(double gravity, double initialVelocity, double
initialPosition, double fallingTime){  
         double x = 0.5 * gravity * (fallingTime * fallingTime) +
                 (initialVelocity * fallingTime) + initialPosition;
         return x;
    };
   
     //Self made function
    public static int factorial(int factorial){
      
       int res = 1;
        for(int i = 1; i <= factorial; i++){
            res = res * i;
         
        }return  res;
       
    };
   
    //Requested function //Exercise 2
    public static int factorialForLoop(int N){
        int res = 1;
         for(int i = 1; i <= N; i++){
            res = res * i;
         
        }return  res;
       
    }
   
    public static int factorialRecursive(int N){
        if( N < 0 ){
            return 0 ;
        }
        else{
           return factorialForLoop(N);
        }
       
    }
   
    //Exercise 3
    //function 1.
    public static double[] generateArray(int N, double lower , double upper){
        double[] array = new double [N];
        Random r = new Random();
        if(lower < upper){
        for(int i = 0; i < N ; i++){
            double n = (upper - lower) -lower ;
            array[i] = r.nextDouble() * n;
        } return array;
        }
        else {
            return array;
        }
    };

    private static boolean toString(double[] generateArray) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    //function 2
    private static double getMax(double[] array){
        double a = 0.0;
       
        for( int i = 0 ; i < array.length; i++){
            double b = array[i];
            if ( a < b ){
                a = b;
            }  
        }return a;
    }
   
    //function 3
    private static double getMin(double[] array){
        double a = array[0];
       
        for( int i = 0 ; i < array.length; i++){
            double b = array[i];
            if ( a > b ){
                a = b;
            }  
        }return a;
    }
    //function 4
    private static double getMean(double[] array){
        double sum  = 0;
        for(int i = 0 ; i < array.length; i++){
            sum += array[i]; //Gets arrays sum
        }
        return sum/array.length; //divide sum with elements
    }
   
    //function 5
    private static double[] arraySort(double[] array){
        for(int i = 0 ; i < array.length-1 ; i ++){
            for(int j = 0 ; j < array.length -i -1 ; j ++){//loop that goest through values
                if(array[j] > array[j+1]){ //if next element is smaller
                    double temp = array[j]; // declare temp to first element
                    array[j] = array[j+1]; //declera arrays first element to second element
                    array[j+1] = temp; //declare arrays next element to arrays first element
                }
            }
        }return array;
    }
   
    //Exercise 4
    //create matrix
    public static double[][] generateMatrix(int N){
        double[][] x ;
       if (N > 0){
        x  = new double [N][N];
        Random rand = new Random();
        //hom many collons can use result.length /result[0]/length goes only through 0 collons. 
        for(int i = 0 ; i < N ; i++){
            //how many rows
            for(int j = 0; j < N; j++){
                x[i][j] = rand.nextDouble()*100;
            }
        }
        
       } 
       else{
           x = new double[1][1];
          
       } return x;
          
    }
    //Print matrix
    public static double getProduct(double[][] array, int row, int col){
        double result = 0.0;
        //Only if matrica is 5 on 5 or squere.
        if(array[0].length == array.length){
        for(int i = 0 ; i < array[0].length ; i++){
            result = array[row][i] * array[i][col];
            //System.out.println(array[row][i] + " * " + array[i][col]);
        }
        }return result;
    }
    
    //Exercise 5
    public static double[] coinFlip(int N){
        double[] array = new double[3];
        int  i = 0;
        int heads = 0;
        int tails = 0;
       
        while (N != i){
             double toss = Math.round(Math.random());
             int r = (int)toss;
             if(r == 1){
                 heads++;
             }
             else if (r == 0 ){
                 tails++;
             }
            i++;
        }
        array[0] = heads;
        array[1] = tails;
        array[2] = heads/tails;
        return array;
        
    }
    //Part 2
    public static int[] rollDice(int N){
        int[] array = new int[N];
        Random rand = new Random();
        for(int i = 0 ; i < N ; i++){    
        int n = rand.nextInt(6) +1;
        array[i] = n;
        
        }
        return  array;
    }
    //Part 3
    public static int roll2Dices(){
        Random rand = new Random();
        Random rand1 = new Random();
        int n = 0 ;
        int n1 = 0 ;
        int sum = 0 ;
        int s = 0; 
       while( s != 12){
           n = rand.nextInt(6)+1;
           n1= rand.nextInt(6)+1;
           sum = sum +1;
           s = n + n1;
       }
       return sum;
    }
    
    //Exercise 6
    public static String getTextFromBytes(byte[] array){

            String str = new String(array); //torns bytes to string ..
            return str;
    }
    
    //Exercise 7 
    
    public static void pascalsTriangle(int level){
        
        
        for(int i = 0; i <= level ; i ++){
            for (int j = 0; j < level-i; j++) {
                
                
            }
            for (int j = 0; j <=i; j++) {
                System.out.print(" "+ncr(i,j));
            }
            System.out.println();
        }
        
    }
    //Pascal formula
    static int ncr(int n, int r){
        return factorial(n) / (factorial(n - r) * factorial(r));
    }

    //Exercise 8 
    
    public static double executeStringEquation(String inputEquation) throws ScriptException{
        ScriptEngineManager mgr = new ScriptEngineManager();
        ScriptEngine engine = mgr.getEngineByName("JavaScript");
        double res = (double) engine.eval(inputEquation);
        return res;
    }
    
    //Exercise 9
    
    public static void setOperations(String input){
        StringBuilder rem = new StringBuilder();
        int indx;
        char c ;
       for(int i = 0 ; i < input.length() ; i ++){
           char operand = input.charAt(i);
           //checks witch operand is in string
           if(operand == '+'){  
               input = input.replaceAll("\\D+",""); //removes all non-digit characters from string
               for(int a = 0 ; a < input.length(); a ++){
                   c = input.charAt(a); //gets char in string at index a
                   indx = input.indexOf(c, a +1); //gets position of index
                   if( indx == -1 ){
                       rem.append(c);
                       
                   }
               }
           
           }else if ( operand == '*'){
               input = input.replaceAll("\\D+","");
               for(int a = 0 ; a < input.length();a++){
                    c = input.charAt(a);
                   indx = input.indexOf(c, a+1);
                   if(indx >1){
                       rem.append(c);
               }
           }
           
       }
           else if ( operand == '-'){
               //input = input.replaceAll("\\D+","");
               
               for(int a = 0 ; a < input.length();a++){
                        c = input.charAt(a);
                        if(c != ',' && c != '[' && c!= ']' && c!= '-'){
                                indx = input.indexOf(c, a+1);
                   if(indx < 1){
                       rem.append(c);
                   }
                        }
    
           }
           
       }
    }System.out.println(rem);
    
    
    }
}